setwd("~/scottyhines")
library(roxygen2)
devtools::document()
# usethis::use_test("square_number")
# usethis::use_test("run_t_test")
# usethis::use_test("run_hierarchical_regression")
# usethis::use_test("run_linear_regression")
# usethis::use_test("run_logistic_regression")
# usethis::use_test("run_network_analysis")
#usethis::use_test("create_fake_data")

devtools::check()
devtools::build()

devtools::install("~/scottyhines")

# test functions ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

library(scottyhines)
library(dplyr)
df <- scottyhines::create_fake_data(5000)
df %>% glimpse()

outcomes <- c("attitude_work_ethic", "attitude_adaptability", "attitude_creativity")
vars_of_interest <- c("attitude_teamwork", "attitude_communication", "demo_job_level", "attitude_persistence")

out_ttest <- scottyhines::run_t_test(df, outcome_vars = outcomes, group_var = "demo_attrition")
out_anova <- scottyhines::run_anova_with_contrasts(df, outcome_vars = outcomes, control_vars = "attitude_leadership",  group_var = "demo_region_code")
out_anova$anova_summary
out_anova$contrast_summary
scottyhines::run_linear_regression(df, outcome_var = "demo_performance", control_vars = "attitude_leadership", interest_vars = vars_of_interest)
scottyhines::run_logistic_regression(df, outcome_var = "demo_attrition", control_vars = c("attitude_leadership", "attitude_innovation"), interest_vars = vars_of_interest)
scottyhines::run_hierarchical_regression(df, outcome_var = "demo_performance", control_vars = c("demo_tenure", "demo_region_code"), interest_vars = vars_of_interest, group_var = "demo_job_level")
scottyhines::run_network_analysis(df, outcome_var = "demo_performance", control_vars = "attitude_leadership", interest_vars = c("network_degree", "network_betweenness", "network_closeness", "network_eigenvector"), group_var = "demo_job_level", num_permutations = 500)
scottyhines::run_heartbeat(df, outcomes)
scottyhines::



# function to get statistics ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


run_causal_attitude_network <- function(df, gamma, threshold){
  wd <- df %>%
    dplyr::select(where(is.numeric)) %>%  # Select only numeric columns
    dplyr::mutate(across(everything(), scale))  # Scale the remaining columns
  # create matrix ~~~~~~~~~~~~~~~~~~~~~
  CorMat <- qgraph::cor_auto(wd[,1:ncol(wd)]) # Compute correlations:
  calc_graph <- qgraph::EBICglasso(CorMat, nrow(wd), gamma, threshold = threshold) # Compute graph with tuning = 0 (BIC):
  out_graph <- qgraph::qgraph(calc_graph, layout = "spring", vsize = 3, esize = 2, label.cex = 1)
  # pull statistics ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  out_small_world <- qgraph::smallworldness(out_graph) #Pull the small world index
  temp <- qgraph::centralityPlot(out_graph, include = "all")
  temp_path <- qgraph::centrality(out_graph) #Get the centrality statistics
  out_centrality <- temp$data %>% tidyr::pivot_wider(id_cols = "node", names_from = "measure", values_from = "value")
  # centrality stats ~~~~~~~~~~~
  out_pathlengths <- as.data.frame(temp_path$ShortestPathLengths) %>%
    tibble::rownames_to_column() %>%
    tidyr::pivot_longer(cols = 2:ncol(.),  # what columns do we want to be long
                        names_to = "metric", # name of the metric
                        values_to = "value", # name of the value
                        values_drop_na = FALSE) %>%
    dplyr::filter(rowname != metric) %>%
    dplyr::mutate(value = as.numeric(value))
  # all clustering metrics ~~~~~
  out_cluster <- qgraph::clustcoef_auto(out_graph, thresholdWS = 0, thresholdON = 0)
  # cluster metrics ~~~~~~~~~~~~
  out_cluster_metrics <- as.data.frame(temp_path$ShortestPathLengths) %>%
    dplyr::bind_cols(qgraph::clustWS(out_graph)) %>%
    tibble::rownames_to_column() %>%
    dplyr::select(rowname, clustWS, signed_clustWS)
  ldf <- list(out_centrality = out_centrality, out_pathlengths = out_pathlengths, out_cluster = out_cluster, out_cluster_metrics = out_cluster_metrics, out_small_world = out_small_world)  ## create a named list of your data frames
  return(ldf)
}

df_out <- run_small_world(df, gamma = .5, threshold = F)
df_out$out_centrality
df_out$out_pathlengths
df_out$out_cluster
df_out$out_cluster_metrics
