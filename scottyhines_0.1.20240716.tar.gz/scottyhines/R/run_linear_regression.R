#' A Function to Run Linear Regression
#'
#' This function performs linear regression analysis on a given dataset. It allows for the specification of an outcome variable, control variables (if any), and variables of interest. The function returns a dataframe summarizing the regression analysis for each variable of interest, including estimates, standard errors, t-values, and p-values.
#'
#' @param data The dataset as a dataframe.
#' @param outcome_var A string specifying the name of the outcome variable.
#' @param control_vars An optional character vector specifying control variables in the model. If provided, these variables are included in the regression model as additional predictors.
#' @param interest_vars A character vector specifying the variables of interest that will be individually added to the base model for analysis.
#' @return A dataframe summarizing the linear regression analysis for each variable of interest. This summary includes regression coefficients, standard errors, t-statistics, and p-values for each term in the model.
#' @export
run_linear_regression <- function(data, outcome_vars, control_vars = NULL, interest_vars) {
  options(warn = -1)
  final_summary <- list()
  for (outcome_var in outcome_vars) {
    model_summaries <- list()
    base_formula <- paste(outcome_var, "~")
    if (!is.null(control_vars) && length(control_vars) > 0) {
      base_formula <- paste(base_formula, paste(control_vars, collapse = " + "), "+")
    }
    for (variable in interest_vars) {
      # Ensure the complete formula is a single string
      complete_formula_str <- paste(base_formula, variable, sep = " ")
      formula <- as.formula(complete_formula_str)
      # Fit the linear regression model
      model <- lm(formula, data = data)
      # Use broom's tidy function to get a cleaner model summary
      tidy_model <- broom::tidy(model)
      # Add the variable name to the summary for clarity
      tidy_model$variable_of_interest <- variable
      tidy_model$outcome_variable <- outcome_var
      # Store the summary in the list
      model_summaries[[variable]] <- tidy_model
    }
    final_summary[[outcome_var]] <- do.call(rbind, model_summaries)
  }
  final_combined_summary <- do.call(rbind, final_summary)
  options(warn = 0)
  return(final_combined_summary)
}




