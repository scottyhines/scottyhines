#' Run Cosine Similarity and Community Detection on Texts
#'
#' This function takes a list of text statements, calculates the cosine similarity matrix,
#' converts it to an edge list, and performs community detection using both the Walktrap
#' and Fast Greedy methods. It then plots the graph and community detection results side by side.
#'
#' @param texts A character vector of text statements.
#' @return A list containing the cosine similarity matrix, edge list, and community detection results.
#' @import text2vec
#' @import tm
#' @import igraph
#' @export
run_cosign_similarity <- function(texts) {
  # Create a token iterator
  tokens <- text2vec::space_tokenizer(texts)

  # Create vocabulary
  it <- text2vec::itoken(tokens, progressbar = FALSE)
  vocab <- text2vec::create_vocabulary(it)

  # Create a term-co-occurrence matrix
  vectorizer <- text2vec::vocab_vectorizer(vocab)
  dtm <- text2vec::create_dtm(it, vectorizer)

  # Apply TF-IDF transformation
  tfidf <- text2vec::TfIdf$new()
  dtm_tfidf <- text2vec::fit_transform(dtm, tfidf)

  # Calculate cosine similarity
  cosine_sim <- text2vec::sim2(dtm_tfidf, method = "cosine")

  # Convert cosine similarity matrix to an edge list
  cosine_sim_matrix <- as.matrix(cosine_sim)
  doc_ids <- 1:nrow(cosine_sim_matrix)

  edge_list <- data.frame(
    from = rep(doc_ids, each = length(doc_ids)),
    to = rep(doc_ids, times = length(doc_ids)),
    weight = as.vector(cosine_sim_matrix)
  )

  # Remove self-loops (where from == to)
  edge_list <- edge_list[edge_list$from != edge_list$to, ]

  # Remove duplicate edges
  edge_list <- edge_list[!duplicated(t(apply(edge_list, 1, sort))), ]

  # Create igraph object
  g <- igraph::graph_from_data_frame(edge_list, directed = FALSE)
  laycords <- igraph::layout_nicely(g)

  # Perform community detection using the Walktrap method
  comm_walktrap <- igraph::walktrap.community(g)

  # Perform community detection using the Fast Greedy method
  comm_fast_greedy <- igraph::cluster_fast_greedy(g)

  # Assign the community memberships to the vertices
  igraph::V(g)$comm_walktrap <- comm_walktrap$membership
  igraph::V(g)$fast_greedy <- comm_fast_greedy$membership

  # Print community memberships
  print("Walktrap Community Detection")
  print(comm_walktrap$membership)
  print("Fast Greedy Community Detection")
  print(comm_fast_greedy$membership)
  print(Sys.time())

  # Plot the graph and community detection results side by side
  par(mfrow = c(1, 3)) # Set up a 1x3 plotting area

  plot(g,
       layout = laycords,
       edge.width = igraph::E(g)$weight * 10,
       edge.label = round(igraph::E(g)$weight, 2),
       vertex.label = paste("Doc", igraph::V(g)$name),
       vertex.size = 30,
       main = "Cosine Similarity Graph")

  plot(comm_walktrap, g,
       layout = laycords,
       edge.width = igraph::E(g)$weight * 10,
       edge.label = round(igraph::E(g)$weight, 2),
       vertex.label = paste("Doc", igraph::V(g)$name),
       vertex.size = 30,
       main = "Walktrap Community Detection")

  plot(comm_fast_greedy, g,
       layout = laycords,
       edge.width = igraph::E(g)$weight * 10,
       edge.label = round(igraph::E(g)$weight, 2),
       vertex.label = paste("Doc", igraph::V(g)$name),
       vertex.size = 30,
       main = "Fast Greedy Community Detection")

  return(list(
    matrix = cosine_sim_matrix,
    edge_list = edge_list,
    community_walktrap = comm_walktrap,
    community_fast_greedy = comm_fast_greedy
  ))
}
