#' A Function to Run Mixed-Effects Model Analysis
#'
#' This function performs mixed-effects model analysis on a given dataset. It allows for the specification of multiple outcome variables, control variables (if any), and variables of interest. The function returns a dataframe summarizing the analysis for each variable of interest, including estimates, standard errors, t-values, p-values, and means at each time point.
#'
#' @param data The dataset as a dataframe.
#' @param outcome_vars A character vector specifying the names of the outcome variables.
#' @param control_vars An optional character vector specifying control variables in the model. If provided, these variables are included in the model as additional fixed effects.
#' @param interest_vars A character vector specifying the variables of interest that will be individually added to the base model for analysis.
#' @param random_effects A string specifying the random effects structure (e.g., "(1 | subject)").
#' @param interaction_var A character string specifying the interaction variable.
#' @param include_interaction A boolean indicating whether to include the interaction term in the model (default is TRUE).
#' @return A list containing two dataframes:
#'   - model_summary: A dataframe summarizing the mixed-effects model analysis for each variable of interest, including regression coefficients, standard errors, t-statistics, and p-values.
#'   - means_summary: A dataframe summarizing the mean values of the outcome variable at each level of the interaction variable.
#' @export
run_mixed_effects_model <- function(data, outcome_vars, control_vars = NULL, interest_vars, random_effects, interaction_var, include_interaction = TRUE) {
  options(warn = -1)

  # Remove cases without the interaction variable
  data <- dplyr::filter(data, !is.na(.data[[interaction_var]]))

  final_summary <- list()
  means_summary <- list()

  for (outcome_var in outcome_vars) {
    for (variable in interest_vars) {
      if (include_interaction) {
        base_formula <- paste(outcome_var, "~", variable, "*", interaction_var)
      } else {
        base_formula <- paste(outcome_var, "~", variable, "+", interaction_var)
      }
      if (!is.null(control_vars) && length(control_vars) > 0) {
        base_formula <- paste(base_formula, "+", paste(control_vars, collapse = " + "))
      }
      complete_formula_str <- paste(base_formula, "+", random_effects)
      formula <- as.formula(complete_formula_str)

      # Print the formula to check it
      print(paste("Running model with formula:", formula))

      model <- lme4::lmer(formula, data = data)
      tidy_model <- broom.mixed::tidy(model, effects = "fixed")
      tidy_model$variable_of_interest <- variable
      tidy_model$outcome_variable <- outcome_var

      means <- data %>%
        dplyr::group_by(.data[[interaction_var]]) %>%
        dplyr::summarize(mean = mean(.data[[outcome_var]], na.rm = TRUE)) %>%
        tidyr::pivot_wider(names_from = .data[[interaction_var]], values_from = mean, names_prefix = "mean_") %>%
        dplyr::mutate(outcome_variable = outcome_var, variable_of_interest = variable, interaction_variable = interaction_var)

      final_summary[[paste(outcome_var, variable, sep = "_")]] <- tidy_model
      means_summary[[paste(outcome_var, variable, sep = "_")]] <- means
    }
  }

  final_combined_summary <- do.call(rbind, final_summary)
  final_means_summary <- do.call(rbind, means_summary)

  options(warn = 0)
  return(list(model_summary = final_combined_summary, means_summary = final_means_summary))
}
