#' Create Fake Data for Analysis
#'
#' This function generates a synthetic dataset with demographic information,
#' attitude measures, network centrality metrics, and realistic qualitative data for a specified number of
#' observations. The dataset includes a mixture of factor, numeric, and character
#' variables, simulating a realistic scenario for testing data analysis pipelines,
#' including regression models and network analysis. Attitude measures are generated
#' as integer values on a scale from 1 to 5, suitable for representing Likert scale responses.
#'
#' @param n The number of observations to generate in the dataset. Defaults to 2000.
#' @return A dataframe with the following columns:
#' @export
create_fake_data <- function(n = 2000) {
  # Generating demographic variables
  demo_job_level <- factor(sample(1:5, n, replace = TRUE))
  demo_tenure <- runif(n, min = 1, max = 100)
  demo_region_code <- sample(c("north", "south", "east", "west"), n, replace = TRUE)
  demo_performance <- sample(1:5, n, replace = TRUE)
  id <- 1:n

  # Adjusting attrition rate and converting to factor
  demo_attrition <- factor(sample(c(1, 0), n, replace = TRUE, prob = c(0.2, 0.8)),
                           levels = c(0, 1), labels = c("No Attrition", "Attrition"))

  # Generating integer attitude measures on a scale from 1 to 5
  attitude_work_ethic <- sample(1:5, n, replace = TRUE)
  attitude_adaptability <- sample(1:5, n, replace = TRUE)
  attitude_creativity <- sample(1:5, n, replace = TRUE)
  attitude_persistence <- sample(1:5, n, replace = TRUE)
  attitude_teamwork <- sample(1:5, n, replace = TRUE)
  attitude_communication <- sample(1:5, n, replace = TRUE)
  attitude_leadership <- sample(1:5, n, replace = TRUE)
  attitude_innovation <- sample(1:5, n, replace = TRUE)

  # Simulating network centrality measures
  network_degree <- round(rlnorm(n, meanlog = log(10), sdlog = 0.5))
  network_betweenness <- abs(rnorm(n, mean = 0.0005, sd = 0.0005))
  network_closeness <- runif(n, min = 0.0001, max = 0.001)
  network_eigenvector <- rbeta(n, shape1 = 2, shape2 = 5)

  # Generating more realistic qualitative data
  phrases <- c(
    "The project was well executed and met all expectations.",
    "Communication within the team could be improved.",
    "I feel valued and appreciated in my role.",
    "The workload can be overwhelming at times.",
    "Leadership provides clear direction and support.",
    "There are opportunities for growth and development.",
    "I would like more feedback on my performance.",
    "The team collaborates effectively and achieves great results.",
    "There is a lack of transparency in decision-making.",
    "I enjoy the challenges and opportunities in my role."
  )

  qualitative_feedback <- sample(phrases, n, replace = TRUE)

  # Compiling variables into a dataframe
  df <- data.frame(id, demo_job_level, demo_tenure, demo_region_code, demo_performance, demo_attrition,
                   attitude_work_ethic, attitude_adaptability, attitude_creativity,
                   attitude_persistence, attitude_teamwork, attitude_communication,
                   attitude_leadership, attitude_innovation,
                   network_degree, network_betweenness, network_closeness, network_eigenvector,
                   qualitative_feedback)

  return(df)
}


create_fake_data(500)
