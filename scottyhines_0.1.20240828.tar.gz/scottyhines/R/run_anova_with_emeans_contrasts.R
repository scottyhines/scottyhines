#' Run ANOVA with Post Hoc Contrasts and Bind Group Means
#'
#' This function performs ANOVA for multiple outcome variables, followed by post hoc contrasts using the `emmeans` package.
#' It then binds the group means and standard errors to the contrast results.
#'
#' @param data A data frame containing the variables.
#' @param group_var The grouping variable (factor) for the analysis.
#' @param outcome_vars A vector of outcome variables for which the ANOVA should be run.
#' @param control_variables Optional. A vector of control variables to be included in the model.
#'
#' @return A list with three components:
#' \describe{
#'   \item{anova}{A data frame with the ANOVA results for all outcome variables.}
#'   \item{contrasts}{A data frame with the post hoc contrasts, including group means and standard errors.}
#'   \item{group_means}{A data frame with the group means and standard errors for each outcome variable.}
#' }
#'
#' @importFrom stats aov as.formula
#' @importFrom broom tidy
#' @importFrom dplyr select mutate rename_with left_join
#' @importFrom tidyr pivot_wider
#'
#' @export
run_anova_with_contrasts <- function(data, group_var, outcome_vars, control_variables = NULL) {

  # Initialize lists to store results for all outcome variables
  all_anova_results <- list()
  all_contrast_results <- list()
  all_group_means <- list()

  # Loop over each outcome variable
  for (outcome_var in outcome_vars) {

    # Prepare the formula
    if (!is.null(control_variables) && length(control_variables) > 0) {
      control_terms <- paste(control_variables, collapse = "+")
      formula <- stats::as.formula(paste(outcome_var, "~", group_var, "+", control_terms))
    } else {
      formula <- stats::as.formula(paste(outcome_var, "~", group_var))
    }

    # Run the ANOVA
    model <- stats::aov(formula, data = data)

    # Create the correct formula for emmeans
    emm_formula <- stats::as.formula(paste("~", group_var))

    # Perform post hoc contrasts using emmeans
    emm <- emmeans::emmeans(model, emm_formula)
    contrasts <- pairs(emm)

    # Tidy the output
    anova_results <- broom::tidy(model) %>%
      dplyr::mutate(outcome_var = outcome_var) # Add outcome_var to identify the source

    contrast_results <- contrasts %>%
      as.data.frame() %>%
      dplyr::mutate(
        p.value = p.adjust(p.value, method = "bonferroni"),
        outcome_var = outcome_var, # Add outcome_var to identify the source
        left_level = sub(" -.*", "", contrast),  # Extract the left comparison level
        right_level = sub(".*- ", "", contrast)  # Extract the right comparison level
      ) %>%
      dplyr::select(contrast, left_level, right_level, estimate, SE, df, t.ratio, p.value, outcome_var)

    # Extract the group means and rename the level variable
    group_means <- summary(emm) %>%
      as.data.frame() %>%
      dplyr::rename(group_level = !!group_var) %>% # Rename the group_var column to group_level
      dplyr::mutate(outcome_var = outcome_var) %>% # Add outcome_var to identify the source
      dplyr::select(group_level, emmean, SE, outcome_var)

    # Bind results to the lists
    all_anova_results[[outcome_var]] <- anova_results
    all_contrast_results[[outcome_var]] <- contrast_results
    all_group_means[[outcome_var]] <- group_means
  }

  # Combine results across all outcome variables
  combined_anova_results <- do.call(rbind, all_anova_results)
  combined_contrast_results <- do.call(rbind, all_contrast_results)
  combined_group_means <- do.call(rbind, all_group_means)

  # Combine the group means into a format suitable for joining with contrasts
  temp_1 <- combined_group_means %>%
    dplyr::select(group_level, emmean, outcome_var) %>%
    tidyr::pivot_wider(id_cols = "outcome_var", names_from = "group_level", values_from = "emmean") %>%
    dplyr::rename_with(~ paste0(., "_mean"), -dplyr::matches("outcome_var"))

  temp_2 <- combined_group_means %>%
    dplyr::select(group_level, SE, outcome_var) %>%
    tidyr::pivot_wider(id_cols = "outcome_var", names_from = "group_level", values_from = "SE") %>%
    dplyr::rename_with(~ paste0(., "_se"), -dplyr::matches("outcome_var"))

  final_means <- temp_1 %>% dplyr::left_join(temp_2, by = "outcome_var")

  # Join the final means with the contrasts
  final_contrasts <- combined_contrast_results %>%
    dplyr::left_join(final_means, by = "outcome_var")

  # Return the combined results
  return(list(anova = combined_anova_results,
              contrasts = final_contrasts,
              group_means = combined_group_means))
}
