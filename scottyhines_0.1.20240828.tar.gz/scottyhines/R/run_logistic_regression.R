#' Run Logistic Regression
#'
#' Performs logistic regression analysis on a given dataset. This function allows for specifying one outcome variable,
#' optional control variables, and multiple variables of interest. It returns a summary dataframe that includes
#' odds ratios and confidence intervals for each variable of interest.
#'
#' @param data The dataset as a dataframe.
#' @param outcome_vars The name of the outcome variable as a string.
#' @param control_vars Optional character vector of control variables in the model.
#' @param interest_vars Character vector of variables of interest.
#' @return A dataframe summarizing the logistic regression analysis, including odds ratios and confidence intervals.
#' @export
run_logistic_regression <- function(data, outcome_vars, control_vars = NULL, interest_vars) {
  if (!requireNamespace("broom", quietly = TRUE)) stop("Package 'broom' is required but not installed.")
  model_summaries <- list()

  # Loop over the outcome variables
  for (outcome_var in outcome_vars) {
    base_formula <- paste(outcome_var, "~")

    if (!is.null(control_vars) && length(control_vars) > 0) {
      base_formula <- paste(base_formula, paste(control_vars, collapse = " + "), "+")
    }

    # Loop over interest variables to fit models
    for (variable in interest_vars) {
      formula <- as.formula(paste(base_formula, variable))
      model <- glm(formula, data = data, family = binomial(link = "logit"))
      tidy_model <- broom::tidy(model)
      odds_ratios <- exp(coef(model))
      conf_int <- exp(stats::confint(model))
      tidy_model$OR <- odds_ratios[names(odds_ratios) %in% tidy_model$term]
      tidy_model$CI_lower <- conf_int[rownames(conf_int), "2.5 %"]
      tidy_model$CI_upper <- conf_int[rownames(conf_int), "97.5 %"]
      tidy_model$variable_of_interest <- variable
      tidy_model$outcome_variable <- outcome_var
      model_summaries[[paste(outcome_var, variable, sep = "_")]] <- tidy_model
    }
  }

  final_summary <- do.call(rbind, model_summaries)
  return(final_summary)
}

