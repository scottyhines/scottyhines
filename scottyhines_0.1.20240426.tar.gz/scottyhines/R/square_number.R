#' Square a Number
#'
#' This function takes a single numeric input and returns its square.
#'
#' @param x A numeric value to be squared.
#' @return The square of the input value.
#' @examples
#' @export
square_number <- function(x) {
  return(x^2)
}
