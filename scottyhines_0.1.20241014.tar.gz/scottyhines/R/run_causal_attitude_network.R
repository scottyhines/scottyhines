#' Run Causal Attitude Network Analysis
#'
#' This function processes a dataframe by scaling numeric columns, computing a correlation matrix,
#' and applying the Extended Bayesian Information Criterion Graphical Lasso (EBICglasso) to estimate
#' a network structure. It visualizes the network and calculates various network statistics,
#' including centrality, clustering coefficients, small-world properties, and more.
#'
#' @param df A dataframe containing numeric data to be analyzed as a network.
#' @param gamma The tuning parameter for EBIC in `EBICglasso`, which controls the
#'        complexity penalty in the graphical lasso procedure.
#' @param threshold Logical; if TRUE, non-significant edges are removed, leading
#'        to a sparser graph which may enhance interpretability by focusing on
#'        the most significant connections.
#'
#' @return A list of network statistics:
#'   - `out_centrality`: Data frame of centrality measures for each node.
#'   - `out_pathlengths`: Data frame of shortest path lengths in the network.
#'   - `out_cluster`: Clustering coefficients for each node.
#'   - `out_cluster_metrics`: Data frame combining path lengths and clustering metrics.
#'   - `out_small_world`: Small world index of the network.
#' @export
run_causal_attitude_network <- function(df, gamma, threshold) {
  wd <- df |>
    dplyr::select(where(is.numeric)) |>
    dplyr::mutate(across(everything(), scale))

  CorMat <- qgraph::cor_auto(wd[, 1:ncol(wd)])
  calc_graph <- qgraph::EBICglasso(CorMat, nrow(wd), gamma, threshold = threshold)
  out_graph <- qgraph::qgraph(calc_graph, layout = "spring", vsize = 3, esize = 2, label.cex = 1)

  out_small_world <- qgraph::smallworldness(out_graph)
  out_small_world_df <- as.data.frame(t(out_small_world))
  colnames(out_small_world_df) <- names(out_small_world)
  out_small_world_df[] <- lapply(out_small_world_df, function(x) as.numeric(as.character(x)))

  temp <- qgraph::centralityPlot(out_graph, include = "all")
  temp_path <- qgraph::centrality(out_graph)
  out_centrality <- temp$data |>
    tidyr::pivot_wider(id_cols = "node", names_from = "measure", values_from = "value") %>%
    dplyr::arrange(desc(ExpectedInfluence))

  out_pathlengths <- as.data.frame(temp_path$ShortestPathLengths) |>
    tibble::rownames_to_column() |>
    tidyr::pivot_longer(cols = -1, names_to = "metric", values_to = "value", values_drop_na = FALSE) %>%
    dplyr::mutate(value = as.numeric(value))

  out_cluster <- qgraph::clustcoef_auto(out_graph, thresholdWS = 0, thresholdON = 0)
  out_cluster_metrics <- as.data.frame(temp_path$ShortestPathLengths) |>
    dplyr::bind_cols(qgraph::clustWS(out_graph)) |>
    tibble::rownames_to_column() |>
    dplyr::select(rowname, clustWS, signed_clustWS)

  ldf <- list(
    out_centrality = out_centrality,
    out_pathlengths = out_pathlengths,
    out_cluster = out_cluster,
    out_cluster_metrics = out_cluster_metrics,
    out_small_world = out_small_world_df
  )

  return(ldf)
}


