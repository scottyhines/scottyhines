rm(list = ls())
options(stringsAsFactors = FALSE)
options(dplyr.summarise.inform = FALSE)
options(scipen=999)
set.seed(123456)
gc()
#setwd("~/scottyhines")
update.packages(checkBuilt = TRUE)
setwd("/Users/scotthines/Dropbox/@projects/01_projects/scottyhines")
library(roxygen2)
devtools::document()
devtools::check()

#install.packages("devtools")
# install.packages("lme4")
# install.packages(c("qgraph", "text2vec"))
#install.packages("roxygen2")

# install.packages("installr")
# install.packages("lme4")
# install.packages("Matrix")
# chooseCRANmirror()
# install.packages("Matrix")

# library(installr)
# updateR()
# update.packages(ask = FALSE, checkBuilt = TRUE)

# usethis::use_test("square_number")
# usethis::use_test("run_t_test")
# usethis::use_test("run_hierarchical_regression")
# usethis::use_test("run_linear_regression")
# usethis::use_test("run_logistic_regression")
# usethis::use_test("run_network_analysis")
#usethis::use_test("create_fake_data")

devtools::build()

devtools::install("/Users/scotthines/Dropbox/@projects/01_projects/scottyhines")

# test functions ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

library(scottyhines)
library(dplyr)
library(ggplot2)

# create fake data ~~~~~~~~~~~~~~~~~~
df <- scottyhines::create_fake_data(5000) %>% dplyr::mutate(id = as.factor(id))
df %>% glimpse()

# set outcomes and predictors ~~~~~~~
outcomes <- c("attitude_work_ethic", "attitude_adaptability", "attitude_creativity")
vars_of_interest <- c("attitude_teamwork", "attitude_communication", "attitude_persistence")

# statifed sampling ~~~~~~~~~~~~~~~~~
out <- scottyhines::create_stratified_sample(df, c("demo_job_level", "demo_region_code", "demo_attrition"), 100)
out$sample
out$proportionality_check

# build tables ~~~~~~~~~~~~~~~~~~~~~~
scottyhines::build_means_table(df, group_var = "demo_region_code", vars = outcomes, include_sd = T)
scottyhines::build_frequency_table(df, group_var = "demo_performance", vars = "demo_region_code", include_percentage = T)
scottyhines::build_correlation_table(data = df, outcome_vars = outcomes, interest_vars = vars_of_interest)

# data viz ~~~~~~~~~~~~~~~~~~~~~~~~~~
scottyhines::dataviz_scatter_item_function(df, grouping_var = "demo_job_level", item_score_var = "demo_performance")

# run statistical analyses ~~~~~~~~~~
# t-test ~~~~~~~~~~~~~~~
temp <- df %>%
  dplyr::select(demo_tenure, demo_region_code, demo_attrition, id) %>%
  tidyr::pivot_wider(id_cols = c("id", "demo_region_code"), names_from = "demo_attrition", values_from = "demo_tenure") %>%
  dplyr::rename(value = 3) %>%
  glimpse()
scottyhines::run_one_sample_ttest_with_overall_mean(temp, item_col = "demo_region_code", response_col = "value")
scottyhines::run_ttest(df, outcome_vars = vars_of_interest, group_var = "demo_attrition", paired = F)

scottyhines::run_ano

out_anova <- scottyhines::run_anova_with_contrasts(df, outcome_vars = outcomes, control_variables = "attitude_leadership",  group_var = "demo_region_code")
out_anova$anova
out_anova$contrasts
out_anova$group_means
x <- scottyhines::run_linear_regression(df, outcome_var = outcomes, control_vars = "attitude_leadership", interest_vars = vars_of_interest)
x <- scottyhines::run_logistic_regression(df, outcome_var = "demo_attrition", control_vars = c("attitude_leadership", "attitude_innovation"), interest_vars = vars_of_interest)
x <- scottyhines::run_hierarchical_regression(df, outcome_var = outcomes, control_vars = c("demo_tenure", "demo_region_code"), interest_vars = vars_of_interest, group_var = "demo_job_level")
scottyhines::run_network_analysis(df, outcome_var = "demo_performance", control_vars = "attitude_leadership", interest_vars = c("network_degree", "network_betweenness", "network_closeness", "network_eigenvector"), group_var = "demo_job_level", num_permutations = 500)
scottyhines::run_heartbeat(df, outcomes)
scottyhines::run_causal_attitude_network(df, gamma = .5, threshold = F)
scottyhines::run_mixed_effects_model(df, outcome_vars = c("attitude_work_ethic", "attitude_adaptability"), control_vars = c("attitude_teamwork"), interest_vars = c("attitude_communication"), random_effects = "(1 | demo_job_level)", interaction_var = "demo_job_level", include_interaction = T)
scottyhines::run_psychometrics(df, items = c(outcomes, vars_of_interest), factors = 3)

# Power Analysis ~~~~~
scottyhines::power_analysis_calculator(test_type = "regression", effect_size = 0.25, power = 0.8, num_predictors = 3)
scottyhines::power_analysis_calculator(test_type = "anova", effect_size = 0.25, power = 0.8, k = 5)
scottyhines::power_analysis_calculator(test_type = "t_test", effect_size = 0.5, power = 0.8)
scottyhines::power_analysis_calculator(test_type = "correlation", effect_size = 0.5, power = 0.8)
scottyhines::power_analysis_calculator(test_type = "proportion", effect_size = 0.5, power = 0.8)

# cosine ~~~~~~~~~~~~~
# Define the sentences
sentences <- c(
  "Using that camera is easy.",
  "Why is she so untidy?",
  "I'm sorry I'm walking so slowly.",
  "It doesn't always work out so well.",
  "That motorway is so dangerous.",
  "That's kind of you.",
  "He's so lazy that he never helps out with the housework."
)

# Define a vector of unique names
unique_names <- c('Alice', 'Bob', 'Charlie', 'Diana', 'Ethan', 'Fiona', 'George')

# Create a dataframe with an ID column and a column for the number of words in each sentence
set.seed(42) # For reproducibility
df_qual <- data.frame(
  id = 1:length(sentences),
  sentence = sentences,
  num_words = sapply(strsplit(sentences, "\\s+"), length),
  random_col1 = sample(1:100, length(sentences), replace = TRUE),
  random_col2 = sample(1:100, length(sentences), replace = TRUE),
  random_col3 = sample(1:100, length(sentences), replace = TRUE),
  name = unique_names)
# Print the dataframe
print(df_qual)
scottyhines::run_cosine_similarity_with_attrs(df_qual, text_col = "sentence", node_id_col = "name", node_attrs = c("id", "num_words", "random_col1"))
