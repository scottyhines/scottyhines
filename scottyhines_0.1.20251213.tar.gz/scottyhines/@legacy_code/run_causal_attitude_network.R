#' Run Causal Attitude Network Analysis
#'
#' This function processes a dataframe by scaling numeric columns, computing a correlation matrix,
#' and applying the Extended Bayesian Information Criterion Graphical Lasso (EBICglasso) to estimate
#' a network structure. It visualizes the network and calculates various network statistics,
#' including centrality, clustering coefficients, small-world properties, and more.
#'
#' @param df A dataframe containing numeric data to be analyzed as a network.
#' @param gamma The tuning parameter for EBIC in `EBICglasso`, which controls the
#'        complexity penalty in the graphical lasso procedure.
#' @param threshold Logical; if TRUE, non-significant edges are removed, leading
#'        to a sparser graph which may enhance interpretability by focusing on
#'        the most significant connections.
#'
#' @return A list of network statistics:
#'   - `out_centrality`: Data frame of centrality measures for each node.
#'   - `out_pathlengths`: Data frame of shortest path lengths in the network.
#'   - `out_cluster`: Clustering coefficients for each node.
#'   - `out_cluster_metrics`: Data frame combining path lengths and clustering metrics.
#'   - `out_small_world`: Small world index of the network.
#' @export
run_causal_attitude_network <- function(df, gamma, threshold, plot_title) {
  # Helper functions
  process_correlation_matrix <- function(CorMat) {
    CorMat %>%
      as.data.frame() %>%
      tibble::rownames_to_column(var = "from") %>%
      tidyr::pivot_longer(cols = -from, names_to = "to", values_to = "weight") %>%
      dplyr::filter(from < to, weight != 1) %>%
      dplyr::arrange(desc(abs(weight))) %>%
      dplyr::mutate(reweight = scales::rescale(weight)) %>%
      dplyr::filter(reweight > .25)
  }

  create_network_plot <- function(edge_file, plot_title) {
    set.seed(12345)
    g <- igraph::graph_from_data_frame(edge_file, directed = FALSE) %>%
      igraph::simplify(edge.attr.comb = list(weight = "sum"))

    # Edge attributes
    E(g)$type <- "Relationship Strength"
    E(g)$color <- "#566573"  # Simplified to single color
    E(g)$weight <- scales::rescale(E(g)$weight, to = c(0.1, 0.9))

    # Layout
    set.seed(42)
    laycords <- igraph::layout_with_fr(g) %>%
      apply(2, function(x) (x - min(x)) / (max(x) - min(x)) * 0.8 + 0.1)

    # Plot
    par(bg = "white", mar = c(1,1,1,1))
    plot(g,
         layout = laycords,
         vertex.size = 20,
         vertex.color = "white",
         vertex.frame.color = "black",
         vertex.label.cex = 1,
         vertex.label.color = "black",
         edge.width = E(g)$weight * 5.5,
         edge.curved = 0.0,
         edge.color = E(g)$color)
    title(plot_title, cex.main = 1.2)

    # Legend
    legend("bottomright",
           legend = "Relationship Strength",
           col = "#566573",
           lty = 1,
           cex = 0.8,
           bty = "n",
           text.col = "black")
  }

  # Main analysis
  wd <- df %>%
    dplyr::select(where(is.numeric)) %>%
    dplyr::mutate(across(everything(), scale))

  CorMat <- qgraph::cor_auto(wd)
  calc_graph <- qgraph::EBICglasso(CorMat, nrow(wd), gamma, threshold = threshold)
  out_graph <- qgraph::qgraph(calc_graph, layout = "spring", vsize = 3, esize = 2, label.cex = 1, labels = colnames(wd))

  # Calculate metrics
  out_small_world <- qgraph::smallworldness(out_graph)
  temp_path <- qgraph::centrality(out_graph)

  # Process outputs
  out_centrality <- qgraph::centralityPlot(out_graph, include = "all")$data %>%
    tidyr::pivot_wider(id_cols = "node", names_from = "measure", values_from = "value") %>%
    dplyr::arrange(desc(ExpectedInfluence))

  edge_df <- process_correlation_matrix(CorMat)
  create_network_plot(edge_df, plot_title)

  # Return results
  list(
    out_centrality = out_centrality,
    out_pathlengths = tibble::rownames_to_column(as.data.frame(temp_path$ShortestPathLengths)) %>%
      tidyr::pivot_longer(-1, names_to = "metric", values_to = "value", values_drop_na = FALSE) %>%
      dplyr::mutate(value = as.numeric(value)),
    out_cluster = qgraph::clustcoef_auto(out_graph, thresholdWS = 0, thresholdON = 0),
    out_cluster_metrics = tibble::rownames_to_column(
      dplyr::bind_cols(
        as.data.frame(temp_path$ShortestPathLengths),
        qgraph::clustWS(out_graph)
      )
    ) %>% dplyr::select(rowname, clustWS, signed_clustWS),
    out_small_world = as.data.frame(t(out_small_world)) %>%
      setNames(names(out_small_world)),
    corr_matrix = edge_df
  )
}


