#' Run Cosine Similarity Analysis on Text Data
#'
#' This function performs cosine similarity analysis on a given dataset of text,
#' creating a network visualization of text similarities.
#'
#' @param df A data frame containing the text data and node IDs.
#' @param text_col The name of the column in df that contains the text data.
#' @param node_id_col The name of the column in df that contains the node IDs.
#' @param node_attrs Optional. Additional node attributes to include in the output.
#' @param cut_number The number of most similar and dissimilar nodes to highlight. Default is 3.
#' @param edge_cut The proportion of edges to keep in the network. Default is 0.5 (50%).
#' @param label_size Size of node labels. Default is 0.7.
#' @param vertex_size Size of vertices. Default is 3.
#' @param layout_func Layout function to use. Default is layout_with_fr.
#' @param use_ngrams Logical. Whether to use n-grams in the vocabulary. Default is TRUE.
#' @param ngram_range A vector of two integers specifying the lower and upper boundary of the n-gram range. Default is c(1, 2).
#' @param min_term_freq The minimum frequency for a term to be included in the vocabulary. Default is 1.
#' @param max_term_freq The maximum frequency for a term to be included in the vocabulary. Default is Inf.
#'
#' @return A list containing:
#'   \item{edge_list}{A data frame of edges in the similarity network.}
#'   \item{node_file}{A data frame of nodes with their attributes.}
#'   \item{dissimilarity_ranking}{A data frame of nodes ranked by their dissimilarity scores.}
#'
#' @import text2vec tm igraph dplyr SnowballC
#' @export
run_cosine_similarity_simplified <- function(df, text_col, node_id_col,
                                             node_attrs = NULL,
                                             cut_number = 3,
                                             edge_cut = 0.5,
                                             label_size = 0.7,
                                             vertex_size = 3,
                                             layout_func = layout_with_fr,
                                             use_ngrams = TRUE,
                                             ngram_range = c(1, 2),
                                             min_term_freq = 1,
                                             max_term_freq = Inf) {

  # library(text2vec)
  # library(tm)
  # library(igraph)
  # library(dplyr)
  # library(SnowballC)

  # Input validation
  if (!all(c(text_col, node_id_col) %in% colnames(df))) {
    stop("Specified text_col or node_id_col not found in the dataframe")
  }

  texts <- df[[text_col]]
  node_ids <- df[[node_id_col]]

  cat("Number of rows in input dataframe:", nrow(df), "\n")
  cat("Number of unique node IDs:", length(unique(node_ids)), "\n")

  # Text preprocessing
  stop_words <- tm::stopwords("en")
  preprocess_text <- function(x) {
    x <- tolower(x)
    x <- gsub("[[:punct:]]", " ", x)
    x <- gsub("[[:digit:]]", " ", x)
    x <- gsub("\\s+", " ", x)
    x <- trimws(x)
    tokens <- unlist(strsplit(x, "\\s+"))
    tokens <- tokens[!tokens %in% stop_words]
    tokens <- sapply(tokens, SnowballC::wordStem)
    paste(tokens, collapse = " ")
  }

  processed_texts <- sapply(texts, preprocess_text)
  it <- itoken(processed_texts, ids = node_ids, progressbar = FALSE)

  # Create vocabulary
  if (use_ngrams) {
    vocab <- create_vocabulary(it, ngram = ngram_range)
  } else {
    vocab <- create_vocabulary(it)
  }
  vocab <- prune_vocabulary(vocab,
                            term_count_min = min_term_freq,
                            term_count_max = max_term_freq)

  # Create DTM and calculate similarity
  vectorizer <- vocab_vectorizer(vocab)
  dtm <- create_dtm(it, vectorizer)
  cat("DTM dimensions:", dim(dtm), "\n")

  tfidf <- TfIdf$new()
  dtm_tfidf <- fit_transform(dtm, tfidf)
  cosine_sim <- sim2(dtm_tfidf, dtm_tfidf, method = "cosine", norm = "l2")

  cat("Cosine similarity matrix dimensions:", dim(cosine_sim), "\n")

  # Convert to dataframe
  cosine_sim_df <- as.data.frame(as.matrix(cosine_sim))
  colnames(cosine_sim_df) <- node_ids
  rownames(cosine_sim_df) <- node_ids

  # Calculate dissimilarity
  avg_dissimilarity <- rowMeans(1 - cosine_sim_df)
  norm_dissimilarity <- (avg_dissimilarity - min(avg_dissimilarity))/
    (max(avg_dissimilarity) - min(avg_dissimilarity))

  dissimilarity_df <- data.frame(
    node_id = node_ids,
    dissimilarity = avg_dissimilarity,
    normalized_dissimilarity = norm_dissimilarity
  )
  dissimilarity_df <- dissimilarity_df[order(-dissimilarity_df$dissimilarity), ]

  # Create edge list
  edge_list <- data.frame(
    from = rep(node_ids, each = length(node_ids)),
    to = rep(node_ids, times = length(node_ids)),
    weight = as.vector(as.matrix(cosine_sim))
  )

  # Remove self-loops and duplicates
  edge_list <- edge_list[edge_list$from != edge_list$to, ]
  edge_list <- edge_list[!duplicated(t(apply(edge_list, 1, sort))), ]
  edge_list <- edge_list[order(-edge_list$weight), ]

  # Keep top edges based on edge_cut
  num_edges_to_keep <- ceiling(nrow(edge_list) * edge_cut)
  edge_list <- edge_list[1:num_edges_to_keep, ]

  # Create and plot graph
  node_file <- df %>% dplyr::select(all_of(c(node_id_col, node_attrs)))
  g <- graph_from_data_frame(edge_list, vertices = node_file, directed = FALSE)

  # Calculate layout
  lay <- layout_func(g)

  # Identify most similar and dissimilar nodes
  most_dissimilar <- head(dissimilarity_df$node_id[order(-dissimilarity_df$dissimilarity)], cut_number)
  most_similar <- tail(dissimilarity_df$node_id[order(-dissimilarity_df$dissimilarity)], cut_number)

  # Set node colors
  V(g)$color <- ifelse(V(g)$name %in% most_dissimilar,
                       "#1cd788",
                       ifelse(V(g)$name %in% most_similar,
                              "#d23a3c",
                              "#d8e5e7"))

  # Plot settings
  par(mar = c(0, 0, 2, 0))  # Reduce margins

  # Create plot
  plot(g,
       layout = lay,
       vertex.color = V(g)$color,
       vertex.label.cex = label_size,
       vertex.size = vertex_size,
       vertex.label.dist = 0.75,  # Distance between label and vertex
       edge.width = 1,
       edge.color = "gray80",
       main = "Text Similarity Network")

  # Add legend
  legend("bottomright",
         legend = c("Most Dissimilar", "Most Similar"),
         col = c("#1cd788", "#d23a3c"),
         pch = 19,
         pt.cex = 1.5,
         cex = 0.8,
         bty = "n")

  # Return results
  return(list(
    edge_list = edge_list,
    node_file = node_file,
    dissimilarity_ranking = dissimilarity_df
  ))
}
