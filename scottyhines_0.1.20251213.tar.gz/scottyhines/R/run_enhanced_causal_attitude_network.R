#' Run Enhanced Causal Attitude Network Analysis with Corrected Color Assignment
#'
#' Performs Causal Attitude Network (CAN) analysis on numeric data using EBIC graphical LASSO,
#' calculates network centrality metrics with z-score standardization, and generates a network
#' visualization with color-coded nodes based on Expected Influence scores.
#'
#' @param df A data frame containing the variables to be analyzed. Must contain at least
#'   some numeric columns.
#' @param gamma Numeric. The EBIC tuning parameter (typically between 0 and 0.5). Higher values
#'   result in sparser networks. Recommended: 0.5 for exploratory analysis, 0.25 for
#'   confirmatory analysis.
#' @param threshold Numeric. The threshold for edge weights in the network. Edges with absolute
#'   weights below this value are set to zero. Default is typically 0.
#' @param plot_title Character string. The title to display on the network plot.
#'
#' @return A list containing seven elements:
#' \describe{
#'   \item{out_adjacency}{The adjacency matrix from the EBIC graphical LASSO}
#'   \item{out_centrality}{Data frame with centrality metrics including z-scored Expected
#'     Influence, sorted by descending Expected Influence}
#'   \item{out_pathlengths}{Data frame with shortest path lengths between all node pairs}
#'   \item{out_cluster}{Clustering coefficient calculated using qgraph's clustcoef_auto}
#'   \item{out_cluster_metrics}{Data frame with clustering coefficients (weighted and signed)
#'     for each node}
#'   \item{out_small_world}{Data frame with small-world network metrics}
#'   \item{corr_matrix}{Processed correlation matrix as an edge list with reweighted values}
#' }
#'
#' @details
#' The function performs the following steps:
#' \enumerate{
#'   \item Selects numeric variables and standardizes them (z-score transformation)
#'   \item Computes polychoric/polyserial correlations using \code{qgraph::cor_auto}
#'   \item Estimates a sparse network using EBIC graphical LASSO
#'   \item Calculates centrality metrics with z-score standardization for Expected Influence
#'   \item Generates a network visualization with nodes colored by Expected Influence:
#'     \itemize{
#'       \item Red: Low influence (< -1 SD)
#'       \item Yellow: Medium influence (-1 to 1 SD)
#'       \item Green: High influence (> 1 SD)
#'     }
#'   \item Computes network properties including clustering and small-world metrics
#' }
#'
#' The Expected Influence metric is z-score standardized (mean = 0, SD = 1) to facilitate
#' interpretation across different network sizes and structures. The color assignment is
#' carefully matched to preserve the correct node-to-color mapping in the visualization.
#'
#' @note
#' \itemize{
#'   \item The function prints debugging information about color assignment to the console
#'   \item Edge colors: red for negative relationships, gray for positive relationships
#'   \item The Fruchterman-Reingold layout algorithm is used with special handling for
#'     networks containing negative edge weights
#'   \item A random seed (123) is set for reproducible layouts
#' }
#'
#' @examples
#' \dontrun{
#' # Load required packages
#' library(qgraph)
#' library(igraph)
#' library(dplyr)
#' library(tidyr)
#' library(tibble)
#' library(scales)
#'
#' # Example with simulated data
#' set.seed(42)
#' df <- data.frame(
#'   var1 = rnorm(200),
#'   var2 = rnorm(200),
#'   var3 = rnorm(200),
#'   var4 = rnorm(200),
#'   var5 = rnorm(200)
#' )
#'
#' # Run CAN analysis
#' results <- run_enhanced_causal_attitude_network(
#'   df = df,
#'   gamma = 0.5,
#'   threshold = 0,
#'   plot_title = "Example Causal Attitude Network"
#' )
#'
#' # Access results
#' print(results$out_centrality)
#' print(results$out_small_world)
#' }
#'
#' @references
#' Epskamp, S., Cramer, A. O., Waldorp, L. J., Schmittmann, V. D., & Borsboom, D. (2012).
#' qgraph: Network visualizations of relationships in psychometric data.
#' Journal of Statistical Software, 48(4), 1-18.
#'
#' Foygel, R., & Drton, M. (2010). Extended Bayesian information criteria for Gaussian
#' graphical models. Advances in Neural Information Processing Systems, 23, 604-612.
#'
#' @seealso \code{\link[qgraph]{EBICglasso}}, \code{\link[qgraph]{qgraph}},
#'   \code{\link[qgraph]{centrality}}, \code{\link[igraph]{graph_from_adjacency_matrix}}
#'
#' @importFrom qgraph cor_auto EBICglasso qgraph centrality centralityPlot smallworldness clustcoef_auto clustWS
#' @importFrom igraph graph_from_adjacency_matrix vcount ecount layout_with_fr V E
#' @importFrom dplyr select mutate filter arrange bind_cols across
#' @importFrom tidyr pivot_longer pivot_wider
#' @importFrom tibble rownames_to_column
#' @importFrom scales rescale
#' @importFrom grDevices adjustcolor
#' @importFrom graphics plot legend
#' @importFrom stats sd
#'
#' @export
run_enhanced_causal_attitude_network <- function(df, gamma, threshold, plot_title) {
  
  # Process correlation matrix function (same as original)
  process_correlation_matrix <- function(CorMat) {
    CorMat %>% 
      as.data.frame() %>% 
      tibble::rownames_to_column(var = "from") %>% 
      tidyr::pivot_longer(cols = -from, names_to = "to", values_to = "weight") %>% 
      dplyr::filter(from < to, weight != 1) %>% 
      dplyr::arrange(desc(abs(weight))) %>% 
      dplyr::mutate(reweight = scales::rescale(weight)) %>% 
      dplyr::filter(reweight > 0.25)
  }
  
  # Main CAN analysis
  wd <- df %>% 
    dplyr::select(where(is.numeric)) %>% 
    dplyr::mutate(across(everything(), scale))
  
  CorMat <- qgraph::cor_auto(wd)
  calc_graph <- qgraph::EBICglasso(CorMat, nrow(wd), gamma, threshold = threshold)
  out_graph <- qgraph::qgraph(calc_graph, layout = "spring", vsize = 3, esize = 2, 
                              label.cex = 1, labels = colnames(wd))
  out_small_world <- qgraph::smallworldness(out_graph)
  temp_path <- qgraph::centrality(out_graph)
  
  # Calculate centrality and apply Z-SCORE scaling - DON'T SORT YET
  out_centrality_unsorted <- qgraph::centralityPlot(out_graph, include = "all")$data %>% 
    tidyr::pivot_wider(id_cols = "node", names_from = "measure", values_from = "value") %>% 
    dplyr::mutate(
      # Z-score scaling: (value - mean) / sd, resulting in mean=0, sd=1
      ExpectedInfluence_zscore = as.vector(scale(ExpectedInfluence)),
      # Keep original for reference
      ExpectedInfluence_original = ExpectedInfluence,
      # Use z-score version as the main EI
      ExpectedInfluence = ExpectedInfluence_zscore
    )
  
  # Create sorted version for display/output
  out_centrality <- out_centrality_unsorted %>%
    dplyr::arrange(desc(ExpectedInfluence))
  
  edge_df <- process_correlation_matrix(CorMat)
  
  # PLOTTING WITH CORRECTED COLOR ASSIGNMENT ================================
  
  # Color palette: Red (< -1), Yellow (-1 to 1), Green (> 1)
  influence_colors <- adjustcolor(c("#e74c3c", "#f1c40f", "#27ae60"), alpha=0.8)  # Red, Yellow, Green
  
  # Create plot using adjacency matrix
  adj_matrix <- as.matrix(calc_graph)
  g <- igraph::graph_from_adjacency_matrix(adj_matrix, mode = "undirected", weighted = TRUE)
  
  if (vcount(g) > 0) {
    set.seed(123)
    
    # Get node names in the order they appear in the graph
    graph_node_names <- rownames(adj_matrix)
    print("=== DEBUGGING COLOR ASSIGNMENT ===")
    print("Graph node order:")
    print(graph_node_names)
    
    # Match centrality data to graph node order (CRITICAL FIX)
    centrality_matched <- out_centrality_unsorted[match(graph_node_names, out_centrality_unsorted$node), ]
    
    print("Matched centrality data (in graph order):")
    print(data.frame(
      graph_order = 1:length(graph_node_names),
      node = centrality_matched$node,
      ei_zscore = round(centrality_matched$ExpectedInfluence, 3)
    ))
    
    # Uniform styling
    V(g)$size <- rep(12, vcount(g))
    V(g)$shape <- "circle"
    
    # Color by Z-scored Expected Influence using MATCHED data
    if (length(unique(centrality_matched$ExpectedInfluence)) > 1) {
      influence_categories <- cut(centrality_matched$ExpectedInfluence, 
                                  breaks = c(-Inf, -1, 1, Inf), 
                                  labels = c("Low", "Medium", "High"), 
                                  include.lowest = TRUE)
      
      print("Influence categories (in graph order):")
      print(data.frame(
        node = centrality_matched$node,
        ei_zscore = round(centrality_matched$ExpectedInfluence, 3),
        category = influence_categories
      ))
      
      color_mapping <- c("Low" = influence_colors[1],     # Red for < -1 SD
                         "Medium" = influence_colors[2],   # Yellow for -1 to 1 SD
                         "High" = influence_colors[3])     # Green for > 1 SD
      
      # Apply colors in the correct order
      V(g)$color <- color_mapping[as.character(influence_categories)]
      
      print("Final color assignment:")
      print(data.frame(
        node = centrality_matched$node,
        ei_zscore = round(centrality_matched$ExpectedInfluence, 3),
        category = influence_categories,
        color = V(g)$color
      ))
      
    } else {
      V(g)$color <- influence_colors[2]  # Default to medium (yellow)
      influence_categories <- rep("Medium", vcount(g))
    }
    
    # Edge styling (same as before)
    if (ecount(g) > 0) {
      E(g)$width <- 0.8
      
      # Color edges based on relationship direction
      edge_weights <- E(g)$weight
      if (any(edge_weights < 0)) {
        E(g)$color <- ifelse(edge_weights < 0, "#e74c3c", "#566573")
      } else {
        E(g)$color <- "#566573"
      }
    }
    
    # Layout - Kamada-Kawai with negative weight handling
    if (ecount(g) > 0 && any(E(g)$weight < 0)) {
      original_weights <- E(g)$weight
      E(g)$weight <- abs(E(g)$weight)
      tryCatch({
        laycords <- igraph::layout_with_fr(g)
      }, error = function(e) {
        laycords <- igraph::layout_with_fr(g, niter = 1000)
      })
      E(g)$weight <- original_weights
    } else {
      tryCatch({
        laycords <- igraph::layout_with_fr(g)
      }, error = function(e) {
        laycords <- igraph::layout_with_fr(g, niter = 1000)
      })
    }
    
    # Plot with same parameters as 64_05_02
    plot(g,
         layout = laycords,
         vertex.shape = V(g)$shape,
         vertex.size = V(g)$size,
         vertex.label = rownames(adj_matrix),
         vertex.label.cex = 1.15,
         vertex.label.color = "black",
         vertex.label.font = 2,
         vertex.label.dist = 0,
         vertex.frame.width = 1,
         vertex.frame.color = "#777777",
         edge.arrow.size = 0.01,
         edge.arrow.width = 0.01,
         edge.width = E(g)$width,
         edge.curved = 0,
         main = plot_title,
         main.cex = 8.0)
    
    # Legend with z-score interpretation
    if (length(unique(centrality_matched$ExpectedInfluence)) > 1) {
      legend("bottomright",
             title = "Expected Influence (Z-Score)",
             legend = c("Low (< -1 SD)", "Med (-1 to 1 SD)", "High (> 1 SD)"),
             pch = 21,
             col = "#777777",
             pt.bg = influence_colors,
             pt.cex = 1.5,
             cex = 0.6,
             bty = "n")
    }
    
    # Print EI statistics for verification
    print("=== EXPECTED INFLUENCE Z-SCORE SUMMARY ===")
    print(paste("Z-scored EI mean:", round(mean(out_centrality$ExpectedInfluence, na.rm = TRUE), 3)))
    print(paste("Z-scored EI sd:", round(sd(out_centrality$ExpectedInfluence, na.rm = TRUE), 3)))
    print("EI distribution by category:")
    print(table(influence_categories))
  }
  
  # Return same structure as original (using sorted centrality for output)
  list(
    out_adjacency = calc_graph,
    out_centrality = out_centrality, 
    out_pathlengths = tibble::rownames_to_column(as.data.frame(temp_path$ShortestPathLengths)) %>% 
      tidyr::pivot_longer(-1, names_to = "metric", values_to = "value", values_drop_na = FALSE) %>% 
      dplyr::mutate(value = as.numeric(value)), 
    out_cluster = qgraph::clustcoef_auto(out_graph, thresholdWS = 0, thresholdON = 0), 
    out_cluster_metrics = tibble::rownames_to_column(dplyr::bind_cols(as.data.frame(temp_path$ShortestPathLengths), qgraph::clustWS(out_graph))) %>% 
      dplyr::select(rowname, clustWS, signed_clustWS), 
    out_small_world = as.data.frame(t(out_small_world)) %>% setNames(names(out_small_world)), 
    corr_matrix = edge_df
  )
}