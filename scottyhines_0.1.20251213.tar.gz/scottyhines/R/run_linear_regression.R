#' Run Linear Regression(s) With Optional Interaction Loop
#'
#' Fits linear models of the form:
#'   outcome ~ controls + (interest_var * interaction_with)
#' If `interaction_with` is NULL, it falls back to:
#'   outcome ~ controls + interest_var
#'
#' @param data A data.frame.
#' @param outcome_vars Character vector of outcome variable names.
#' @param control_vars Optional character vector of control variables always included.
#' @param interest_vars Character vector of predictors of interest to iterate over.
#' @param interaction_with Optional character vector of variables to interact with each interest var
#'   (e.g., "org_affiliation"). If provided, each model uses `interest_var * interaction_with`.
#' @return A data.frame (rows = model terms across all runs) with tidy coefficients and metadata.
#' @export
run_linear_regression <- function(data,
                                  outcome_vars,
                                  control_vars = NULL,
                                  interest_vars,
                                  interaction_with = NULL) {
  options(warn = -1)
  on.exit(options(warn = 0), add = TRUE)
  
  stopifnot(is.data.frame(data))
  stopifnot(is.character(outcome_vars), length(outcome_vars) >= 1)
  stopifnot(is.character(interest_vars), length(interest_vars) >= 1)
  if (!is.null(control_vars)) stopifnot(is.character(control_vars))
  if (!is.null(interaction_with)) stopifnot(is.character(interaction_with))
  
  final_summary <- list()
  
  for (outcome_var in outcome_vars) {
    model_summaries <- list()
    
    # Build the left side of the formula
    base_formula <- paste(outcome_var, "~")
    
    # Add controls if any
    if (!is.null(control_vars) && length(control_vars) > 0) {
      base_formula <- paste(base_formula, paste(control_vars, collapse = " + "), "+")
    }
    
    # Iterate over variables of interest
    for (variable in interest_vars) {
      
      # If interactions are requested, iterate across them; else just the variable
      partners <- if (is.null(interaction_with)) NA_character_ else interaction_with
      
      for (partner in partners) {
        if (is.na(partner)) {
          # No interaction: just add the interest variable
          rhs_term <- variable
          interacted_with_val <- NA_character_
        } else {
          # With interaction: use * to include main effects + interaction
          rhs_term <- paste(variable, partner, sep = " * ")
          interacted_with_val <- partner
        }
        
        # Full formula string
        complete_formula_str <- paste(base_formula, rhs_term, sep = " ")
        fm <- stats::as.formula(complete_formula_str)
        
        # Fit model
        fit <- stats::lm(fm, data = data)
        
        # Tidy summary
        tidy_model <- broom::tidy(fit)
        
        # Add metadata
        tidy_model$variable_of_interest <- variable
        tidy_model$interacted_with     <- interacted_with_val
        tidy_model$outcome_variable    <- outcome_var
        tidy_model$formula             <- complete_formula_str
        
        key <- if (is.na(interacted_with_val)) {
          paste(variable, outcome_var, sep = "__")
        } else {
          paste(variable, interacted_with_val, outcome_var, sep = "__")
        }
        model_summaries[[key]] <- tidy_model
      }
    }
    
    final_summary[[outcome_var]] <- do.call(rbind, model_summaries)
  }
  
  final_combined_summary <- do.call(rbind, final_summary)
  rownames(final_combined_summary) <- NULL
  final_combined_summary
}
