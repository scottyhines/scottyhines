#' Cross-validated XGBoost via tidymodels
#' (with confusion matrices, key metrics, and variable importance)
#'
#' @description
#' Fits an XGBoost model with tidymodels using robust preprocessing,
#' v-fold cross-validation, and hyperparameter tuning. Supports
#' classification (binary/multiclass) and regression.
#'
#' Returns train/test confusion matrices & a compact set of 6–8 key
#' classification metrics (accuracy, kappa, sensitivity/recall, specificity,
#' precision, F1, balanced accuracy; plus ROC AUC & PR AUC for **binary**
#' when probabilities exist). Also returns variable importance:
#' raw (per dummy), top-N, and collapsed to parent variables, plus an
#' optional vip ggplot.
#'
#' @param train_df Data frame for training.
#' @param new_df Data frame to score (columns need not match; the recipe aligns them).
#' @param outcome Name of the outcome column in `train_df`.
#' @param mode "classification" or "regression".
#' @param v Number of CV folds (default 5).
#' @param grid_size Number of hyperparameter combinations (default 25).
#' @param normalize_numeric If TRUE, standardize numeric predictors.
#' @param class_imbalance "auto" or "none" (binary classification only). "auto"
#'   passes `scale_pos_weight = #neg/#pos` to xgboost (positive = second factor level).
#' @param seed RNG seed.
#' @param top_n_vi Integer; number of features to show in `vi_top` (default 20).
#' @param collapse_regex Regex used to collapse one-hot dummy names back to
#'   a parent variable in `vi_parent_top`. By default, everything before the
#'   first `_` or `:` is treated as the parent: `"[:_].*$"`.
#' @param return_vip_plot Logical; if TRUE, returns a `vip_plot` ggplot object
#'   with `vip::vip(..., num_features = top_n_vi)`.
#'
#' @return List with:
#' \itemize{
#'   \item \code{outcome}, \code{mode}
#'   \item \code{resamples}, \code{tuned_results}, \code{best_params}, \code{cv_summary}
#'   \item \code{workflow_final} (fitted workflow)
#'   \item \code{train_predictions}, \code{new_predictions}
#'   \item \code{metrics_train}, \code{metrics_new}  (classification only; \code{metrics_new} is \code{NULL} if \code{new_df} lacks \code{outcome})
#'   \item \code{conf_mat_train}, \code{conf_mat_new} (classification only; \code{conf_mat_new} is \code{NULL} if \code{new_df} lacks \code{outcome})
#'   \item \code{vi_raw}, \code{vi_top}, \code{vi_parent_top}, \code{vip_plot}
#' }
#'
#' @examples
#' \donttest{
#' if (requireNamespace("modeldata", quietly = TRUE)) {
#'   modeldata::attrition -> dat
#'   set.seed(42)
#'   sp <- rsample::initial_split(dat, prop = 0.8, strata = "Attrition")
#'   tr <- rsample::training(sp); te <- rsample::testing(sp)
#'   res <- run_xgb_tidymodels_tuned(
#'     train_df = tr, new_df = te, outcome = "Attrition",
#'     mode = "classification", v = 5, grid_size = 30,
#'     class_imbalance = "auto", top_n_vi = 20, return_vip_plot = TRUE
#'   )
#'   res$conf_mat_new
#'   res$metrics_new
#'   utils::head(res$vi_top)
#'   utils::head(res$vi_parent_top)
#'   if (!is.null(res$vip_plot)) print(res$vip_plot)
#' }
#' }
#' @export
run_xgb_tidymodels_tuned <- function(
    train_df,
    new_df,
    outcome,
    mode = c("regression", "classification"),
    v = 5,
    grid_size = 25,
    normalize_numeric = FALSE,
    class_imbalance = c("auto", "none"),
    seed = 123,
    top_n_vi = 20,
    collapse_regex = "[:_].*$",
    return_vip_plot = FALSE
) {
  mode <- base::match.arg(mode)
  class_imbalance <- base::match.arg(class_imbalance)
  
  if (!base::is.data.frame(train_df) || !base::is.data.frame(new_df)) {
    base::stop("`train_df` and `new_df` must be data frames.")
  }
  if (!base::is.character(outcome) || length(outcome) != 1L || !outcome %in% base::names(train_df)) {
    base::stop("`outcome` must be the name of a column in `train_df`.")
  }
  
  # Outcome checks
  if (base::identical(mode, "classification")) {
    if (!base::is.factor(train_df[[outcome]])) train_df[[outcome]] <- base::as.factor(train_df[[outcome]])
    train_df[[outcome]] <- base::droplevels(train_df[[outcome]])
    if (base::nlevels(train_df[[outcome]]) < 2) base::stop("Classification requires at least 2 outcome levels.")
  } else if (!base::is.numeric(train_df[[outcome]])) {
    base::stop("For regression, the outcome must be numeric.")
  }
  
  predictors <- base::setdiff(base::names(train_df), outcome)
  fml <- stats::as.formula(base::paste(outcome, "~", base::paste(predictors, collapse = " + ")))
  
  # Recipe
  rec <- recipes::recipe(fml, data = train_df) |>
    recipes::step_string2factor(recipes::all_nominal_predictors()) |>
    recipes::step_nzv(recipes::all_predictors()) |>
    recipes::step_impute_median(recipes::all_numeric_predictors()) |>
    recipes::step_impute_mode(recipes::all_nominal_predictors()) |>
    recipes::step_other(recipes::all_nominal_predictors(), threshold = 0.005, other = "other") |>
    recipes::step_unknown(recipes::all_nominal_predictors(), new_level = ".missing") |>
    recipes::step_novel(  recipes::all_nominal_predictors(), new_level = ".novel") |>
    recipes::step_dummy(recipes::all_nominal_predictors(), one_hot = TRUE)
  
  if (base::isTRUE(normalize_numeric)) {
    rec <- rec |> recipes::step_normalize(recipes::all_numeric_predictors())
  }
  
  # Engine args (threads, imbalance)
  engine_args <- base::list(nthread = base::max(1L, parallel::detectCores() - 1L))
  if (base::identical(mode, "classification") &&
      base::identical(class_imbalance, "auto") &&
      base::nlevels(train_df[[outcome]]) == 2) {
    tab <- base::table(train_df[[outcome]])
    spw <- base::as.numeric(tab[1] / tab[2])  # positive = 2nd level
    if (base::is.finite(spw) && spw > 0) engine_args$scale_pos_weight <- spw
  }
  
  # Model spec
  spec <- parsnip::boost_tree(
    mode           = mode,
    trees          = parsnip::tune(),
    learn_rate     = parsnip::tune(),
    tree_depth     = parsnip::tune(),
    mtry           = parsnip::tune(),
    sample_size    = parsnip::tune(),
    loss_reduction = parsnip::tune(),
    min_n          = parsnip::tune()
  )
  spec <- base::do.call(parsnip::set_engine, c(base::list(object = spec, engine = "xgboost"), engine_args))
  
  wf <- workflows::workflow() |>
    workflows::add_recipe(rec) |>
    workflows::add_model(spec)
  
  # Grid (space-filling; dials >= 1.3.0)
  mtry_final <- dials::finalize(dials::mtry(), train_df[, predictors, drop = FALSE])
  
  base::set.seed(seed)
  grid <- dials::grid_space_filling(
    dials::trees(c(300L, 2000L)),
    dials::learn_rate(c(-3.5, -0.5)),   # log10 scale ~ [0.0003, 0.316]
    dials::tree_depth(c(3L, 10L)),
    mtry_final,
    dials::sample_prop(c(0.5, 1.0)),
    dials::loss_reduction(c(-6, 3)),    # log10 gamma ~ [1e-6, 1e3]
    dials::min_n(c(1L, 40L)),
    size = grid_size
  )
  
  strata_arg <- if (base::identical(mode, "classification")) outcome else NULL
  rs <- rsample::vfold_cv(train_df, v = v, strata = strata_arg)
  
  metrics <- if (base::identical(mode, "regression")) {
    yardstick::metric_set(yardstick::rmse, yardstick::rsq)
  } else {
    yardstick::metric_set(yardstick::roc_auc, yardstick::accuracy)
  }
  
  ctrl <- tune::control_grid(save_pred = TRUE)
  
  base::set.seed(seed)
  tuned <- tune::tune_grid(
    wf,
    resamples = rs,
    grid = grid,
    metrics = metrics,
    control = ctrl
  )
  
  best <- if (base::identical(mode, "regression")) {
    tune::select_best(tuned, metric = "rmse")
  } else {
    tune::select_best(tuned, metric = "roc_auc")
  }
  
  final_wf <- tune::finalize_workflow(wf, best)
  
  base::set.seed(seed)
  final_fit <- parsnip::fit(final_wf, data = train_df)
  
  # ---- Predictions (stats::predict to avoid non-exported generics) ----
  pred_train_class <- if (base::identical(mode, "classification")) {
    tibble::as_tibble(stats::predict(final_fit, new_data = train_df, type = "class"))
  } else NULL
  pred_train_prob  <- if (base::identical(mode, "classification")) {
    base::tryCatch(tibble::as_tibble(stats::predict(final_fit, new_data = train_df, type = "prob")),
                   error = function(e) NULL)
  } else NULL
  pred_train_reg   <- if (base::identical(mode, "regression")) {
    tibble::as_tibble(stats::predict(final_fit, new_data = train_df))
  } else NULL
  
  pred_new_class <- if (base::identical(mode, "classification")) {
    tibble::as_tibble(stats::predict(final_fit, new_data = new_df, type = "class"))
  } else NULL
  pred_new_prob  <- if (base::identical(mode, "classification")) {
    base::tryCatch(tibble::as_tibble(stats::predict(final_fit, new_data = new_df, type = "prob")),
                   error = function(e) NULL)
  } else NULL
  pred_new_reg   <- if (base::identical(mode, "regression")) {
    tibble::as_tibble(stats::predict(final_fit, new_data = new_df))
  } else NULL
  
  train_predictions <- if (base::identical(mode, "classification")) {
    out <- pred_train_class
    if (!base::is.null(pred_train_prob)) out <- dplyr::bind_cols(out, pred_train_prob)
    out
  } else {
    pred_train_reg
  }
  new_predictions <- if (base::identical(mode, "classification")) {
    out <- pred_new_class
    if (!base::is.null(pred_new_prob)) out <- dplyr::bind_cols(out, pred_new_prob)
    out
  } else {
    pred_new_reg
  }
  
  # ---- Metrics + confusion matrix (classification only) ----
  metrics_train <- NULL; metrics_new <- NULL
  conf_mat_train <- NULL; conf_mat_new <- NULL
  
  if (base::identical(mode, "classification")) {
    truth_train <- train_df[[outcome]]
    
    # Build evaluation frame for train
    class_col_train <- if (".pred_class" %in% base::names(train_predictions)) ".pred_class" else base::names(train_predictions)[1]
    eval_train <- tibble::tibble(truth = truth_train, estimate = train_predictions[[class_col_train]])
    
    # Compute 8 key metrics for train (set event_level="second" where applicable)
    metrics_train <- dplyr::bind_rows(
      yardstick::accuracy(eval_train, truth = truth, estimate = estimate),
      yardstick::kap(eval_train,      truth = truth, estimate = estimate),
      yardstick::sens(eval_train,     truth = truth, estimate = estimate, event_level = "second"),
      yardstick::spec(eval_train,     truth = truth, estimate = estimate, event_level = "second"),
      yardstick::precision(eval_train, truth = truth, estimate = estimate, event_level = "second"),
      yardstick::recall(eval_train,    truth = truth, estimate = estimate, event_level = "second"),
      yardstick::f_meas(eval_train,    truth = truth, estimate = estimate, event_level = "second"),
      yardstick::bal_accuracy(eval_train, truth = truth, estimate = estimate)
    )
    
    # Add AUCs for binary if probs exist (yardstick >= 1.3.x expects bare columns)
    if (!base::is.null(pred_train_prob) && base::nlevels(truth_train) == 2L) {
      pos_lvl <- base::levels(truth_train)[2]  # tidymodels event = second level
      prob_col_train <- base::paste0(".pred_", pos_lvl)
      if (prob_col_train %in% base::names(train_predictions)) {
        df_train <- tibble::tibble(truth = truth_train,
                                   pred  = train_predictions[[prob_col_train]])
        auc_train <- yardstick::roc_auc(df_train, truth, pred, event_level = "second")
        pr_train  <- yardstick::pr_auc(df_train,  truth, pred, event_level = "second")
        metrics_train <- dplyr::bind_rows(metrics_train, auc_train, pr_train)
      }
    }
    
    # Confusion matrix for train
    conf_mat_train <- yardstick::conf_mat(eval_train, truth = truth, estimate = estimate)
    
    # ---- Test/NEW metrics only if outcome exists in new_df ----
    if (outcome %in% base::names(new_df)) {
      truth_new <- new_df[[outcome]]
      if (!base::is.factor(truth_new)) truth_new <- base::factor(truth_new, levels = base::levels(truth_train))
      # Build evaluation for new
      class_col_new <- if (".pred_class" %in% base::names(new_predictions)) ".pred_class" else base::names(new_predictions)[1]
      eval_new <- tibble::tibble(truth = truth_new, estimate = new_predictions[[class_col_new]])
      
      metrics_new <- dplyr::bind_rows(
        yardstick::accuracy(eval_new, truth = truth, estimate = estimate),
        yardstick::kap(eval_new,      truth = truth, estimate = estimate),
        yardstick::sens(eval_new,     truth = truth, estimate = estimate, event_level = "second"),
        yardstick::spec(eval_new,     truth = truth, estimate = estimate, event_level = "second"),
        yardstick::precision(eval_new, truth = truth, estimate = estimate, event_level = "second"),
        yardstick::recall(eval_new,    truth = truth, estimate = estimate, event_level = "second"),
        yardstick::f_meas(eval_new,    truth = truth, estimate = estimate, event_level = "second"),
        yardstick::bal_accuracy(eval_new, truth = truth, estimate = estimate)
      )
      
      # AUCs for binary
      if (!base::is.null(pred_new_prob) && base::nlevels(truth_new) == 2L) {
        pos_lvl <- base::levels(truth_new)[2]
        prob_col_new <- base::paste0(".pred_", pos_lvl)
        if (prob_col_new %in% base::names(new_predictions)) {
          df_new <- tibble::tibble(truth = truth_new,
                                   pred  = new_predictions[[prob_col_new]])
          auc_new <- yardstick::roc_auc(df_new, truth, pred, event_level = "second")
          pr_new  <- yardstick::pr_auc(df_new,  truth, pred, event_level = "second")
          metrics_new <- dplyr::bind_rows(metrics_new, auc_new, pr_new)
        }
      }
      
      conf_mat_new <- yardstick::conf_mat(eval_new, truth = truth, estimate = estimate)
    }
  }
  
  # ---- CV summary & variable importance ----
  cv_summary <- tune::collect_metrics(tuned)
  cv_summary <- dplyr::arrange(cv_summary, .metric, mean)
  
  vi_raw <- NULL
  vip_plot <- NULL
  base::try({
    fitted_booster <- workflows::extract_fit_parsnip(final_fit)$fit
    vi_raw <- vip::vi(fitted_booster) |> tibble::as_tibble()
    if (return_vip_plot) {
      vip_plot <- vip::vip(fitted_booster, num_features = top_n_vi)
    }
  }, silent = TRUE)
  
  vi_top <- NULL
  if (!base::is.null(vi_raw) && "Importance" %in% base::names(vi_raw)) {
    vi_top <- dplyr::slice_max(vi_raw, order_by = Importance, n = top_n_vi)
  }
  
  vi_parent_top <- NULL
  if (!base::is.null(vi_raw) && "Variable" %in% base::names(vi_raw) && "Importance" %in% base::names(vi_raw)) {
    vi_parent_top <- vi_raw |>
      dplyr::mutate(parent = base::sub(collapse_regex, "", Variable)) |>
      dplyr::group_by(parent) |>
      dplyr::summarise(Importance = base::sum(Importance), .groups = "drop") |>
      dplyr::arrange(dplyr::desc(Importance)) |>
      dplyr::slice_head(n = top_n_vi)
  }
  
  # Return
  base::list(
    outcome = outcome,
    mode = mode,
    resamples = rs,
    tuned_results = tuned,
    best_params = best,
    cv_summary = cv_summary,
    workflow_final = final_wf,
    train_predictions = train_predictions,
    new_predictions = new_predictions,
    metrics_train = metrics_train,
    metrics_new = metrics_new,
    conf_mat_train = conf_mat_train,
    conf_mat_new = conf_mat_new,
    vi_raw = vi_raw,
    vi_top = vi_top,
    vi_parent_top = vi_parent_top,
    vip_plot = vip_plot
  )
}
