#' Create Stratified Sample
#'
#' This function performs stratified random sampling on a given dataframe based on specified variables, sample size, and tolerance level.
#'
#' @param data A dataframe containing the population data.
#' @param stratify_vars A character vector specifying the names of the variables to stratify on.
#' @param total_sample_size An integer specifying the total number of samples to pull.
#' @param tolerance A numeric value specifying the allowed deviation from the sample proportion (in percentage points).
#'
#' @return A list containing the stratified random sample, a summary of proportions in the population and sample, and suggestions for the next pull.
#' Returns NULL if an error occurs with a message to try a different sample size.
#' @export
create_stratified_sample <- function(data, stratify_vars, total_sample_size, tolerance = 3) {
  tryCatch({
    # Create strata
    data <- data %>%
      dplyr::mutate(strata = interaction(!!!dplyr::syms(stratify_vars), sep = "_"))
    
    # Calculate initial sample sizes
    proportions <- data %>%
      dplyr::group_by(strata) %>%
      dplyr::summarise(count = dplyr::n(), .groups = 'drop') %>%
      dplyr::mutate(proportion = count / sum(count),
                    sample_size = round(proportion * total_sample_size)) %>%
      dplyr::ungroup()
    
    # Adjust sample sizes to ensure they sum up to total_sample_size
    difference <- total_sample_size - sum(proportions$sample_size)
    if (difference != 0) {
      proportions <- proportions %>%
        dplyr::arrange(dplyr::desc(proportion)) %>%
        dplyr::mutate(sample_size = dplyr::if_else(difference > 0 & dplyr::row_number() == 1, sample_size + difference,
                                                   dplyr::if_else(difference < 0 & dplyr::row_number() == dplyr::n(), sample_size + difference, sample_size)))
    }
    
    resample <- TRUE
    max_attempts <- 10
    attempts <- 0
    
    while (resample && attempts < max_attempts) {
      attempts <- attempts + 1
      
      # Perform stratified sampling
      sampled_data <- proportions %>%
        dplyr::group_by(strata) %>%
        dplyr::group_modify(~ {
          dplyr::sample_n(dplyr::filter(data, strata == .y$strata), .x$sample_size) %>%
            dplyr::select(-strata)
        }) %>%
        dplyr::ungroup()
      
      # Check proportionality for combined strata
      population_proportions <- data %>%
        dplyr::group_by(strata) %>%
        dplyr::summarise(count = dplyr::n(), .groups = 'drop') %>%
        dplyr::mutate(proportion = count / sum(count)) %>%
        dplyr::select(strata, population_count = count, population_proportion = proportion)
      
      sample_proportions <- sampled_data %>%
        dplyr::mutate(strata = interaction(!!!dplyr::syms(stratify_vars), sep = "_")) %>%
        dplyr::group_by(strata) %>%
        dplyr::summarise(count = dplyr::n(), .groups = 'drop') %>%
        dplyr::mutate(proportion = count / sum(count)) %>%
        dplyr::select(strata, sample_count = count, sample_proportion = proportion)
      
      proportionality_check <- dplyr::left_join(population_proportions, sample_proportions, by = "strata") %>%
        dplyr::mutate(difference = sample_proportion - population_proportion,
                      suggestion = dplyr::case_when(
                        difference > tolerance / 100 ~ "Pull fewer",
                        difference < -tolerance / 100 ~ "Pull more",
                        TRUE ~ "Proportionate"
                      ))
      
      # Adjust sample sizes based on the suggestions
      proportions <- proportions %>%
        dplyr::left_join(proportionality_check %>% dplyr::select(strata, suggestion), by = "strata") %>%
        dplyr::mutate(sample_size = case_when(
          suggestion == "Pull fewer" ~ pmax(sample_size - 1, 1),
          suggestion == "Pull more" ~ sample_size + 1,
          TRUE ~ sample_size
        )) %>%
        dplyr::select(-suggestion)
      
      if (all(proportionality_check$suggestion == "Proportionate")) {
        resample <- FALSE
      }
    }
    
    # Check proportionality for individual stratifying variables
    individual_checks <- lapply(stratify_vars, function(var) {
      population_individual <- data %>%
        dplyr::group_by(!!dplyr::sym(var)) %>%
        dplyr::summarise(count = dplyr::n(), .groups = 'drop') %>%
        dplyr::mutate(proportion = count / sum(count)) %>%
        dplyr::select(!!dplyr::sym(var), population_count = count, population_proportion = proportion)
      
      sample_individual <- sampled_data %>%
        dplyr::group_by(!!dplyr::sym(var)) %>%
        dplyr::summarise(count = dplyr::n(), .groups = 'drop') %>%
        dplyr::mutate(proportion = count / sum(count)) %>%
        dplyr::select(!!dplyr::sym(var), sample_count = count, sample_proportion = proportion)
      
      dplyr::left_join(population_individual, sample_individual, by = var) %>%
        dplyr::mutate(variable = var, .before = 1)
    })
    
    return(list(sample = sampled_data, proportionality_check = proportionality_check, individual_checks = individual_checks))
  }, error = function(e) {
    message("Try a different sample size.")
    return(NULL)
  })
}
