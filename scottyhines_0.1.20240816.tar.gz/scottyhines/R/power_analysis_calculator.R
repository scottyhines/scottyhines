#' Power Analysis Calculator for Various Statistical Tests
#'
#' This function performs a power analysis calculation for various statistical tests, including regression models.
#' Users can calculate the required sample size, power, or effect size based on the other two parameters.
#'
#' @param test_type A character string specifying the type of test. Options are `"t_test"`, `"anova"`, `"correlation"`, `"proportion"`, or `"regression"`.
#' @param effect_size Numeric value for the effect size. For regression, this is Cohen's f². For ANOVA, this is Cohen's f.
#' @param sample_size Numeric value for the sample size. Leave as NULL if you want to calculate this.
#' @param power Numeric value for the desired power (1 - beta). Leave as NULL if you want to calculate this.
#' @param sig_level Numeric value for the significance level (alpha), with a default value of 0.05.
#' @param num_predictors Numeric value for the number of predictors in the regression model (required if `test_type` is `"regression"`).
#' @param k Numeric value for the number of groups in the ANOVA (required if `test_type` is `"anova"`).
#' 
#' @return A list containing the results of the power analysis, including the calculated parameter. If `test_type` is `"regression"`, it also includes the calculated sample size.
#' 
#' @examples
#' # Calculate sample size needed for a regression with an effect size of 0.5, power of 0.8, and 3 predictors
#' power_analysis_calculator(test_type = "regression", effect_size = 0.5, power = 0.8, num_predictors = 3)
#' 
#' # Calculate sample size needed for an ANOVA with an effect size of 0.5, power of 0.8, and 3 groups
#' power_analysis_calculator(test_type = "anova", effect_size = 0.5, power = 0.8, k = 3)
#' 
#' @importFrom pwr pwr.t.test pwr.anova.test pwr.r.test pwr.2p.test pwr.f2.test
#' @export
power_analysis_calculator <- function(test_type, 
                                      effect_size = NULL, 
                                      sample_size = NULL, 
                                      power = NULL, 
                                      sig_level = 0.05,
                                      num_predictors = NULL,
                                      k = NULL) { 
  # Input validation
  if(sum(!is.null(effect_size), !is.null(sample_size), !is.null(power)) != 2) {
    stop("You must specify exactly two of the three parameters: effect_size, sample_size, power.")
  }
  
  if(test_type == "regression" & is.null(num_predictors)) {
    stop("You must specify the number of predictors for a regression power analysis.")
  }
  
  if(test_type == "anova" & is.null(k)) {
    stop("You must specify the number of groups (k) for an ANOVA power analysis.")
  }
  
  # Run power analysis based on the type of test
  result <- switch(test_type,
                   "t_test" = pwr::pwr.t.test(d = effect_size, n = sample_size, power = power, sig.level = sig_level),
                   "anova" = {
                     if (is.null(sample_size)) {
                       pwr::pwr.anova.test(k = k, f = effect_size, power = power, sig.level = sig_level)
                     } else {
                       pwr::pwr.anova.test(k = k, f = effect_size, n = sample_size, sig.level = sig_level)
                     }
                   },
                   "correlation" = pwr::pwr.r.test(r = effect_size, n = sample_size, power = power, sig.level = sig_level),
                   "proportion" = pwr::pwr.2p.test(h = effect_size, n = sample_size, power = power, sig.level = sig_level),
                   "regression" = {
                     if (is.null(sample_size)) {
                       temp_result <- pwr::pwr.f2.test(u = num_predictors, f2 = effect_size, power = power, sig.level = sig_level)
                       sample_size <- ceiling(temp_result$v + num_predictors + 1)
                       list(result = temp_result, sample_size = sample_size)
                     } else {
                       v <- sample_size - num_predictors - 1
                       list(result = pwr::pwr.f2.test(u = num_predictors, v = v, f2 = effect_size, sig.level = sig_level), 
                            sample_size = sample_size)
                     }
                   },
                   stop("Invalid test type. Use 't_test', 'anova', 'correlation', 'proportion', or 'regression'.")
  )
  
  # Return the result
  return(result)
}
