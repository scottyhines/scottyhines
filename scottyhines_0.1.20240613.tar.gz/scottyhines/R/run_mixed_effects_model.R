#' A Function to Run Mixed-Effects Model Analysis
#'
#' This function performs mixed-effects model analysis on a given dataset. It allows for the specification of multiple outcome variables, control variables (if any), and variables of interest. The function returns a dataframe summarizing the analysis for each variable of interest, including estimates, standard errors, t-values, p-values, and means at each time point.
#'
#' @param data The dataset as a dataframe.
#' @param outcome_vars A character vector specifying the names of the outcome variables.
#' @param control_vars An optional character vector specifying control variables in the model. If provided, these variables are included in the model as additional fixed effects.
#' @param interest_vars A character vector specifying the variables of interest that will be individually added to the base model for analysis.
#' @param random_effects A string specifying the random effects structure (e.g., "(1 | subject)"). 
#' Notes on random effects structure:
#'  - Different Grouping Levels: If your data includes repeated measures for subjects, you might use (1 | subject).
#'  - Clusters or Groups: If your data is clustered (e.g., students within classrooms, patients within hospitals), you might use (1 | cluster) or (1 | group).
#'  - Nested Designs: If your grouping factors are nested (e.g., students within classrooms within schools), you might use (1 | school/classroom/subject).
#'  - Crossed Designs: If your factors are crossed (e.g., subjects rated by multiple raters), you might use (1 | subject) + (1 | rater).
#'  - Random Slopes: If you suspect that the effect of a predictor varies across levels of the grouping factor, you might include random slopes. For example, (1 + predictor | subject) allows the effect of predictor to vary by subject.
#'  - Complex Random Effects Structures: For both random intercepts and slopes, you might use (1 + predictor | subject). If you believe there is a correlation between random intercepts and slopes, you might use (1 + predictor || subject) to fit an uncorrelated model.
#'  - Model Fit and Comparison: Use AIC/BIC or likelihood ratio tests to compare models with different random effects structures.
#'  - Convergence Issues: Complex random effects structures may lead to convergence problems, requiring simpler models or alternative fitting algorithms.
#' @return A dataframe summarizing the mixed-effects model analysis for each variable of interest. This summary includes regression coefficients, standard errors, t-statistics, p-values, and mean values of the outcome variable at each time point.
#' @export
run_mixed_effects_model <- function(data, outcome_vars, control_vars = NULL, interest_vars, random_effects) {
  library(lme4)
  library(lmerTest)
  library(broom.mixed)
  library(dplyr)
  library(tidyr)
  
  options(warn = -1)
  final_summary <- list()
  
  for (outcome_var in outcome_vars) {
    for (variable in interest_vars) {
      base_formula <- paste(outcome_var, "~", variable)
      if (!is.null(control_vars) && length(control_vars) > 0) {
        base_formula <- paste(base_formula, "+", paste(control_vars, collapse = " + "))
      }
      complete_formula_str <- paste(base_formula, "+", random_effects)
      formula <- as.formula(complete_formula_str)
      
      # Fit the mixed-effects model
      model <- lmer(formula, data = data)
      
      # Get a cleaner model summary
      tidy_model <- tidy(model, effects = "fixed")
      
      # Add the variable name and outcome variable to the summary for clarity
      tidy_model$variable_of_interest <- variable
      tidy_model$outcome_variable <- outcome_var
      
      # Calculate means of the outcome variable at each time point
      means <- data %>%
        group_by(!!sym(variable)) %>%
        summarize(mean = mean(!!sym(outcome_var), na.rm = TRUE)) %>%
        pivot_wider(names_from = !!sym(variable), values_from = mean, names_prefix = "mean_") %>%
        mutate(outcome_variable = outcome_var, variable_of_interest = variable)
      
      # Combine the tidy model with means
      combined_summary <- left_join(tidy_model, means, by = c("outcome_variable", "variable_of_interest"))
      
      # Store the summary in the list
      final_summary[[paste(outcome_var, variable, sep = "_")]] <- combined_summary
    }
  }
  
  final_combined_summary <- do.call(rbind, final_summary)
  options(warn = 0)
  return(final_combined_summary)
}
