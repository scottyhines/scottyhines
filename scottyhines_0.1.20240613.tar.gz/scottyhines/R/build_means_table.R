#' Build a summary table with means and counts for specified variables within each group.
#'
#' @param df A data frame containing the data to summarize.
#' @param group_var The name of the variable to group by (as a string).
#' @param vars A vector of variable names to calculate the summaries for.
#'
#' @return A wide-format data frame where each group's mean and count for each variable is a separate column.
#' @export
build_means_table <- function(df, group_var, vars) {
  # Convert group_var to symbol and ensure vars is treated correctly
  group_var_sym <- rlang::ensym(group_var)
  # Calculate means for each variable within each group
  means_df <- df %>%
    dplyr::group_by(!!group_var_sym) %>%
    dplyr::summarise(dplyr::across(all_of(vars), ~mean(.x, na.rm = TRUE)), .groups = 'drop')
  # Calculate the count of group
  counts_df <- df %>%
    dplyr::group_by(!!group_var_sym) %>%
    dplyr::summarise(N = n())
  # Rename counts columns
  names(counts_df)[-1] <- paste0(names(counts_df)[-1], "_n")
  # Merge the means and counts dataframes
  summary_df <- dplyr::inner_join(means_df, counts_df, by = as.character(group_var_sym))
  # Pivot the data to a wide format with groups as column headers
  wide_df <- tidyr::pivot_longer(summary_df, cols = -!!group_var_sym, names_to = "variable", values_to = "value") %>%
    tidyr::pivot_wider(names_from = !!group_var_sym, values_from = value) %>%
    dplyr::arrange(desc(grepl("_n$", variable))) %>%
    dplyr::mutate(variable = gsub("_n$", "", variable))
  return(wide_df)
}
