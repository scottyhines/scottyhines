#' Create Fake Data for Analysis
#'
#' Generates a synthetic dataset with demographic information, attitude
#' measures (Likert 1-5), network centrality metrics, and qualitative
#' feedback. Unlike a pure noise simulation, this data is generated from a
#' known causal structure so the package's analysis functions detect real,
#' interpretable signal. The latent process baked in:
#' \itemize{
#'   \item \strong{Tenure / job level} shift overall attitudes (longer tenure and
#'     higher level produce stronger work ethic and adaptability).
#'   \item \strong{Mediation chain:} \code{attitude_leadership -> attitude_communication
#'     -> attitude_work_ethic} (path a and path b are both non-zero).
#'   \item \strong{Moderation:} \code{attitude_teamwork * attitude_persistence}
#'     interacts on \code{attitude_work_ethic} (positive interaction term).
#'   \item \strong{Group differences:} \code{demo_region_code} shifts
#'     \code{attitude_creativity} and \code{attitude_innovation}, so ANOVAs
#'     and group-mean tables find significant differences.
#'   \item \strong{Performance:} \code{demo_performance} is driven by work ethic,
#'     adaptability, and tenure plus noise.
#'   \item \strong{Attrition:} binary outcome generated from a logistic function
#'     of low work ethic, low communication, and region-level intercepts.
#'   \item \strong{Network metrics:} \code{network_degree}, \code{network_betweenness},
#'     \code{network_closeness}, and \code{network_eigenvector} are correlated
#'     with \code{attitude_communication}.
#' }
#' Likert measures stay as integers 1-5, demographics, attrition, network
#' metrics, and qualitative feedback keep their classes and ranges, so any
#' existing code that consumed the previous version of this function will
#' continue to work.
#'
#' @param n The number of observations to generate. Defaults to 2000.
#' @param seed Optional integer for reproducibility. Defaults to NULL (no seed set).
#' @return A data.frame with id, demographics, Likert attitudes, network
#'   centrality measures, and qualitative feedback columns.
#' @export
create_fake_data <- function(n = 2000, seed = NULL) {
  if (!is.null(seed)) set.seed(seed)

  # Helper: take a continuous latent score and bin it into a 1-5 Likert int.
  # Internally re-scales the score so values land sensibly across the 1-5 range.
  to_likert <- function(z) {
    # Roughly center around 3 and spread across 1-5 using empirical scaling.
    z_scaled <- 3 + 1.2 * (z - mean(z, na.rm = TRUE)) / stats::sd(z, na.rm = TRUE)
    out <- round(z_scaled)
    out[out < 1] <- 1
    out[out > 5] <- 5
    as.integer(out)
  }

  inv_logit <- function(x) 1 / (1 + exp(-x))

  # ----- Demographics ----------------------------------------------------
  id <- seq_len(n)
  demo_job_level <- factor(sample(1:5, n, replace = TRUE,
                                  prob = c(0.30, 0.28, 0.22, 0.13, 0.07)))
  job_level_num  <- as.numeric(as.character(demo_job_level))

  # Tenure correlated with job level: higher level -> longer tenure on average
  demo_tenure <- pmin(100, pmax(1,
                                runif(n, min = 1, max = 100) +
                                  6 * (job_level_num - 3) +
                                  rnorm(n, sd = 5)))

  demo_region_code <- sample(c("north", "south", "east", "west"), n,
                             replace = TRUE,
                             prob = c(0.30, 0.25, 0.25, 0.20))
  region_idx <- match(demo_region_code, c("north", "south", "east", "west"))

  # Region-level shifts that flow into a couple of attitudes (drives ANOVA signal)
  region_creativity_shift <- c(north =  0.40, south = -0.30, east =  0.10, west = -0.20)[demo_region_code]
  region_innovation_shift <- c(north =  0.30, south = -0.20, east = -0.10, west =  0.00)[demo_region_code]
  region_attrition_shift  <- c(north = -0.20, south =  0.30, east = -0.10, west =  0.00)[demo_region_code]

  # ----- Latent person-level engagement --------------------------------
  # Standardised proxies for tenure and job level
  tenure_z   <- as.numeric(scale(demo_tenure))
  joblvl_z   <- as.numeric(scale(job_level_num))

  # Latent traits driving the attitude block
  latent_engagement <- 0.30 * tenure_z + 0.25 * joblvl_z + rnorm(n, sd = 1)
  latent_indep      <- rnorm(n, sd = 1)  # independent personality factor

  # ----- Attitudes -------------------------------------------------------
  # Persistence: independent moderator
  z_persistence <- 0.20 * latent_engagement + 0.80 * rnorm(n)
  attitude_persistence <- to_likert(z_persistence)
  persistence_z <- as.numeric(scale(z_persistence))

  # Innovation: independent-ish, region-shifted
  z_innovation <- 0.15 * latent_engagement + region_innovation_shift + 0.85 * rnorm(n)
  attitude_innovation <- to_likert(z_innovation)

  # Leadership: tied to job level, drives the mediation chain
  z_leadership <- 0.40 * joblvl_z + 0.20 * latent_engagement + 0.70 * rnorm(n)
  attitude_leadership <- to_likert(z_leadership)
  leadership_z <- as.numeric(scale(z_leadership))

  # Communication: mediator -- driven by leadership
  z_communication <- 0.50 * leadership_z + 0.20 * latent_engagement + 0.65 * rnorm(n)
  attitude_communication <- to_likert(z_communication)
  communication_z <- as.numeric(scale(z_communication))

  # Teamwork: correlated with communication
  z_teamwork <- 0.45 * communication_z + 0.20 * latent_engagement + 0.70 * rnorm(n)
  attitude_teamwork <- to_likert(z_teamwork)
  teamwork_z <- as.numeric(scale(z_teamwork))

  # Creativity: region-shifted, partly tied to innovation
  z_creativity <- 0.30 * latent_indep + region_creativity_shift +
                  0.20 * (z_innovation - mean(z_innovation)) +
                  0.70 * rnorm(n)
  attitude_creativity <- to_likert(z_creativity)

  # Work ethic: outcome of the mediation chain + the moderation interaction
  # path a (leadership -> communication) and path b (communication -> work ethic)
  # are both > 0; the X*W product (teamwork * persistence) is also > 0
  z_work_ethic <- 0.45 * communication_z +
                  0.25 * teamwork_z +
                  0.25 * persistence_z +
                  0.30 * (teamwork_z * persistence_z) +
                  0.30 * tenure_z +
                  0.60 * rnorm(n)
  attitude_work_ethic <- to_likert(z_work_ethic)
  work_ethic_z <- as.numeric(scale(z_work_ethic))

  # Adaptability: driven by work ethic and creativity
  z_adaptability <- 0.40 * work_ethic_z +
                    0.20 * (z_creativity - mean(z_creativity)) +
                    0.20 * latent_engagement +
                    0.70 * rnorm(n)
  attitude_adaptability <- to_likert(z_adaptability)
  adaptability_z <- as.numeric(scale(z_adaptability))

  # ----- Performance (continuous-ish 1-5 outcome) -----------------------
  z_performance <- 0.45 * work_ethic_z +
                   0.30 * adaptability_z +
                   0.20 * tenure_z +
                   0.65 * rnorm(n)
  demo_performance <- to_likert(z_performance)

  # ----- Attrition (binary outcome) -------------------------------------
  # Higher work ethic and communication lower the probability of attrition;
  # region intercepts shift the base rate; overall ~20% attrition.
  attrition_logit <- -1.5 +
                     -0.80 * work_ethic_z +
                     -0.50 * communication_z +
                     -0.20 * tenure_z +
                     region_attrition_shift +
                     rnorm(n, sd = 0.4)
  attrition_prob <- inv_logit(attrition_logit)
  demo_attrition <- factor(stats::rbinom(n, size = 1, prob = attrition_prob),
                           levels = c(0, 1),
                           labels = c("No Attrition", "Attrition"))

  # ----- Network centrality (correlated with communication) -------------
  # Higher communicators tend to have more connections / higher centrality
  network_degree <- round(pmax(1, exp(log(10) + 0.30 * communication_z +
                                        rnorm(n, sd = 0.4))))
  network_betweenness <- pmax(0, 0.0005 + 0.0003 * communication_z +
                                rnorm(n, sd = 0.0003))
  network_closeness <- pmin(0.001, pmax(0.0001,
                                        runif(n, min = 0.0001, max = 0.001) +
                                          0.00005 * communication_z))
  network_eigenvector <- pmin(1, pmax(0,
                                      stats::rbeta(n, shape1 = 2, shape2 = 5) +
                                        0.05 * communication_z))

  # ----- Qualitative feedback -------------------------------------------
  positive_phrases <- c(
    "The project was well executed and met all expectations.",
    "I feel valued and appreciated in my role.",
    "Leadership provides clear direction and support.",
    "There are opportunities for growth and development.",
    "The team collaborates effectively and achieves great results.",
    "I enjoy the challenges and opportunities in my role."
  )
  negative_phrases <- c(
    "Communication within the team could be improved.",
    "The workload can be overwhelming at times.",
    "I would like more feedback on my performance.",
    "There is a lack of transparency in decision-making."
  )
  # Probability of a positive phrase rises with work ethic
  pos_prob <- inv_logit(work_ethic_z)
  pick_positive <- stats::rbinom(n, size = 1, prob = pos_prob) == 1
  qualitative_feedback <- ifelse(pick_positive,
                                 sample(positive_phrases, n, replace = TRUE),
                                 sample(negative_phrases, n, replace = TRUE))

  # ----- Assemble -------------------------------------------------------
  df <- data.frame(
    id, demo_job_level, demo_tenure, demo_region_code, demo_performance, demo_attrition,
    attitude_work_ethic, attitude_adaptability, attitude_creativity,
    attitude_persistence, attitude_teamwork, attitude_communication,
    attitude_leadership, attitude_innovation,
    network_degree, network_betweenness, network_closeness, network_eigenvector,
    qualitative_feedback,
    stringsAsFactors = FALSE
  )

  return(df)
}
