#' Run DAG Causal Discovery via the PC Algorithm
#'
#' Estimates a Directed Acyclic Graph (DAG) from numeric data using the
#' PC algorithm (Peter & Clark) with Gaussian conditional independence tests.
#' Returns directed edges, a visual DAG plot, and IDA-based causal effect
#' estimates for all variable pairs. Optionally performs community detection
#' and scales node size by causal effect magnitude.
#'
#' @param df A data frame. All numeric columns will be selected, scaled, and
#'   used as nodes in the DAG.
#' @param alpha Numeric. Significance level for conditional independence tests.
#'   Lower values produce sparser graphs (fewer edges). Default is \code{0.05}.
#' @param plot_title Character. Title displayed on the DAG plot.
#'   Default is \code{"DAG Causal Discovery"}.
#' @param scale_nodes Logical. If \code{TRUE}, node size is proportional to
#'   total outgoing causal effect (sum of absolute IDA effects). If
#'   \code{FALSE} (default), all nodes are the same size.
#' @param detect_communities Logical. If \code{TRUE}, runs Louvain community
#'   detection on the undirected skeleton and colors nodes by community. If
#'   \code{FALSE} (default), nodes cycle through the Flat UI palette.
#' @param max_node_size Numeric. Maximum node diameter in the plot. When
#'   \code{scale_nodes = TRUE}, nodes range from \code{max_node_size * 0.4}
#'   to \code{max_node_size}. When \code{scale_nodes = FALSE}, all nodes are
#'   drawn at \code{max_node_size * 0.67}. Default is \code{30}.
#' @param layout Character. Layout algorithm for node placement. One of
#'   \code{"fr"} (Fruchterman-Reingold, default), \code{"mds"}
#'   (multidimensional scaling), \code{"kk"} (Kamada-Kawai), \code{"circle"},
#'   or \code{"drl"} (DrL, for large networks).
#'
#' @return A named list:
#' \describe{
#'   \item{pc_fit}{The fitted \code{\link[pcalg]{pc}} object.}
#'   \item{dag_edges}{A data frame of directed edges (\code{from}, \code{to}).}
#'   \item{causal_effects}{A data frame of IDA-estimated causal effects
#'     (\code{from}, \code{to}, \code{effect}), sorted by descending
#'     absolute effect.}
#'   \item{out_communities}{(Only when \code{detect_communities = TRUE}) A
#'     tibble with columns \code{node} and \code{community}.}
#'   \item{out_modularity}{(Only when \code{detect_communities = TRUE})
#'     Numeric modularity score.}
#' }
#'
#' @details
#' The \code{alpha} parameter controls the sparsity-sensitivity tradeoff:
#' \itemize{
#'   \item \code{alpha = 0.01}: Conservative, fewer edges, higher confidence.
#'   \item \code{alpha = 0.05}: Balanced (default).
#'   \item \code{alpha = 0.10}: Liberal, more edges, more exploratory.
#' }
#'
#' @note
#' Requires Bioconductor package \pkg{graph}. Install with
#' \code{BiocManager::install("graph")} if not already available.
#'
#' @section Causal Effect Metrics:
#' \describe{
#'   \item{IDA Causal Effect}{Intervention-calculus when the DAG is Absent
#'     (Maathuis et al., 2009). Estimates the expected change in a target
#'     variable when an intervention sets a source variable to a specific
#'     value. Computed for all directed variable pairs from the PC-estimated
#'     CPDAG. Larger absolute values indicate stronger causal influence.}
#'   \item{Total Outgoing Effect}{Sum of absolute IDA effects from a node to
#'     all others. Used for \code{scale_nodes = TRUE} — nodes with larger
#'     total outgoing effect are drawn bigger, highlighting the most
#'     causally influential variables.}
#' }
#'
#' @section DAG Structure Metrics:
#' \describe{
#'   \item{Directed Edges}{Edges oriented by the PC algorithm using
#'     v-structures (colliders) and orientation rules. A directed edge
#'     X -> Y means X is a potential cause of Y.}
#'   \item{Undirected Edges}{Edges the algorithm could not orient — the
#'     causal direction is ambiguous given the data.}
#' }
#'
#' @section References:
#' \itemize{
#'   \item Maathuis, M. H., Kalisch, M., & Buhlmann, P. (2009). Estimating
#'     high-dimensional intervention effects from observational data.
#'     \emph{Annals of Statistics}, 37(6A), 3133--3164.
#'   \item Spirtes, P., Glymour, C., & Scheines, R. (2000). \emph{Causation,
#'     Prediction, and Search} (2nd ed.). MIT Press.
#'   \item Kalisch, M. & Buhlmann, P. (2007). Estimating high-dimensional
#'     directed acyclic graphs with the PC-algorithm. \emph{Journal of
#'     Machine Learning Research}, 8, 613--636.
#' }
#'
#' @examples
#' \dontrun{
#' # Simple DAG
#' result <- run_dag_discovery(survey_data, alpha = 0.05)
#'
#' # With community detection and scaled nodes
#' result <- run_dag_discovery(survey_data, alpha = 0.05,
#'   detect_communities = TRUE, scale_nodes = TRUE)
#' }
#'
#' @seealso \code{\link{run_causal_attitude_network}} for undirected network
#'   estimation via GGM/EBICglasso.
#'
#' @importFrom pcalg pc gaussCItest ida
#' @importFrom igraph graph_from_adjacency_matrix layout_with_fr V E vcount
#'   as_undirected cluster_louvain membership modularity as_data_frame
#' @importFrom grDevices adjustcolor
#' @importFrom scales rescale
#' @importFrom dplyr select mutate filter arrange rowwise ungroup desc
#' @importFrom tibble tibble
#' @export
run_dag_discovery <- function(df, alpha = 0.05,
                              plot_title = "DAG Causal Discovery",
                              scale_nodes = FALSE,
                              detect_communities = FALSE,
                              max_node_size = 30,
                              layout = "fr") {
  
  wd <- df %>%
    dplyr::select(where(is.numeric)) %>%
    dplyr::mutate(dplyr::across(dplyr::everything(), scale)) %>%
    as.data.frame()
  
  suffStat <- list(C = stats::cor(wd), n = nrow(wd))
  pc_fit <- pcalg::pc(
    suffStat  = suffStat,
    indepTest = pcalg::gaussCItest,
    labels    = colnames(wd),
    alpha     = alpha,
    verbose   = FALSE
  )
  
  adj <- methods::as(pc_fit@graph, "matrix")
  g <- igraph::graph_from_adjacency_matrix(adj, mode = "directed", diag = FALSE)
  
  # Causal effects (computed before plot so we can use for node sizing)
  edges <- igraph::as_data_frame(g, what = "edges")
  
  causal_effects <- suppressMessages(suppressWarnings({
    expand.grid(
      from = colnames(wd), to = colnames(wd), stringsAsFactors = FALSE
    ) %>%
      dplyr::filter(.data$from != .data$to) %>%
      dplyr::rowwise() %>%
      dplyr::mutate(
        effect = tryCatch(
          min(pcalg::ida(
            match(.data$from, colnames(wd)),
            match(.data$to, colnames(wd)),
            suffStat$C, pc_fit@graph
          )),
          error = function(e) NA_real_
        )
      ) %>%
      dplyr::ungroup() %>%
      dplyr::filter(!is.na(.data$effect)) %>%
      dplyr::arrange(dplyr::desc(abs(.data$effect)))
  }))
  
  # --- Node colors ---
  node_palette <- c("#e74c3c", "#9b59b6", "#3498db", "#2ecc71",
                    "#f1c40f", "#e67e22", "#16a085", "#34495e",
                    "#1abc9c", "#c0392b", "#8e44ad", "#2980b9")
  n_nodes <- igraph::vcount(g)
  
  community_df   <- NULL
  out_modularity <- NULL
  
  if (detect_communities) {
    g_undir <- igraph::as_undirected(g, mode = "collapse")
    communities <- igraph::cluster_louvain(g_undir)
    comm_membership <- igraph::membership(communities)
    
    community_df <- tibble::tibble(
      node      = colnames(wd),
      community = as.integer(comm_membership)
    )
    out_modularity <- igraph::modularity(communities)
    
    igraph::V(g)$color <- grDevices::adjustcolor(
      node_palette[(comm_membership %% length(node_palette)) + 1],
      alpha.f = 0.7
    )
    igraph::V(g)$frame.color <- node_palette[
      (comm_membership %% length(node_palette)) + 1
    ]
  } else {
    igraph::V(g)$color <- "#ecf0f1"
    igraph::V(g)$frame.color <- "#34495e"
  }
  
  # --- Node size ---
  if (scale_nodes) {
    total_effect <- causal_effects %>%
      dplyr::group_by(.data$from) %>%
      dplyr::summarise(total = sum(abs(.data$effect)), .groups = "drop")
    effect_vec <- stats::setNames(total_effect$total, total_effect$from)
    igraph::V(g)$size <- scales::rescale(
      effect_vec[igraph::V(g)$name], to = c(max_node_size * 0.4, max_node_size)
    )
  } else {
    igraph::V(g)$size <- max_node_size * 0.67
  }
  
  # --- Plot ---
  set.seed(42)
  layout_fn <- switch(layout,
                      fr     = igraph::layout_with_fr,
                      mds    = igraph::layout_with_mds,
                      kk     = igraph::layout_with_kk,
                      circle = igraph::layout_in_circle,
                      drl    = igraph::layout_with_drl,
                      stop("Unknown layout: ", layout, ". Use fr, mds, kk, circle, or drl.")
  )
  laycords <- layout_fn(g) %>%
    apply(2, function(x) (x - min(x)) / (max(x) - min(x)) * 0.8 + 0.1)
  
  graphics::par(bg = "white", mar = c(1, 2, 2, 1))
  plot(g,
       layout              = laycords,
       vertex.frame.color  = igraph::V(g)$frame.color,
       vertex.frame.width  = 1.5,
       vertex.label.cex    = igraph::V(g)$size / max_node_size * 0.8,
       vertex.label.color  = "grey20",
       vertex.label.family = "sans",
       edge.arrow.size     = 0.5,
       edge.color          = grDevices::adjustcolor("#34495e", alpha.f = 0.6),
       edge.width          = 1.5,
       edge.curved         = 0.15
  )
  graphics::title(plot_title, cex.main = 1.3, font.main = 1, col.main = "grey20")
  
  # Legend
  if (detect_communities) {
    n_comm <- length(unique(igraph::membership(communities)))
    graphics::legend("bottomleft",
                     legend = paste("Community", seq_len(n_comm)),
                     col    = node_palette[seq_len(n_comm)],
                     pch    = 16, pt.cex = 1.5, cex = 0.7, bty = "n", text.col = "grey30"
    )
  }
  if (scale_nodes) {
    graphics::legend("bottomright",
                     legend = "Node size = Total causal effect",
                     cex = 0.65, bty = "n", text.col = "grey50"
    )
  }
  
  # --- Interpretation ---
  n_edges <- nrow(edges)
  n_effects <- nrow(causal_effects)
  top3 <- utils::head(causal_effects, 3)
  
  cat("\n")
  cat(sprintf("\n%s DAG Causal Discovery Results %s\n",
              strrep("-", 10), strrep("-", 10)))
  cat("\n\n")
  cat(sprintf("  Nodes: %d | Directed edges: %d | Alpha: %s\n",
              n_nodes, n_edges, alpha))
  cat(sprintf("  Causal effects estimated: %d of %d pairs\n",
              n_effects, n_nodes * (n_nodes - 1)))
  if (n_effects < n_nodes * (n_nodes - 1)) {
    cat(sprintf("  (%d pairs skipped — graph not a valid CPDAG for those pairs)\n",
                n_nodes * (n_nodes - 1) - n_effects))
  }
  cat("\n")
  
  if (n_edges == 0) {
    cat("  No directed edges found. The PC algorithm found no conditional\n")
    cat("  dependencies at this alpha level. Try a higher alpha (e.g. 0.10).\n")
  } else {
    cat("  Arrows (X -> Y) indicate estimated causal direction: X may cause Y.\n")
    cat("  Undirected edges mean the direction could not be determined.\n\n")
    if (nrow(top3) > 0) {
      cat("  Top causal effects (IDA estimates):\n")
      for (i in seq_len(nrow(top3))) {
        cat(sprintf("    %d. %s -> %s  (effect = %.3f)\n",
                    i, top3$from[i], top3$to[i], top3$effect[i]))
      }
      cat("\n  Larger absolute effects = stronger estimated causal influence.\n")
    }
  }
  
  if (detect_communities) {
    n_comm <- length(unique(community_df$community))
    cat(sprintf("\n  Communities detected: %d (modularity = %.3f)\n",
                n_comm, out_modularity))
    cat("  Nodes colored by community membership.\n")
  }
  cat("\n")
  
  # --- Output ---
  out <- list(
    pc_fit         = pc_fit,
    dag_edges      = edges,
    causal_effects = causal_effects
  )
  
  if (detect_communities) {
    out$out_communities <- community_df
    out$out_modularity  <- out_modularity
  }
  
  out
}
