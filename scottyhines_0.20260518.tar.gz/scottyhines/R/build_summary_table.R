#' Build a Combined Summary Table (Means + Frequencies)
#'
#' Automatically detects whether each variable is numeric (means) or categorical (frequencies),
#' summarizes by group, and combines into a single wide table. Variables are returned
#' in the order they are provided, with N as the first row.
#'
#' @param df A data frame containing the data.
#' @param group_var The name of the grouping variable (as a string).
#' @param vars A character vector of variable names to summarize. Numeric variables get means;
#'   categorical/character/factor variables get frequency counts.
#' @param include_sd Logical. Include standard deviations for numeric variables. Default is TRUE.
#' @param include_percentage Logical. Include percentages for categorical variables. Default is TRUE.
#' @param include_overall Logical. If TRUE, adds an "overall" column. Default is TRUE.
#' @param scale_numeric Logical. If TRUE, z-score scale numeric variables before summarizing. Default is FALSE.
#'
#' @return A wide-format data frame with one row per variable/category, columns per group level.
#' @export
build_summary_table <- function(df,
                                group_var,
                                vars,
                                include_sd = TRUE,
                                include_percentage = TRUE,
                                include_overall = TRUE,
                                scale_numeric = FALSE) {

  # Scale numeric columns if requested
  if (scale_numeric) {
    for (v in vars) {
      if (v %in% names(df) && is.numeric(df[[v]])) {
        df[[v]] <- as.numeric(scale(df[[v]]))
      }
    }
  }

  # Remove rows with NA in group_var
  df <- df[!is.na(df[[group_var]]), ]

  # Get group levels
  group_levels <- sort(unique(as.character(df[[group_var]])))

  # Helper: summarize one numeric variable
  summarize_numeric <- function(data, var, groups) {
    rows <- list()
    for (g in groups) {
      subset_vals <- data[[var]][as.character(data[[group_var]]) == g]
      m <- round(mean(subset_vals, na.rm = TRUE), 2)
      if (include_sd) {
        s <- round(sd(subset_vals, na.rm = TRUE), 2)
        rows[[g]] <- paste0(m, " (", s, ")")
      } else {
        rows[[g]] <- as.character(m)
      }
    }
    row <- data.frame(
      variable = var,
      sub_category = NA_character_,
      stringsAsFactors = FALSE
    )
    for (g in groups) row[[g]] <- rows[[g]]
    row
  }

  # Helper: summarize one categorical variable
  summarize_categorical <- function(data, var, groups) {
    cats <- sort(unique(as.character(data[[var]])))
    row_list <- list()
    for (cat in cats) {
      row <- data.frame(
        variable = paste0(var, "_", cat),
        sub_category = cat,
        stringsAsFactors = FALSE
      )
      for (g in groups) {
        subset_data <- data[as.character(data[[group_var]]) == g, ]
        n_group <- nrow(subset_data)
        n_cat <- sum(as.character(subset_data[[var]]) == cat, na.rm = TRUE)
        if (include_percentage) {
          pct <- round(n_cat / n_group * 100, 2)
          row[[g]] <- paste0(pct, "% (N = ", n_cat, ")")
        } else {
          row[[g]] <- as.character(n_cat)
        }
      }
      row_list[[cat]] <- row
    }
    dplyr::bind_rows(row_list)
  }

  # Build N row
  n_row <- data.frame(variable = "N", sub_category = NA_character_, stringsAsFactors = FALSE)
  for (g in group_levels) {
    n_row[[g]] <- as.character(sum(as.character(df[[group_var]]) == g))
  }

  # Build variable rows
  var_rows <- list()
  for (i in seq_along(vars)) {
    v <- vars[i]
    if (is.numeric(df[[v]])) {
      var_rows[[v]] <- summarize_numeric(df, v, group_levels)
    } else {
      var_rows[[v]] <- summarize_categorical(df, v, group_levels)
    }
    # Tag input order
    var_rows[[v]]$.var_of_interest <- v
    var_rows[[v]]$.input_order <- i
  }

  result <- dplyr::bind_rows(var_rows)

  # Add overall column
  if (include_overall) {
    overall_n <- as.character(nrow(df))
    n_row[["overall"]] <- overall_n

    overall_rows <- list()
    for (v in vars) {
      if (is.numeric(df[[v]])) {
        m <- round(mean(df[[v]], na.rm = TRUE), 2)
        if (include_sd) {
          s <- round(sd(df[[v]], na.rm = TRUE), 2)
          val <- paste0(m, " (", s, ")")
        } else {
          val <- as.character(m)
        }
        overall_rows[[v]] <- data.frame(variable = v, overall = val, stringsAsFactors = FALSE)
      } else {
        cats <- sort(unique(as.character(df[[v]])))
        for (cat in cats) {
          n_cat <- sum(as.character(df[[v]]) == cat, na.rm = TRUE)
          if (include_percentage) {
            pct <- round(n_cat / nrow(df) * 100, 2)
            val <- paste0(pct, "% (N = ", n_cat, ")")
          } else {
            val <- as.character(n_cat)
          }
          overall_rows[[paste0(v, "_", cat)]] <- data.frame(
            variable = paste0(v, "_", cat), overall = val, stringsAsFactors = FALSE
          )
        }
      }
    }
    overall_df <- dplyr::bind_rows(overall_rows)
    result <- result %>% dplyr::left_join(overall_df, by = "variable")
  }

  # Combine N row + variable rows, sort by input order
  n_row$.var_of_interest <- NA_character_
  n_row$.input_order <- 0
  final <- dplyr::bind_rows(n_row, result) %>%
    dplyr::arrange(.input_order) %>%
    dplyr::select(variable, sub_category, dplyr::everything()) %>%
    dplyr::select(-dplyr::any_of(c(".var_of_interest", ".input_order")))

  return(final)
}
