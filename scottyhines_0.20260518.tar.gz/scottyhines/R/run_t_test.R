#' Run T-Tests with Group Means and Labels
#'
#' Performs paired or independent t-tests on multiple outcome variables and returns
#' a tidy summary including group means, group labels, and test statistics.
#'
#' @param data A data frame containing the variables to be tested
#' @param outcome_vars Character vector of outcome variable names to test
#' @param group_var Character string specifying the grouping variable name
#' @param paired Logical indicating whether to perform paired (TRUE) or independent (FALSE) t-tests. Default is FALSE.
#' @param scale_numeric Logical. If TRUE, all numeric outcome columns are z-score scaled before testing. Default is FALSE.
#'
#' @return A data frame with the following columns:
#'   - estimate: Mean difference (paired) or difference in means (independent)
#'   - estimate1: Mean of group 1 (independent t-test only)
#'   - estimate2: Mean of group 2 (independent t-test only)
#'   - statistic: t-statistic
#'   - p.value: p-value for the test
#'   - parameter: Degrees of freedom
#'   - conf.low: Lower bound of 95% confidence interval
#'   - conf.high: Upper bound of 95% confidence interval
#'   - method: Description of the t-test method used
#'   - alternative: Alternative hypothesis
#'   - outcome_variable: Name of the outcome variable tested
#'   - group_variable: Name of the grouping variable
#'   - mean_group1: Mean value for the first group
#'   - mean_group2: Mean value for the second group
#'   - group1_name: Label/name of the first group (e.g., "pre", "control")
#'   - group2_name: Label/name of the second group (e.g., "post", "test")
#'   - mean_diff: Difference between group means (mean_group2 - mean_group1)
#'
#' @examples
#' results_indep <- run_ttest(
#'   data = mtcars,
#'   outcome_vars = c("mpg", "hp"),
#'   group_var = "am",  # automatic vs manual transmission
#'   paired = FALSE
#' )
#'
#' @export
run_ttest <- function(data, outcome_vars, group_var, paired = FALSE, scale_numeric = FALSE) {
  
  # Scale numeric columns if requested
  if (scale_numeric) {
    for (v in outcome_vars) {
      if (v %in% names(data) && is.numeric(data[[v]])) {
        data[[v]] <- as.numeric(scale(data[[v]]))
      }
    }
  }
  
  # Initialize list to store results for each outcome variable
  t_test_summaries <- list()
  
  # Loop through each outcome variable
  for (outcome_var in outcome_vars) {
    
    if (paired) {
      # Extract unique group levels
      group_levels <- unique(data[[group_var]])
      
      # Check that there are exactly two groups for paired t-test
      if (length(group_levels) != 2) {
        stop("Paired t-test requires exactly two levels in the group variable.")
      }
      
      # Extract data for each group
      group1 <- data[data[[group_var]] == group_levels[1], 
                     outcome_var, drop = TRUE]
      group2 <- data[data[[group_var]] == group_levels[2], 
                     outcome_var, drop = TRUE]
      
      # Calculate means for each group
      mean_group1 <- mean(group1, na.rm = TRUE)
      mean_group2 <- mean(group2, na.rm = TRUE)
      
      # Run paired t-test
      mod <- t.test(group1, group2, paired = TRUE)
      
    } else {
      # For independent t-test, create formula and run test
      formula <- as.formula(paste(outcome_var, "~", group_var))
      mod <- t.test(formula, data = data)
      
      # Extract group levels and calculate means
      group_levels <- unique(data[[group_var]])
      mean_group1 <- mean(data[data[[group_var]] == group_levels[1], 
                               outcome_var], na.rm = TRUE)
      mean_group2 <- mean(data[data[[group_var]] == group_levels[2], 
                               outcome_var], na.rm = TRUE)
    }
    
    # Convert model results to tidy format
    tidy_model <- broom::tidy(mod)
    
    # Add metadata columns
    tidy_model$outcome_variable <- outcome_var
    tidy_model$group_variable <- group_var
    tidy_model$mean_group1 <- mean_group1  # Mean value for first group
    tidy_model$mean_group2 <- mean_group2  # Mean value for second group
    tidy_model$group1_name <- group_levels[1]  # Label for first group (e.g., "pre", "control")
    tidy_model$group2_name <- group_levels[2]  # Label for second group (e.g., "post", "test")
    tidy_model$mean_diff <- mean_group2 - mean_group1  # Calculate mean difference
    
    # Store results for this outcome variable
    t_test_summaries[[outcome_var]] <- tidy_model
  }
  
  # Combine all results into a single data frame
  final_t_test_summary <- do.call(rbind, t_test_summaries)
  
  return(janitor::clean_names(final_t_test_summary))
}