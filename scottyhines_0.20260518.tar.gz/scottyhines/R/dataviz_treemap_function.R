#' Treemap Chart Function
#'
#' Creates a treemap showing hierarchical data as nested rectangles, where the size
#' of each rectangle represents the count of observations. Supports 1, 2, or 3 levels
#' of grouping hierarchy. Built with ggplot2 + treemapify.
#'
#' @param df A data frame containing the data.
#' @param group_vars A character vector of 1 to 3 variable names defining the hierarchy.
#'   The first variable is the outermost grouping (biggest boxes), subsequent variables
#'   define nested sub-boxes.
#' @param fill_var Optional string specifying which variable to color by. Defaults to the
#'   outermost (first) variable in group_vars.
#' @param title_text A string specifying the title. Default is "Treemap".
#' @param sub_text A string specifying the subtitle. Default is "".
#' @param caption_text A string specifying the caption. Default is "".
#' @param show_labels Logical. Whether to show labels inside each box. Default is TRUE.
#' @param show_n Logical. Whether to show the count (N) inside each box. Default is TRUE.
#' @param border_color A string specifying the color of group borders. Default is "grey20".
#' @param border_size Numeric. Line width of the outer group borders. Default is 3.
#' @param fill_alpha Numeric. Alpha transparency for the fill colors. Default is 0.75.
#'
#' @return A ggplot object.
#' @export
dataviz_treemap_function <- function(df,
                                     group_vars,
                                     fill_var = NULL,
                                     title_text = "Treemap",
                                     sub_text = "",
                                     caption_text = "",
                                     show_labels = TRUE,
                                     show_n = TRUE,
                                     border_color = "grey20",
                                     border_size = 3,
                                     fill_alpha = 0.75) {

  if (!requireNamespace("treemapify", quietly = TRUE)) {
    stop("Package 'treemapify' is required. Install it with: install.packages('treemapify')")
  }

  stopifnot(length(group_vars) >= 1, length(group_vars) <= 3)

  # Default fill_var to the outermost grouping variable
  if (is.null(fill_var)) {
    fill_var <- group_vars[1]
  }

  # Custom color palette
  custom_colors <- c("#e74c3c", "#9b59b6", "#3498db", "#2ecc71",
                     "#f1c40f", "#e67e22", "#16a085", "#34495e",
                     "#1abc9c", "#c0392b", "#8e44ad", "#2980b9")

  # Remove NAs in grouping variables
  for (gv in group_vars) {
    df <- df[!is.na(df[[gv]]), ]
  }

  # Build count data
  group_syms <- rlang::syms(group_vars)
  count_df <- df %>%
    dplyr::group_by(!!!group_syms) %>%
    dplyr::summarise(n = dplyr::n(), .groups = "drop") %>%
    dplyr::filter(n > 0)

  # Determine the innermost variable for tile labels
  innermost_var <- group_vars[length(group_vars)]

  # Create label column — top-left style: "name\n(N)"
  if (show_labels && show_n) {
    count_df$.label <- paste0(count_df[[innermost_var]], "\n(", count_df$n, ")")
  } else if (show_labels) {
    count_df$.label <- as.character(count_df[[innermost_var]])
  } else if (show_n) {
    count_df$.label <- paste0("(", count_df$n, ")")
  } else {
    count_df$.label <- ""
  }

  # Build the plot based on hierarchy depth
  if (length(group_vars) == 1) {
    plot <- ggplot2::ggplot(count_df, ggplot2::aes(
      area = n,
      fill = .data[[fill_var]],
      label = .label
    ))
  } else if (length(group_vars) == 2) {
    plot <- ggplot2::ggplot(count_df, ggplot2::aes(
      area = n,
      fill = .data[[fill_var]],
      label = .label,
      subgroup = .data[[group_vars[1]]]
    ))
  } else {
    plot <- ggplot2::ggplot(count_df, ggplot2::aes(
      area = n,
      fill = .data[[fill_var]],
      label = .label,
      subgroup = .data[[group_vars[1]]],
      subgroup2 = .data[[group_vars[2]]]
    ))
  }

  plot <- plot +
    treemapify::geom_treemap(alpha = fill_alpha) +
    ggplot2::scale_fill_manual(values = rep(custom_colors, length.out = length(unique(count_df[[fill_var]]))))

  # Add innermost tile labels — top-left, white text
  if (show_labels || show_n) {
    plot <- plot +
      treemapify::geom_treemap_text(
        colour = "white",
        place = "topleft",
        fontface = "bold",
        grow = FALSE,
        reflow = TRUE,
        min.size = 2,
        padding.x = grid::unit(2, "mm"),
        padding.y = grid::unit(2, "mm")
      )
  }

  # Add subgroup borders and labels for 2+ level hierarchy
  if (length(group_vars) >= 2) {
    # Compute subgroup totals for the label
    subgroup_totals <- count_df %>%
      dplyr::group_by(.data[[group_vars[1]]]) %>%
      dplyr::summarise(.total = sum(n), .groups = "drop")

    plot <- plot +
      treemapify::geom_treemap_subgroup_border(
        colour = border_color,
        size = border_size
      ) +
      treemapify::geom_treemap_subgroup_text(
        place = "topleft",
        colour = "white",
        fontface = "bold",
        alpha = 0.7,
        grow = FALSE,
        padding.x = grid::unit(3, "mm"),
        padding.y = grid::unit(3, "mm"),
        min.size = 3
      )
  }

  # Add subgroup2 borders and labels for 3-level hierarchy
  if (length(group_vars) == 3) {
    plot <- plot +
      treemapify::geom_treemap_subgroup2_border(
        colour = border_color,
        size = border_size + 1
      ) +
      treemapify::geom_treemap_subgroup2_text(
        place = "topleft",
        colour = "white",
        fontface = "bold",
        alpha = 0.5,
        grow = FALSE,
        padding.x = grid::unit(4, "mm"),
        padding.y = grid::unit(4, "mm"),
        min.size = 4
      )
  }

  plot <- plot +
    ggplot2::labs(
      title = title_text,
      subtitle = sub_text,
      caption = caption_text
    ) +
    ggplot2::theme_linedraw() +
    ggplot2::theme(
      legend.position = "none"
    )

  return(plot)
}
