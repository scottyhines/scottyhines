#' Run Mediation Analysis (X -> M -> Y) With Optional Covariates
#'
#' Fits a classic three-variable mediation model for every combination of
#' outcome (Y), mediator (M), and predictor of interest (X), optionally
#' adjusting for a shared set of covariates. For each triplet the function
#' estimates the three Baron & Kenny equations:
#' \itemize{
#'   \item Path a: \code{M ~ controls + X}                (effect of X on M)
#'   \item Path b: \code{Y ~ controls + X + M}            (effect of M on Y, adjusted for X)
#'   \item Path c (total): \code{Y ~ controls + X}        (total effect of X on Y)
#' }
#' Each equation is auto-fit with \code{stats::lm} when the response is
#' continuous and \code{stats::glm(family = binomial)} when the response is
#' binary. A variable is treated as binary when it is logical, a 2-level
#' factor / character, or a numeric column whose only values are 0 and 1.
#' The actual family used per equation is reported in the output tables.
#'
#' The direct effect (c') is the X coefficient from the path-b model. The
#' indirect effect is \code{a * b}, with a Sobel standard error and a
#' percentile bootstrap confidence interval. When path-a and path-b are on
#' different scales (mixed linear / logistic), the bootstrap CI is the
#' preferred inferential tool; the \code{family_a} / \code{family_b} columns
#' make it explicit when this is the case. Proportion mediated is reported
#' as \code{a*b / c} when the total effect is non-trivial.
#'
#' @section How to read the output:
#' The \code{indirect_effects} table is the headline result. For each X -> M -> Y
#' triplet, look at four numbers in this order:
#' \enumerate{
#'   \item \strong{c_total} -- does X have a meaningful overall effect on Y?
#'     If c is not significant there is little to mediate in the first place.
#'   \item \strong{a} and \strong{b} -- both should be significant for a
#'     credible mediation story. Path a says X moves M; path b says M moves Y
#'     after controlling for X.
#'   \item \strong{indirect_effect_ab} with its bootstrap CI
#'     (\code{boot_ci_lower}, \code{boot_ci_upper}). If the CI excludes zero,
#'     the mediated path is statistically significant. The bootstrap CI is
#'     the gold-standard test, especially when paths cross scales (mixed
#'     linear / logistic).
#'   \item \strong{cprime_direct} -- the X effect that remains after controlling
#'     for M. If c' is no longer significant, M fully explains the X -> Y
#'     relationship (\strong{full mediation}). If c' is smaller than c but still
#'     significant, that's \strong{partial mediation}.
#' }
#' Helper columns: \code{mediation_type} (none / partial / full),
#' \code{direction} (sign of ab), \code{proportion_mediated} (ab / c, treat as
#' a rough indicator when \code{mixed_scales = TRUE}), and
#' \code{interpretation} (a one-line plain-English summary of the row). The
#' returned \code{legend} data.frame describes every column in
#' \code{indirect_effects}.
#'
#' Coefficient sign reminder: when \code{family_b = "binomial"} the b and c
#' coefficients are on the \strong{log-odds} scale, so a value of -0.7 means
#' "every unit of the predictor multiplies the odds of Y = 1 by exp(-0.7)
#' \eqn{\approx} 0.50". For OLS rows the coefficients are raw point changes in Y.
#'
#' @param data A data.frame.
#' @param outcome_vars Character vector of outcome (Y) variable names.
#' @param mediator_vars Character vector of mediator (M) variable names.
#' @param interest_vars Character vector of predictor (X) variable names to iterate over.
#' @param control_vars Optional character vector of covariates included in every path equation.
#' @param n_boot Integer. Number of bootstrap resamples for the indirect-effect CI. Default 1000. Set to 0 to skip bootstrap.
#' @param conf_level Numeric in (0,1). Confidence level for the bootstrap CI. Default 0.95.
#' @param scale_numeric Logical. If TRUE, continuous numeric outcome / mediator / predictor / control columns are z-score scaled before fitting. Binary 0/1 columns are left untouched. Default FALSE.
#' @return A list with four elements:
#' \describe{
#'   \item{coefficients}{Tidy coefficient rows for every path-a, path-b, and total-effect (path-c) model, tagged with outcome / mediator / predictor / path / family.}
#'   \item{indirect_effects}{One row per X -> M -> Y triplet with paths a, b, c, c', the indirect effect a*b, Sobel SE / z / p, bootstrap CI, proportion mediated, the family used at each path, and helper interpretation columns: \code{mediation_type}, \code{direction}, \code{ab_inference_method}, \code{mixed_scales}, and a plain-English \code{interpretation}.}
#'   \item{model_fit}{Per-model R-squared (McFadden's pseudo-R² for glm), AIC, BIC, n_obs, residual SE for each of the three equations.}
#'   \item{legend}{A data.frame describing each column in \code{indirect_effects} in plain English.}
#' }
#' @export
run_mediation_analysis <- function(data,
                                   outcome_vars,
                                   mediator_vars,
                                   interest_vars,
                                   control_vars = NULL,
                                   n_boot = 1000,
                                   conf_level = 0.95,
                                   scale_numeric = FALSE) {
  options(warn = -1)
  on.exit(options(warn = 0), add = TRUE)

  stopifnot(is.data.frame(data))
  stopifnot(is.character(outcome_vars), length(outcome_vars) >= 1)
  stopifnot(is.character(mediator_vars), length(mediator_vars) >= 1)
  stopifnot(is.character(interest_vars), length(interest_vars) >= 1)
  if (!is.null(control_vars)) stopifnot(is.character(control_vars))
  stopifnot(is.numeric(n_boot), n_boot >= 0)
  stopifnot(is.numeric(conf_level), conf_level > 0, conf_level < 1)

  # Detect binary variables: logical, 2-level factor / character, or numeric in {0,1}
  is_binary_var <- function(x) {
    x_clean <- x[!is.na(x)]
    if (length(x_clean) == 0) return(FALSE)
    if (is.logical(x_clean)) return(TRUE)
    if (is.factor(x_clean)) return(length(levels(droplevels(x_clean))) == 2)
    if (is.character(x_clean)) return(length(unique(x_clean)) == 2)
    if (is.numeric(x_clean)) {
      u <- unique(x_clean)
      return(length(u) == 2 && all(u %in% c(0, 1)))
    }
    FALSE
  }

  # Coerce a binary column (logical, 2-level factor / character) to numeric 0/1.
  # Numeric 0/1 columns pass through unchanged. Used so glm responses are clean.
  coerce_binary_numeric <- function(x) {
    if (is.logical(x)) return(as.integer(x))
    if (is.factor(x)) return(as.integer(x) - 1L)
    if (is.character(x)) {
      u <- sort(unique(x[!is.na(x)]))
      if (length(u) == 2) return(as.integer(x == u[length(u)]))
      return(x)
    }
    x
  }

  # Scale numeric columns if requested -- skip binary 0/1 columns so we don't
  # destroy the response distribution required by glm(binomial).
  if (scale_numeric) {
    all_vars <- unique(c(outcome_vars, mediator_vars, interest_vars, control_vars))
    for (v in all_vars) {
      if (v %in% names(data) && is.numeric(data[[v]]) && !is_binary_var(data[[v]])) {
        data[[v]] <- as.numeric(scale(data[[v]]))
      }
    }
  }

  # Pre-coerce binary outcome / mediator columns to 0/1 numeric so glm sees a
  # clean response variable. Predictors are left as-is (numeric 0/1 binaries
  # work directly; factor/logical predictors will be dummy-coded by the formula).
  for (v in unique(c(outcome_vars, mediator_vars))) {
    if (v %in% names(data) && is_binary_var(data[[v]])) {
      data[[v]] <- coerce_binary_numeric(data[[v]])
    }
  }

  # Per-variable binary status (computed once, after coercion)
  binary_status <- list()
  for (v in unique(c(outcome_vars, mediator_vars, interest_vars))) {
    binary_status[[v]] <- v %in% names(data) && is_binary_var(data[[v]])
  }

  # Fit one equation, picking lm or glm(binomial) by response type.
  fit_equation <- function(formula, data, response_is_binary) {
    if (response_is_binary) {
      list(fit = stats::glm(formula, data = data, family = stats::binomial()),
           family = "binomial")
    } else {
      list(fit = stats::lm(formula, data = data), family = "gaussian")
    }
  }

  # R-squared that works for both lm and glm: OLS R² for lm, McFadden's pseudo
  # R² for glm. Returns NA if neither is computable.
  rsq <- function(fit) {
    if (inherits(fit, "lm") && !inherits(fit, "glm")) {
      return(summary(fit)$r.squared)
    }
    if (inherits(fit, "glm")) {
      d  <- stats::deviance(fit)
      d0 <- fit$null.deviance
      if (is.finite(d) && is.finite(d0) && d0 > 0) return(1 - d / d0)
    }
    NA_real_
  }

  # Helper to build the controls portion of a formula RHS
  controls_rhs <- function(controls) {
    if (is.null(controls) || length(controls) == 0) return("")
    paste0(paste(controls, collapse = " + "), " + ")
  }

  # Helper to safely pull a coefficient row by term name
  get_term <- function(tidy_df, term_name) {
    row <- tidy_df[tidy_df$term == term_name, , drop = FALSE]
    if (nrow(row) == 0) {
      return(list(estimate = NA_real_, std.error = NA_real_,
                  statistic = NA_real_, p.value = NA_real_))
    }
    list(estimate = row$estimate[1],
         std.error = row$std.error[1],
         statistic = row$statistic[1],
         p.value = row$p.value[1])
  }

  alpha <- 1 - conf_level
  ci_lo_q <- alpha / 2
  ci_hi_q <- 1 - alpha / 2

  coef_rows <- list()
  indirect_rows <- list()
  fit_rows <- list()

  total_iterations <- length(outcome_vars) * length(mediator_vars) * length(interest_vars)
  pb <- txtProgressBar(min = 0, max = total_iterations, style = 3)
  current_iteration <- 0

  for (outcome_var in outcome_vars) {
    for (mediator_var in mediator_vars) {
      for (predictor_var in interest_vars) {

        # Skip degenerate triplets where the same column appears in multiple roles
        if (any(duplicated(c(outcome_var, mediator_var, predictor_var)))) {
          current_iteration <- current_iteration + 1
          setTxtProgressBar(pb, current_iteration)
          next
        }

        tryCatch({
          ctrl <- controls_rhs(control_vars)
          y_binary <- isTRUE(binary_status[[outcome_var]])
          m_binary <- isTRUE(binary_status[[mediator_var]])

          # Path a: M ~ controls + X
          fa_str <- paste0(mediator_var, " ~ ", ctrl, predictor_var)
          fa <- stats::as.formula(fa_str)
          fit_a_obj <- fit_equation(fa, data, m_binary)
          fit_a <- fit_a_obj$fit
          fam_a <- fit_a_obj$family
          tidy_a <- broom::tidy(fit_a)
          a_term <- get_term(tidy_a, predictor_var)

          # Path b + c': Y ~ controls + X + M
          fb_str <- paste0(outcome_var, " ~ ", ctrl, predictor_var, " + ", mediator_var)
          fb <- stats::as.formula(fb_str)
          fit_b_obj <- fit_equation(fb, data, y_binary)
          fit_b <- fit_b_obj$fit
          fam_b <- fit_b_obj$family
          tidy_b <- broom::tidy(fit_b)
          b_term <- get_term(tidy_b, mediator_var)
          cprime_term <- get_term(tidy_b, predictor_var)

          # Path c (total): Y ~ controls + X
          fc_str <- paste0(outcome_var, " ~ ", ctrl, predictor_var)
          fc <- stats::as.formula(fc_str)
          fit_c_obj <- fit_equation(fc, data, y_binary)
          fit_c <- fit_c_obj$fit
          fam_c <- fit_c_obj$family
          tidy_c <- broom::tidy(fit_c)
          c_term <- get_term(tidy_c, predictor_var)

          # Tag coefficient rows with metadata + path label + family
          tag <- function(tidy_df, path_label, equation_str, fam) {
            tidy_df$path               <- path_label
            tidy_df$family             <- fam
            tidy_df$outcome_variable   <- outcome_var
            tidy_df$mediator_variable  <- mediator_var
            tidy_df$predictor_variable <- predictor_var
            tidy_df$formula            <- equation_str
            tidy_df
          }
          key_base <- paste(outcome_var, mediator_var, predictor_var, sep = "__")
          coef_rows[[paste0(key_base, "__a")]]        <- tag(tidy_a, "a", fa_str, fam_a)
          coef_rows[[paste0(key_base, "__b_cprime")]] <- tag(tidy_b, "b_cprime", fb_str, fam_b)
          coef_rows[[paste0(key_base, "__c_total")]]  <- tag(tidy_c, "c_total", fc_str, fam_c)

          # Indirect effect (a*b) and Sobel SE/z/p
          a_est <- a_term$estimate
          a_se  <- a_term$std.error
          b_est <- b_term$estimate
          b_se  <- b_term$std.error
          ab    <- a_est * b_est
          sobel_se <- suppressWarnings(sqrt(a_est^2 * b_se^2 + b_est^2 * a_se^2))
          sobel_z  <- if (is.finite(sobel_se) && sobel_se > 0) ab / sobel_se else NA_real_
          sobel_p  <- if (is.finite(sobel_z)) 2 * stats::pnorm(-abs(sobel_z)) else NA_real_

          # Bootstrap CI for indirect effect (works regardless of family mix)
          boot_lo <- NA_real_
          boot_hi <- NA_real_
          boot_n_used <- 0L
          if (n_boot > 0) {
            n <- nrow(data)
            ab_boot <- numeric(n_boot)
            for (i in seq_len(n_boot)) {
              idx <- sample.int(n, n, replace = TRUE)
              boot_data <- data[idx, , drop = FALSE]
              ab_boot[i] <- tryCatch({
                fit_a_b <- fit_equation(fa, boot_data, m_binary)$fit
                fit_b_b <- fit_equation(fb, boot_data, y_binary)$fit
                ca <- stats::coef(fit_a_b)[predictor_var]
                cb <- stats::coef(fit_b_b)[mediator_var]
                if (is.na(ca) || is.na(cb)) NA_real_ else as.numeric(ca) * as.numeric(cb)
              }, error = function(e) NA_real_, warning = function(w) NA_real_)
            }
            ab_boot <- ab_boot[is.finite(ab_boot)]
            boot_n_used <- length(ab_boot)
            if (boot_n_used >= 2) {
              qs <- stats::quantile(ab_boot, probs = c(ci_lo_q, ci_hi_q), na.rm = TRUE)
              boot_lo <- as.numeric(qs[1])
              boot_hi <- as.numeric(qs[2])
            }
          }

          # Proportion mediated (only meaningful when total effect is non-trivial,
          # and only really interpretable when fam_a, fam_b, fam_c are consistent)
          prop_med <- if (isTRUE(is.finite(c_term$estimate)) &&
                          abs(c_term$estimate) > .Machine$double.eps) {
            ab / c_term$estimate
          } else {
            NA_real_
          }

          # ---- Plain-English interpretation ----
          # Significance flags. Bootstrap CI is the gold standard for ab; fall
          # back to Sobel p when bootstrap was skipped or unusable.
          sig_a    <- isTRUE(is.finite(a_term$p.value)      && a_term$p.value      < 0.05)
          sig_b    <- isTRUE(is.finite(b_term$p.value)      && b_term$p.value      < 0.05)
          sig_c    <- isTRUE(is.finite(c_term$p.value)      && c_term$p.value      < 0.05)
          sig_cp   <- isTRUE(is.finite(cprime_term$p.value) && cprime_term$p.value < 0.05)
          if (n_boot > 0 && is.finite(boot_lo) && is.finite(boot_hi)) {
            sig_ab <- (boot_lo > 0 && boot_hi > 0) || (boot_lo < 0 && boot_hi < 0)
            ab_inference_method <- "bootstrap_ci"
          } else {
            sig_ab <- isTRUE(is.finite(sobel_p) && sobel_p < 0.05)
            ab_inference_method <- "sobel"
          }

          # Mediation classification:
          #   - "none"             : indirect effect not significant
          #   - "full mediation"   : indirect significant AND direct (c') not significant
          #   - "partial mediation": indirect significant AND direct still significant
          mediation_type <- if (!sig_ab) {
            "none"
          } else if (sig_cp) {
            "partial mediation"
          } else {
            "full mediation"
          }

          # Direction of the indirect effect
          direction <- if (!is.finite(ab) || abs(ab) < .Machine$double.eps) {
            "n/a"
          } else if (ab > 0) {
            "positive (X raises Y through M)"
          } else {
            "negative (X lowers Y through M)"
          }

          # One-line interpretation sentence
          format_p <- function(p) {
            if (!is.finite(p)) return("p = NA")
            if (p < 0.001)     return("p < .001")
            sprintf("p = %.3f", p)
          }
          ab_p_txt <- if (ab_inference_method == "bootstrap_ci") {
            sprintf("bootstrap %.0f%% CI [%.3f, %.3f]",
                    100 * conf_level, boot_lo, boot_hi)
          } else {
            sprintf("Sobel %s", format_p(sobel_p))
          }
          path_phrase <- if (fam_b == "binomial") {
            "log-odds of Y"
          } else {
            "Y"
          }
          interpretation <- if (mediation_type == "none") {
            sprintf("No significant mediation: indirect effect ab = %.3f (%s) is not distinguishable from zero.",
                    ab, ab_p_txt)
          } else {
            sprintf("%s of %s by %s: ab = %.3f (%s), total c = %.3f, direct c' = %.3f. About %.0f%% of the total effect runs through %s.",
                    tools::toTitleCase(mediation_type),
                    outcome_var, mediator_var,
                    ab, ab_p_txt, c_term$estimate, cprime_term$estimate,
                    100 * ifelse(is.finite(prop_med), prop_med, NA_real_),
                    mediator_var)
          }
          # Note when units don't match across paths (interpret prop_mediated cautiously)
          mixed_scales <- length(unique(c(fam_a, fam_b, fam_c))) > 1

          indirect_rows[[key_base]] <- data.frame(
            outcome_variable       = outcome_var,
            mediator_variable      = mediator_var,
            predictor_variable     = predictor_var,
            family_a               = fam_a,
            family_b               = fam_b,
            family_c_total         = fam_c,
            a_estimate             = a_est,
            a_se                   = a_se,
            a_p_value              = a_term$p.value,
            b_estimate             = b_est,
            b_se                   = b_se,
            b_p_value              = b_term$p.value,
            c_total_estimate       = c_term$estimate,
            c_total_se             = c_term$std.error,
            c_total_p_value        = c_term$p.value,
            cprime_direct_estimate = cprime_term$estimate,
            cprime_direct_se       = cprime_term$std.error,
            cprime_direct_p_value  = cprime_term$p.value,
            indirect_effect_ab     = ab,
            sobel_se               = sobel_se,
            sobel_z                = sobel_z,
            sobel_p_value          = sobel_p,
            boot_ci_lower          = boot_lo,
            boot_ci_upper          = boot_hi,
            boot_n_used            = boot_n_used,
            conf_level             = conf_level,
            proportion_mediated    = prop_med,
            mediation_type         = mediation_type,
            direction              = direction,
            ab_inference_method    = ab_inference_method,
            mixed_scales           = mixed_scales,
            interpretation         = interpretation,
            stringsAsFactors       = FALSE
          )

          # Per-equation fit stats
          fit_one <- function(fit, fam, path_label, equation_str) {
            resid_se <- if (inherits(fit, "lm") && !inherits(fit, "glm")) summary(fit)$sigma else NA_real_
            data.frame(
              outcome_variable    = outcome_var,
              mediator_variable   = mediator_var,
              predictor_variable  = predictor_var,
              path                = path_label,
              family              = fam,
              formula             = equation_str,
              r_squared           = rsq(fit),
              aic                 = stats::AIC(fit),
              bic                 = stats::BIC(fit),
              n_obs               = stats::nobs(fit),
              residual_se         = resid_se,
              stringsAsFactors    = FALSE
            )
          }
          fit_rows[[paste0(key_base, "__a")]]        <- fit_one(fit_a, fam_a, "a", fa_str)
          fit_rows[[paste0(key_base, "__b_cprime")]] <- fit_one(fit_b, fam_b, "b_cprime", fb_str)
          fit_rows[[paste0(key_base, "__c_total")]]  <- fit_one(fit_c, fam_c, "c_total", fc_str)

          current_iteration <- current_iteration + 1
          setTxtProgressBar(pb, current_iteration)
        }, error = function(e) {
          error_msg <- sprintf("ERROR: Failed mediation triplet Y='%s' M='%s' X='%s'\n  Error: %s",
                               outcome_var, mediator_var, predictor_var, e$message)
          message(error_msg)
        })
      }
    }
  }

  close(pb)
  cat("\n")

  final_coefs    <- do.call(rbind, coef_rows);    rownames(final_coefs)    <- NULL
  final_indirect <- do.call(rbind, indirect_rows); rownames(final_indirect) <- NULL
  final_fit      <- do.call(rbind, fit_rows);     rownames(final_fit)      <- NULL

  # Plain-English column descriptions for indirect_effects
  legend <- data.frame(
    column = c(
      "outcome_variable", "mediator_variable", "predictor_variable",
      "family_a", "family_b", "family_c_total",
      "a_estimate", "a_se", "a_p_value",
      "b_estimate", "b_se", "b_p_value",
      "c_total_estimate", "c_total_se", "c_total_p_value",
      "cprime_direct_estimate", "cprime_direct_se", "cprime_direct_p_value",
      "indirect_effect_ab", "sobel_se", "sobel_z", "sobel_p_value",
      "boot_ci_lower", "boot_ci_upper", "boot_n_used", "conf_level",
      "proportion_mediated", "mediation_type", "direction",
      "ab_inference_method", "mixed_scales", "interpretation"
    ),
    description = c(
      "Y -- the outcome variable.",
      "M -- the mediator variable (the proposed pathway).",
      "X -- the predictor of interest (the proposed cause).",
      "Model family used to fit path a (M ~ X). gaussian = OLS, binomial = logistic.",
      "Model family used to fit path b / c' (Y ~ X + M).",
      "Model family used to fit the total-effect model (Y ~ X).",
      "Path a coefficient: effect of X on M.",
      "Standard error of the path a coefficient.",
      "p-value for path a. Small p means X meaningfully predicts M.",
      "Path b coefficient: effect of M on Y, holding X constant.",
      "Standard error of the path b coefficient.",
      "p-value for path b. Small p means M meaningfully predicts Y.",
      "Total-effect c: effect of X on Y, no mediator in the model.",
      "Standard error of c.",
      "p-value for c. Small p means X has a meaningful overall effect on Y.",
      "Direct-effect c': effect of X on Y AFTER controlling for M.",
      "Standard error of c'.",
      "p-value for c'. If c was significant but c' is not, M fully accounts for the X->Y relationship.",
      "Indirect effect ab = a * b. The piece of the total effect that flows through M.",
      "Sobel standard error for ab. Assumes equal scales across paths.",
      "Sobel z-statistic for ab.",
      "Sobel p-value for ab. Treat with caution when family_a differs from family_b.",
      "Lower bound of the bootstrap percentile CI for ab. CI excluding zero = significant indirect effect.",
      "Upper bound of the bootstrap percentile CI for ab.",
      "Number of bootstrap replicates that produced a usable estimate (out of n_boot).",
      "Confidence level used for the bootstrap CI (e.g., 0.95).",
      "ab divided by c. Roughly: share of the total effect that runs through M. Interpret cautiously when mixed_scales = TRUE.",
      "Classification: 'none' (no indirect effect), 'partial mediation' (indirect significant + direct still significant), or 'full mediation' (indirect significant + direct no longer significant).",
      "Sign of the indirect effect (positive / negative / n/a).",
      "Which test was used to call ab significant: 'bootstrap_ci' (preferred) or 'sobel'.",
      "TRUE when path-a, path-b, and path-c are not all the same family (e.g., one OLS and one logistic). Coefficients on different scales -- be careful with proportion_mediated.",
      "One-line plain-English summary of this row."
    ),
    stringsAsFactors = FALSE
  )

  return(list(
    coefficients     = janitor::clean_names(final_coefs),
    indirect_effects = janitor::clean_names(final_indirect),
    model_fit        = janitor::clean_names(final_fit),
    legend           = legend
  ))
}
