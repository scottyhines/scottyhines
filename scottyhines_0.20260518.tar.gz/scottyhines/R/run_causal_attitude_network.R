#' Run Causal Attitude Network Analysis
#'
#' Estimates a Gaussian Graphical Model (GGM) from numeric data using
#' EBICglasso regularization, then optionally performs community detection,
#' centrality analysis, bridge centrality, small-world diagnostics, and
#' produces a network plot with edges colored by sign.
#'
#' @param df A data frame. All numeric columns will be selected, scaled, and
#'   used as nodes in the network.
#' @param gamma Numeric. The EBIC tuning parameter controlling sparsity.
#'   Higher values produce sparser networks. Typical range is \code{0} to
#'   \code{0.5}. Passed to \code{\link[qgraph]{EBICglasso}}.
#' @param threshold Logical or numeric. Whether to threshold small partial
#'   correlations to zero. Passed to \code{\link[qgraph]{EBICglasso}}.
#' @param plot_title Character. Title displayed on the network plot.
#' @param scale_nodes Logical. If \code{TRUE}, node size is proportional to
#'   Expected Influence centrality. If \code{FALSE} (default), all nodes are
#'   the same size.
#' @param detect_communities Logical. If \code{TRUE} (default), runs Louvain
#'   community detection, colors nodes by community, and computes bridge
#'   centrality. If \code{FALSE}, all nodes are colored uniformly and bridge
#'   metrics are omitted.
#' @param max_node_size Numeric. Maximum node diameter in the plot. When
#'   \code{scale_nodes = TRUE}, nodes range from \code{max_node_size * 0.4}
#'   to \code{max_node_size}. When \code{scale_nodes = FALSE}, all nodes are
#'   drawn at \code{max_node_size * 0.67}. Default is \code{30}.
#' @param layout Character. Layout algorithm for node placement. One of:
#'   \describe{
#'     \item{\code{"fr"}}{Fruchterman-Reingold force-directed (default).
#'       Good general-purpose layout.}
#'     \item{\code{"mds"}}{Multidimensional scaling. Places nodes so that
#'       graph distances approximate Euclidean distances — often produces
#'       clean, interpretable plots.}
#'     \item{\code{"kk"}}{Kamada-Kawai spring-based. Similar to FR but
#'       tends to produce more symmetric layouts.}
#'     \item{\code{"circle"}}{Nodes arranged in a circle. Useful for
#'       comparing edge density across the network.}
#'     \item{\code{"drl"}}{DrL distributed recursive layout. Best for
#'       large networks (50+ nodes).}
#'   }
#'
#' @return A named list with the following elements:
#' \describe{
#'   \item{out_centrality}{A tibble of centrality metrics per node (Strength,
#'     Closeness, Betweenness, ExpectedInfluence). If
#'     \code{detect_communities = TRUE}, also includes \code{community},
#'     \code{bridge_strength}, and \code{bridge_expected}. Sorted by
#'     descending ExpectedInfluence.}
#'   \item{out_communities}{(Only when \code{detect_communities = TRUE}) A
#'     tibble with columns \code{node} and \code{community}.}
#'   \item{out_modularity}{(Only when \code{detect_communities = TRUE})
#'     Numeric modularity score (0--1).}
#'   \item{out_pathlengths}{A long-format tibble of shortest path lengths
#'     between all node pairs.}
#'   \item{out_cluster}{Clustering coefficients from
#'     \code{\link[qgraph]{clustcoef_auto}}.}
#'   \item{out_cluster_metrics}{A tibble with columns \code{rowname},
#'     \code{clustWS}, and \code{signed_clustWS}.}
#'   \item{out_small_world}{A one-row data frame of small-world index values.}
#'   \item{corr_matrix}{A tibble of processed pairwise partial correlations.}
#' }
#'
#' @details
#' When \code{detect_communities = TRUE}, the function uses the Louvain
#' algorithm on the absolute-valued adjacency matrix to assign community
#' membership, colors nodes accordingly, and computes bridge centrality via
#' \code{\link[networktools]{bridge}}.
#'
#' When \code{detect_communities = FALSE}, all nodes are colored
#' \code{#3498db} (blue) and bridge centrality is skipped.
#'
#' \strong{Interpreting bridge centrality:} A node with high bridge strength
#' or bridge expected influence connects two otherwise separate communities.
#' Intervening on that factor could propagate effects across both clusters.
#'
#' @section Centrality Metrics:
#' The following metrics are computed via \code{\link[qgraph]{centrality}} and
#' reported in \code{out_centrality}:
#' \describe{
#'   \item{Strength}{Sum of absolute edge weights connected to a node. Measures
#'     how strongly connected an item is overall.}
#'   \item{Expected Influence (EI)}{Sum of edge weights with sign preserved
#'     (Robinaugh et al., 2016). Unlike Strength, negative edges reduce EI.
#'     Identifies nodes that activate vs. suppress the network.}
#'   \item{Closeness}{Inverse of the sum of shortest path lengths to all other
#'     nodes. High values indicate a node can quickly reach the rest of the
#'     network.}
#'   \item{Betweenness}{Proportion of shortest paths between all node pairs
#'     that pass through a given node. Identifies bottleneck or broker nodes
#'     that control information flow.}
#' }
#'
#' @section Bridge Centrality Metrics:
#' Computed via \code{\link[networktools]{bridge}} when
#' \code{detect_communities = TRUE}. Based on Jones, Ma & McNally (2021):
#' \describe{
#'   \item{Bridge Strength}{Sum of absolute edge weights to nodes in
#'     \emph{other} communities. Identifies items that connect different
#'     clusters of attitudes or constructs.}
#'   \item{Bridge Expected Influence}{Same as Bridge Strength but
#'     sign-preserved. Detects items that activate one community while
#'     suppressing another.}
#'   \item{Bridge Closeness}{Shortest-path centrality restricted to nodes in
#'     other communities. Measures how efficiently a node reaches outside its
#'     own cluster.}
#'   \item{Bridge Betweenness}{Frequency a node lies on shortest paths
#'     \emph{between} communities. The true gatekeeper nodes.}
#' }
#'
#' @section References:
#' \itemize{
#'   \item Epskamp, S., Borsboom, D., & Fried, E. I. (2018). Estimating
#'     psychological networks and their accuracy: A tutorial paper.
#'     \emph{Behavior Research Methods}, 50(1), 195--212.
#'   \item Jones, P. J., Ma, R., & McNally, R. J. (2021). Bridge centrality:
#'     A network approach to understanding comorbidity. \emph{Multivariate
#'     Behavioral Research}, 56(2), 353--367.
#'   \item Robinaugh, D. J., Millner, A. J., & McNally, R. J. (2016).
#'     Identifying highly influential nodes in the complicated grief network.
#'     \emph{Journal of Abnormal Psychology}, 125(6), 747--757.
#' }
#'
#' @examples
#' \dontrun{
#' # With community detection (default)
#' result <- run_causal_attitude_network(
#'   df = survey_data, gamma = 0.25, threshold = TRUE,
#'   plot_title = "Employee Attitude Network"
#' )
#'
#' # Without community detection, with scaled nodes
#' result <- run_causal_attitude_network(
#'   df = survey_data, gamma = 0.25, threshold = TRUE,
#'   plot_title = "Attitude Network (Simple)",
#'   detect_communities = FALSE, scale_nodes = TRUE
#' )
#' }
#'
#' @seealso \code{\link{run_dag_discovery}} for directed causal discovery via
#'   the PC algorithm.
#'
#' @importFrom qgraph cor_auto EBICglasso qgraph smallworldness centrality
#'   centralityPlot clustcoef_auto clustWS getWmat
#' @importFrom igraph graph_from_data_frame graph_from_adjacency_matrix
#'   simplify layout_with_fr V E cluster_louvain membership modularity vcount
#' @importFrom grDevices adjustcolor
#' @importFrom networktools bridge
#' @importFrom scales rescale
#' @importFrom dplyr select mutate filter arrange across everything desc
#'   bind_cols left_join
#' @importFrom tidyr pivot_longer pivot_wider
#' @importFrom tibble rownames_to_column tibble
#' @export
run_causal_attitude_network <- function(df, gamma, threshold, plot_title,
                                        scale_nodes = FALSE,
                                        detect_communities = TRUE,
                                        max_node_size = 30,
                                        layout = "fr") {
  
  process_correlation_matrix <- function(CorMat) {
    CorMat %>%
      as.data.frame() %>%
      tibble::rownames_to_column(var = "from") %>%
      tidyr::pivot_longer(cols = -"from", names_to = "to", values_to = "weight") %>%
      dplyr::filter(.data$from < .data$to, .data$weight != 1) %>%
      dplyr::arrange(dplyr::desc(abs(.data$weight))) %>%
      dplyr::mutate(reweight = scales::rescale(.data$weight)) %>%
      dplyr::filter(.data$reweight > 0.25)
  }
  
  create_network_plot <- function(edge_file, plot_title, node_names,
                                  centrality_scores,
                                  communities = NULL, scale_nodes = FALSE) {
    set.seed(12345)
    g <- igraph::graph_from_data_frame(edge_file, directed = FALSE) %>%
      igraph::simplify(edge.attr.comb = list(weight = "mean"))
    
    edge_sign <- sign(igraph::E(g)$weight)
    node_order <- match(igraph::V(g)$name, node_names)
    
    # Node colors
    comm_palette <- c("#e74c3c", "#9b59b6", "#3498db", "#2ecc71",
                      "#f1c40f", "#e67e22", "#16a085", "#34495e",
                      "#1abc9c", "#c0392b", "#8e44ad", "#2980b9")
    if (!is.null(communities)) {
      igraph::V(g)$color <- grDevices::adjustcolor(
        comm_palette[(communities[node_order] %% length(comm_palette)) + 1],
        alpha.f = 0.7
      )
      igraph::V(g)$frame.color <- comm_palette[
        (communities[node_order] %% length(comm_palette)) + 1
      ]
    } else {
      igraph::V(g)$color <- "#ecf0f1"
      igraph::V(g)$frame.color <- "#34495e"
    }
    
    # Node size
    if (scale_nodes) {
      cent_ordered <- centrality_scores[node_order]
      igraph::V(g)$size <- scales::rescale(abs(cent_ordered), to = c(max_node_size * 0.4, max_node_size))
    } else {
      igraph::V(g)$size <- max_node_size * 0.67
    }
    
    # Edge aesthetics
    igraph::E(g)$color <- ifelse(
      edge_sign >= 0,
      grDevices::adjustcolor("#3498db", alpha.f = 0.6),
      grDevices::adjustcolor("#e74c3c", alpha.f = 0.6)
    )
    igraph::E(g)$width <- scales::rescale(
      abs(igraph::E(g)$weight), to = c(0.5, 5)
    )
    
    # Layout — abs() to avoid negative weight error
    set.seed(42)
    layout_weights <- abs(igraph::E(g)$weight)
    layout_weights[layout_weights == 0] <- 0.001
    layout_fn <- switch(layout,
                        fr     = function(g) igraph::layout_with_fr(g, weights = layout_weights),
                        mds    = igraph::layout_with_mds,
                        kk     = function(g) igraph::layout_with_kk(g, weights = layout_weights),
                        circle = igraph::layout_in_circle,
                        drl    = function(g) igraph::layout_with_drl(g, weights = layout_weights),
                        stop("Unknown layout: ", layout, ". Use fr, mds, kk, circle, or drl.")
    )
    laycords <- layout_fn(g) %>%
      apply(2, function(x) (x - min(x)) / (max(x) - min(x)) * 0.8 + 0.1)
    
    graphics::par(bg = "white", mar = c(1, 2, 2, 1))
    plot(g,
         layout              = laycords,
         vertex.frame.color  = igraph::V(g)$frame.color,
         vertex.frame.width  = 1.5,
         vertex.label.cex    = igraph::V(g)$size / max_node_size * 0.8,
         vertex.label.color  = "grey20",
         vertex.label.family = "sans",
         vertex.label.dist   = 0,
         edge.curved         = 0.15
    )
    graphics::title(plot_title, cex.main = 1.3, font.main = 1, col.main = "grey20")
    
    # Legend
    legend_labels <- c("Positive edge", "Negative edge")
    legend_cols   <- c("#3498db", "#e74c3c")
    legend_lty    <- c(1, 1)
    legend_pch    <- c(NA, NA)
    
    if (!is.null(communities)) {
      n_comm <- length(unique(communities))
      legend_labels <- c(legend_labels, "", paste("Community", seq_len(n_comm)))
      legend_cols   <- c(legend_cols, NA, comm_palette[seq_len(n_comm)])
      legend_lty    <- c(legend_lty, NA, rep(NA, n_comm))
      legend_pch    <- c(legend_pch, NA, rep(16, n_comm))
    }
    
    graphics::legend("bottomleft",
                     legend = legend_labels, col = legend_cols,
                     lty = legend_lty, pch = legend_pch,
                     lwd = 2, pt.cex = 1.5, cex = 0.7, bty = "n", text.col = "grey30"
    )
    
    if (scale_nodes) {
      graphics::legend("bottomright",
                       legend = "Node size = Expected Influence",
                       cex = 0.65, bty = "n", text.col = "grey50"
      )
    }
  }
  
  # Scale numeric columns
  wd <- df %>%
    dplyr::select(where(is.numeric)) %>%
    dplyr::mutate(dplyr::across(dplyr::everything(), scale))
  
  # Estimate regularized partial correlation network
  CorMat <- qgraph::cor_auto(wd)
  calc_graph <- qgraph::EBICglasso(CorMat, nrow(wd), gamma, threshold = threshold)
  out_graph <- qgraph::qgraph(calc_graph, layout = "spring",
                              vsize = 3, esize = 2, label.cex = 1, labels = colnames(wd))
  
  # Centrality metrics
  out_small_world <- qgraph::smallworldness(out_graph)
  temp_path <- qgraph::centrality(out_graph)
  out_centrality <- qgraph::centralityPlot(out_graph, include = "all")$data %>%
    tidyr::pivot_wider(id_cols = "node", names_from = "measure",
                       values_from = "value") %>%
    dplyr::arrange(dplyr::desc(.data$ExpectedInfluence))
  
  # Community detection (optional)
  community_df   <- NULL
  out_modularity <- NULL
  comm_membership <- NULL
  
  if (detect_communities) {
    adj_matrix <- qgraph::getWmat(out_graph)
    ig <- igraph::graph_from_adjacency_matrix(
      abs(adj_matrix), mode = "undirected", weighted = TRUE, diag = FALSE
    )
    communities <- igraph::cluster_louvain(ig)
    comm_membership <- igraph::membership(communities)
    
    community_df <- tibble::tibble(
      node      = colnames(wd),
      community = comm_membership
    )
    out_modularity <- igraph::modularity(communities)
    
    out_centrality <- out_centrality %>%
      dplyr::left_join(community_df, by = "node")
    
    # Bridge centrality
    bridge <- networktools::bridge(out_graph,
                                   communities = community_df$community)
    bridge_df <- tibble::tibble(
      node            = colnames(wd),
      bridge_strength = bridge$`Bridge Strength`,
      bridge_expected = bridge$`Bridge Expected Influence (1-step)`
    )
    out_centrality <- out_centrality %>%
      dplyr::left_join(bridge_df, by = "node")
  }
  
  # Plot
  edge_df <- process_correlation_matrix(CorMat)
  ei_scores <- temp_path$InExpectedInfluence
  names(ei_scores) <- colnames(wd)
  create_network_plot(edge_df, plot_title, colnames(wd), ei_scores,
                      communities = comm_membership, scale_nodes = scale_nodes)
  
  # --- Interpretation ---
  n_nodes <- ncol(wd)
  n_edges <- nrow(edge_df)
  top3_cent <- utils::head(out_centrality, 3)
  
  cat(sprintf("\n%s Causal Attitude Network Results %s\n",
              strrep("-", 10), strrep("-", 10)))
  cat("\n")
  cat(sprintf("  Nodes: %d | Edges (filtered): %d | Gamma: %s\n",
              n_nodes, n_edges, gamma))
  cat(sprintf("  Small-world index: %.2f\n",
              as.numeric(out_small_world[1])))
  cat("\n")
  cat("  Blue edges = positive partial correlations (co-activation).\n")
  cat("  Red edges  = negative partial correlations (suppression).\n")
  cat("  Edge width = strength of the relationship.\n\n")
  
  cat("  Top nodes by Expected Influence:\n")
  for (i in seq_len(nrow(top3_cent))) {
    cat(sprintf("    %d. %s  (EI = %.3f)\n",
                i, top3_cent$node[i], top3_cent$ExpectedInfluence[i]))
  }
  cat("\n  High EI nodes activate the network when increased.\n")
  
  if (detect_communities) {
    n_comm <- length(unique(community_df$community))
    cat(sprintf("\n  Communities detected: %d (modularity = %.3f)\n",
                n_comm, out_modularity))
    
    top_bridge <- out_centrality %>%
      dplyr::arrange(dplyr::desc(abs(.data$bridge_expected))) %>%
      utils::head(3)
    cat("  Top bridge nodes (connect communities):\n")
    for (i in seq_len(nrow(top_bridge))) {
      cat(sprintf("    %d. %s  (bridge EI = %.3f)\n",
                  i, top_bridge$node[i], top_bridge$bridge_expected[i]))
    }
    cat("  Bridge nodes are intervention targets — they propagate effects\n")
    cat("  across communities.\n")
  }
  cat("\n")
  
  # Build output list
  out <- list(
    out_centrality      = out_centrality,
    out_pathlengths     = tibble::rownames_to_column(
      as.data.frame(temp_path$ShortestPathLengths)
    ) %>%
      tidyr::pivot_longer(-1, names_to = "metric", values_to = "value",
                          values_drop_na = FALSE) %>%
      dplyr::mutate(value = as.numeric(.data$value)),
    out_cluster         = qgraph::clustcoef_auto(out_graph,
                                                 thresholdWS = 0, thresholdON = 0),
    out_cluster_metrics = tibble::rownames_to_column(
      dplyr::bind_cols(
        as.data.frame(temp_path$ShortestPathLengths),
        qgraph::clustWS(out_graph)
      )
    ) %>%
      dplyr::select("rowname", "clustWS", "signed_clustWS"),
    out_small_world     = as.data.frame(t(out_small_world)) %>%
      stats::setNames(names(out_small_world)),
    corr_matrix         = edge_df
  )
  
  if (detect_communities) {
    out$out_communities <- community_df
    out$out_modularity  <- out_modularity
  }
  
  out
}