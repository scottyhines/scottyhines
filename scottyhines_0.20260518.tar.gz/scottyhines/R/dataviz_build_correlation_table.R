#' Create a Correlation Heatmap
#' 
#' @description
#' Creates a heatmap visualization of correlation values between network metrics and criterion measures.
#' The function uses ggplot2 to generate a tile-based heatmap with customized styling and the viridis
#' color palette.
#' 
#' @param build_correlation_table A correlation matrix/data frame containing the correlation values
#' @param title Character string for plot title (default: "Relationship of Network Metrics to Criterion Measures:")
#' @param subtitle Character string for plot subtitle (default: "Data: Forte Network Metrics | Connections Responses")
#' @param caption Character string for plot caption (default: "Plot: T&D Science (hinessco@)")
#' @param xlab Character string for x-axis label (default: "Criterion Measure")
#' @param ylab Character string for y-axis label (default: "Network Metric")
#' 
#' @details
#' The function performs the following operations:
#' - Converts row names to a column
#' - Pivots the data to long format
#' - Removes correlations with absolute values less than 0.05 (sets them to NA)
#' - Creates a heatmap with customized theming
#' 
#' @return A ggplot2 object containing the correlation heatmap
#' @export
create_correlation_plot <- function(build_correlation_table, 
                                    title = "Relationship of Network Metrics to Criterion Measures:",
                                    subtitle = "Data: Forte Network Metrics | Connections Responses",
                                    caption = "Plot: T&D Science (hinessco@)",
                                    xlab = "Criterion Measure",
                                    ylab = "Network Metric") {
  
  build_correlation_table %>% 
    tibble::rownames_to_column(var = "term") %>%
    tidyr::pivot_longer(-term,
                        names_to = "metric",
                        values_to = "value") %>%  
    dplyr::mutate(value = ifelse(abs(value) <= .04999, NA, value)) %>%
    ggplot(aes(metric, y = reorder(term, desc(term)), fill = value)) +
    geom_tile(linewidth = 1, color = "#F0F0F0") +
    coord_fixed() +
    scale_fill_gradientn(colours = viridis::viridis(50, option = "viridis")) +
    labs(
      title = title,
      subtitle = subtitle,
      caption = caption
    ) +
    xlab(xlab) +
    ylab(ylab) +
    theme(
      plot.title.position = "plot",
      plot.caption.position = "plot",
      plot.title = element_text(face = "bold", size = rel(1.2)),
      plot.subtitle = element_text(face = "bold", size = rel(1)),
      plot.caption = element_text(size = rel(.8), hjust = 0, color = "grey40", face = "bold"),
      legend.position = "top",
      axis.text.x = element_text(angle = 270, hjust = 0, vjust = 0.2, size = rel(.8)),
      axis.text.y = element_text(color = "black", size = rel(.8)),
      axis.title.x = element_text(size = rel(1)),
      axis.title.y = element_text(size = rel(1)),
      legend.justification = c(0.35, 0.8),
      legend.key.width = unit(20, "mm"),
      legend.key.height = unit(4, "mm"),
      panel.grid.minor.x = element_line(color = "#D2D2D2")
    )
}
