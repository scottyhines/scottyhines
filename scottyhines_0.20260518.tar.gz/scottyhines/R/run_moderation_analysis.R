#' Run Moderation Analysis (X * W -> Y) With Optional Covariates
#'
#' Fits a moderation model for every combination of outcome (Y), predictor of
#' interest (X), and moderator (W), optionally adjusting for a shared set of
#' covariates. Each model is:
#'   \code{Y ~ controls + X * W}
#' which estimates main effects of X and W, plus the X:W interaction.
#'
#' The function auto-fits with \code{stats::lm} when Y is continuous and
#' \code{stats::glm(family = binomial)} when Y is binary. A variable is
#' treated as binary when it is logical, a 2-level factor / character, or a
#' numeric column whose only values are 0 and 1. The actual family used is
#' reported in the output tables.
#'
#' Beyond the model coefficients, the function reports \strong{simple slopes}
#' of X at meaningful levels of W:
#' \itemize{
#'   \item Continuous W: slope of X at W = mean - 1 SD, mean, mean + 1 SD.
#'   \item Categorical / binary W (factor / character / logical / 0-1 numeric): slope of X at each level of W.
#' }
#' Slope p-values are computed from the model variance-covariance matrix. For
#' logistic models the slope is on the log-odds scale; the corresponding
#' \code{odds_ratio} is also reported.
#'
#' @param data A data.frame.
#' @param outcome_vars Character vector of outcome (Y) variable names.
#' @param interest_vars Character vector of predictor (X) variable names to iterate over.
#' @param moderator_vars Character vector of moderator (W) variable names to iterate over.
#' @param control_vars Optional character vector of covariates always included.
#' @param scale_numeric Logical. If TRUE, continuous numeric outcome / predictor / moderator / control columns are z-score scaled before fitting. Binary 0/1 columns are left untouched. Default FALSE.
#' @section How to read the output:
#' \strong{Start with} \code{moderation_summary} -- one row per Y / X / W
#' triplet. The headline columns:
#' \itemize{
#'   \item \code{interaction_min_p_value} -- the moderation test. If it is
#'     not below 0.05, there is \strong{no moderation}: the slope of X on Y
#'     does not depend on W. The simple slopes you see across W levels are
#'     just the same effect evaluated at different points; do not interpret
#'     them as evidence that W changes the relationship.
#'   \item \code{moderation_type} -- one of "no moderation", "moderation
#'     (magnitude change)", or "moderation (sign flip)".
#'   \item \code{slope_min} / \code{slope_max} / \code{slope_range} -- how
#'     much the slope of X changes across the levels of W. A wide range with
#'     a non-significant interaction usually means a noisy estimate, not a
#'     real moderation.
#'   \item \code{interpretation} -- one-line plain-English summary.
#' }
#'
#' \code{simple_slopes} gives the slope of X on Y at meaningful values of W:
#' \itemize{
#'   \item Continuous W -> mean - 1 SD, mean, mean + 1 SD.
#'   \item Categorical W -> each level.
#'   \item Binary W (0/1 or logical) -> at W = 0 and W = 1.
#' }
#' Each slope row has its own \code{interpretation}, \code{significant}, and
#' \code{direction} helper columns. For logistic models, \code{odds_ratio} is
#' the multiplicative effect on odds(Y = 1) per unit of X at that level of W.
#'
#' Also worth knowing: a slope at one level of W can be significant on its
#' own even when the interaction itself is not -- that is fine, and exactly
#' what \code{moderation_summary} prevents you from misreading. Significant
#' simple slopes without a significant interaction means X does predict Y,
#' but not in a way that changes meaningfully with W.
#'
#' @return A list with five elements:
#' \describe{
#'   \item{coefficients}{Tidy coefficients for every Y / X / W model, tagged with metadata and the family used.}
#'   \item{simple_slopes}{Slope of X at meaningful levels of W with SE, t (or z for glm), p, odds ratio when logistic, plus helper columns \code{significant}, \code{direction}, and a plain-English \code{interpretation}.}
#'   \item{moderation_summary}{One row per Y / X / W triplet with the X:W interaction test (the actual moderation test), slope range across W, classification, and a plain-English \code{interpretation}.}
#'   \item{model_fit}{R-squared (McFadden's pseudo-R² for glm), AIC, BIC, n_obs, residual SE per model, plus the family used.}
#'   \item{legend}{A list with two data.frames -- \code{simple_slopes} and \code{moderation_summary} -- describing each column in plain English.}
#' }
#' @export
run_moderation_analysis <- function(data,
                                    outcome_vars,
                                    interest_vars,
                                    moderator_vars,
                                    control_vars = NULL,
                                    scale_numeric = FALSE) {
  options(warn = -1)
  on.exit(options(warn = 0), add = TRUE)

  stopifnot(is.data.frame(data))
  stopifnot(is.character(outcome_vars), length(outcome_vars) >= 1)
  stopifnot(is.character(interest_vars), length(interest_vars) >= 1)
  stopifnot(is.character(moderator_vars), length(moderator_vars) >= 1)
  if (!is.null(control_vars)) stopifnot(is.character(control_vars))

  # Detect binary variables
  is_binary_var <- function(x) {
    x_clean <- x[!is.na(x)]
    if (length(x_clean) == 0) return(FALSE)
    if (is.logical(x_clean)) return(TRUE)
    if (is.factor(x_clean)) return(length(levels(droplevels(x_clean))) == 2)
    if (is.character(x_clean)) return(length(unique(x_clean)) == 2)
    if (is.numeric(x_clean)) {
      u <- unique(x_clean)
      return(length(u) == 2 && all(u %in% c(0, 1)))
    }
    FALSE
  }

  # Coerce a binary outcome to 0/1 numeric so glm sees a clean response
  coerce_binary_numeric <- function(x) {
    if (is.logical(x)) return(as.integer(x))
    if (is.factor(x))  return(as.integer(x) - 1L)
    if (is.character(x)) {
      u <- sort(unique(x[!is.na(x)]))
      if (length(u) == 2) return(as.integer(x == u[length(u)]))
      return(x)
    }
    x
  }

  # Scale numeric columns if requested -- skip binary 0/1 columns
  if (scale_numeric) {
    all_vars <- unique(c(outcome_vars, interest_vars, moderator_vars, control_vars))
    for (v in all_vars) {
      if (v %in% names(data) && is.numeric(data[[v]]) && !is_binary_var(data[[v]])) {
        data[[v]] <- as.numeric(scale(data[[v]]))
      }
    }
  }

  # Pre-coerce binary outcomes to 0/1 numeric
  for (v in outcome_vars) {
    if (v %in% names(data) && is_binary_var(data[[v]])) {
      data[[v]] <- coerce_binary_numeric(data[[v]])
    }
  }

  controls_rhs <- function(controls) {
    if (is.null(controls) || length(controls) == 0) return("")
    paste0(paste(controls, collapse = " + "), " + ")
  }

  rsq <- function(fit) {
    if (inherits(fit, "lm") && !inherits(fit, "glm")) return(summary(fit)$r.squared)
    if (inherits(fit, "glm")) {
      d  <- stats::deviance(fit); d0 <- fit$null.deviance
      if (is.finite(d) && is.finite(d0) && d0 > 0) return(1 - d / d0)
    }
    NA_real_
  }

  coef_rows <- list()
  slope_rows <- list()
  fit_rows <- list()
  summary_rows <- list()

  total_iterations <- length(outcome_vars) * length(interest_vars) * length(moderator_vars)
  pb <- txtProgressBar(min = 0, max = total_iterations, style = 3)
  current_iteration <- 0

  for (outcome_var in outcome_vars) {
    y_binary <- outcome_var %in% names(data) && is_binary_var(data[[outcome_var]])

    for (predictor_var in interest_vars) {
      for (moderator_var in moderator_vars) {

        # Skip degenerate triplets
        if (any(duplicated(c(outcome_var, predictor_var, moderator_var)))) {
          current_iteration <- current_iteration + 1
          setTxtProgressBar(pb, current_iteration)
          next
        }

        tryCatch({
          ctrl <- controls_rhs(control_vars)
          formula_str <- paste0(outcome_var, " ~ ", ctrl,
                                predictor_var, " * ", moderator_var)
          fm <- stats::as.formula(formula_str)

          # Fit lm or glm depending on Y
          if (y_binary) {
            fit <- stats::glm(fm, data = data, family = stats::binomial())
            fam <- "binomial"
            is_glm <- TRUE
          } else {
            fit <- stats::lm(fm, data = data)
            fam <- "gaussian"
            is_glm <- FALSE
          }
          s <- summary(fit)

          # Coefficients
          tidy_model <- broom::tidy(fit)
          tidy_model$family             <- fam
          tidy_model$outcome_variable   <- outcome_var
          tidy_model$predictor_variable <- predictor_var
          tidy_model$moderator_variable <- moderator_var
          tidy_model$formula            <- formula_str

          key_base <- paste(outcome_var, predictor_var, moderator_var, sep = "__")
          coef_rows[[key_base]] <- tidy_model

          # Model fit
          if (is_glm) {
            f_stat <- NA_real_; f_p <- NA_real_; resid_se <- NA_real_
          } else {
            fstat <- if (!is.null(s$fstatistic)) s$fstatistic else c(NA_real_, NA_real_, NA_real_)
            f_stat <- unname(fstat[1])
            f_p <- if (all(is.finite(fstat))) {
              unname(stats::pf(fstat[1], fstat[2], fstat[3], lower.tail = FALSE))
            } else NA_real_
            resid_se <- s$sigma
          }
          fit_rows[[key_base]] <- data.frame(
            outcome_variable   = outcome_var,
            predictor_variable = predictor_var,
            moderator_variable = moderator_var,
            family             = fam,
            formula            = formula_str,
            r_squared          = rsq(fit),
            f_statistic        = f_stat,
            f_pvalue           = f_p,
            aic                = stats::AIC(fit),
            bic                = stats::BIC(fit),
            n_obs              = stats::nobs(fit),
            residual_se        = resid_se,
            stringsAsFactors   = FALSE
          )

          # Simple slopes: slope of X at meaningful levels of W
          coefs <- stats::coef(fit)
          vc    <- stats::vcov(fit)
          coef_names <- names(coefs)

          # Find the X main-effect coefficient name
          x_main_name <- predictor_var
          if (!(x_main_name %in% coef_names)) {
            cand <- coef_names[startsWith(coef_names, predictor_var) & !grepl(":", coef_names, fixed = TRUE)]
            x_main_name <- if (length(cand) >= 1) cand[1] else NA_character_
          }

          # Identify all interaction coef names involving X *and* the moderator
          int_names <- coef_names[grepl(":", coef_names, fixed = TRUE)]
          int_names <- int_names[vapply(int_names, function(nm) {
            parts <- strsplit(nm, ":", fixed = TRUE)[[1]]
            on_x <- predictor_var %in% parts || any(startsWith(parts, predictor_var))
            on_w <- moderator_var %in% parts || any(startsWith(parts, moderator_var))
            on_x && on_w
          }, logical(1))]

          # Choose df / distribution for slope p-values
          residual_df <- if (is_glm) NA_real_ else fit$df.residual

          add_slope_row <- function(level_label, level_value, contrib_names, contrib_values) {
            present <- contrib_names %in% coef_names
            contrib_names  <- contrib_names[present]
            contrib_values <- contrib_values[present]
            sel <- c(x_main_name, contrib_names)
            sel <- sel[!is.na(sel)]
            sel <- sel[sel %in% coef_names]
            if (length(sel) == 0) return(NULL)
            wts <- c(1, contrib_values)[seq_along(sel)]
            est <- sum(coefs[sel] * wts)
            v   <- as.numeric(t(wts) %*% vc[sel, sel, drop = FALSE] %*% wts)
            se  <- if (is.finite(v) && v >= 0) sqrt(v) else NA_real_
            stat <- if (is.finite(se) && se > 0) est / se else NA_real_
            pval <- if (is.finite(stat)) {
              if (is_glm) {
                2 * stats::pnorm(-abs(stat))
              } else if (is.finite(residual_df) && residual_df > 0) {
                2 * stats::pt(-abs(stat), df = residual_df)
              } else NA_real_
            } else NA_real_

            # Per-slope interpretation
            sig_flag <- isTRUE(is.finite(pval) && pval < 0.05)
            direction <- if (!is.finite(est) || abs(est) < .Machine$double.eps) {
              "n/a"
            } else if (est > 0) {
              "positive"
            } else {
              "negative"
            }
            unit_phrase <- if (is_glm) {
              "log-odds of Y"
            } else {
              "Y"
            }
            level_phrase <- if (!is.na(suppressWarnings(as.numeric(level_value)))) {
              sprintf("at %s = %.3f", moderator_var, as.numeric(level_value))
            } else {
              sprintf("at %s = '%s'", moderator_var, level_label)
            }
            sig_phrase <- if (sig_flag) "(significant)" else "(not significant)"
            interp <- if (is.finite(est)) {
              if (is_glm) {
                sprintf("%s: each unit of %s changes the %s by %.3f (OR = %.3f) %s.",
                        level_phrase, predictor_var, unit_phrase,
                        est, exp(est), sig_phrase)
              } else {
                sprintf("%s: each unit of %s changes %s by %.3f %s.",
                        level_phrase, predictor_var, unit_phrase,
                        est, sig_phrase)
              }
            } else {
              "Slope could not be estimated."
            }

            data.frame(
              outcome_variable   = outcome_var,
              predictor_variable = predictor_var,
              moderator_variable = moderator_var,
              family             = fam,
              moderator_level    = level_label,
              moderator_value    = suppressWarnings(as.numeric(level_value)),
              slope_estimate     = est,
              slope_se           = se,
              slope_statistic    = stat,
              slope_p_value      = pval,
              odds_ratio         = if (is_glm) exp(est) else NA_real_,
              significant        = sig_flag,
              direction          = direction,
              interpretation     = interp,
              formula            = formula_str,
              stringsAsFactors   = FALSE
            )
          }

          mod_col <- data[[moderator_var]]
          slopes_for_this <- list()

          # Continuous moderator -> evaluate at mean +/- 1 SD (excludes binary 0/1)
          if (is.numeric(mod_col) && !is_binary_var(mod_col)) {
            mw <- mean(mod_col, na.rm = TRUE)
            sw <- stats::sd(mod_col, na.rm = TRUE)
            levels_to_eval <- list(
              list(label = "mean_minus_1sd", value = mw - sw),
              list(label = "mean",           value = mw),
              list(label = "mean_plus_1sd",  value = mw + sw)
            )
            for (lvl in levels_to_eval) {
              contrib_vals <- rep(lvl$value, length(int_names))
              row <- add_slope_row(lvl$label, lvl$value, int_names, contrib_vals)
              if (!is.null(row)) slopes_for_this[[lvl$label]] <- row
            }
          } else {
            # Categorical / binary moderator -> slope at each level
            if (is.numeric(mod_col)) {
              # Numeric 0/1 binary: evaluate slope at W=0 (no interaction contribution)
              # and W=1 (X coef + X:W coef). No factor-level coef gymnastics needed.
              row0 <- add_slope_row("0", 0, character(0), numeric(0))
              row1 <- add_slope_row("1", 1, int_names, rep(1, length(int_names)))
              if (!is.null(row0)) slopes_for_this[["0"]] <- row0
              if (!is.null(row1)) slopes_for_this[["1"]] <- row1
            } else {
              if (is.logical(mod_col)) mod_col <- factor(mod_col)
              if (!is.factor(mod_col)) mod_col <- factor(mod_col)
              lvls <- levels(mod_col)
              for (lvl in lvls) {
                # Ref level: no interaction contribution.
                # Non-ref level: the X:Wlvl (or Wlvl:X) coef gets weight 1.
                contrib_names_lvl <- character(0)
                contrib_vals_lvl <- numeric(0)
                if (length(int_names) > 0) {
                  expected <- c(paste0(predictor_var, ":", moderator_var, lvl),
                                paste0(moderator_var, lvl, ":", predictor_var))
                  hit <- intersect(expected, int_names)
                  if (length(hit) > 0) {
                    contrib_names_lvl <- hit[1]
                    contrib_vals_lvl  <- 1
                  }
                }
                row <- add_slope_row(lvl, NA_real_, contrib_names_lvl, contrib_vals_lvl)
                if (!is.null(row)) slopes_for_this[[lvl]] <- row
              }
            }
          }

          if (length(slopes_for_this) > 0) {
            slope_rows[[key_base]] <- do.call(rbind, slopes_for_this)
          }

          # ---- Moderation summary row ----
          # Pull the X:W interaction term test from tidy(fit). For continuous W
          # there is one row; for a factor W with k levels there are k-1
          # interaction rows -- we report the smallest p among them as the
          # omnibus indicator, plus the count of significant interaction rows.
          int_terms_in_tidy <- tidy_model[grepl(":", tidy_model$term, fixed = TRUE) &
                                          (grepl(predictor_var, tidy_model$term, fixed = TRUE) |
                                           startsWith(tidy_model$term, predictor_var)) &
                                          (grepl(moderator_var, tidy_model$term, fixed = TRUE) |
                                           startsWith(tidy_model$term, moderator_var)), , drop = FALSE]

          if (nrow(int_terms_in_tidy) >= 1) {
            interaction_term       <- int_terms_in_tidy$term[which.min(int_terms_in_tidy$p.value)]
            interaction_estimate   <- int_terms_in_tidy$estimate[which.min(int_terms_in_tidy$p.value)]
            interaction_se         <- int_terms_in_tidy$std.error[which.min(int_terms_in_tidy$p.value)]
            interaction_min_p      <- min(int_terms_in_tidy$p.value, na.rm = TRUE)
            n_interaction_terms    <- nrow(int_terms_in_tidy)
            n_interaction_sig      <- sum(int_terms_in_tidy$p.value < 0.05, na.rm = TRUE)
          } else {
            interaction_term <- NA_character_
            interaction_estimate <- NA_real_
            interaction_se <- NA_real_
            interaction_min_p <- NA_real_
            n_interaction_terms <- 0L
            n_interaction_sig   <- 0L
          }

          interaction_significant <- isTRUE(is.finite(interaction_min_p) && interaction_min_p < 0.05)

          # Slope summary across levels of W
          if (!is.null(slope_rows[[key_base]]) && nrow(slope_rows[[key_base]]) > 0) {
            slopes_df    <- slope_rows[[key_base]]
            slope_min    <- min(slopes_df$slope_estimate, na.rm = TRUE)
            slope_max    <- max(slopes_df$slope_estimate, na.rm = TRUE)
            slope_range  <- slope_max - slope_min
            n_slopes_sig <- sum(slopes_df$slope_p_value < 0.05, na.rm = TRUE)
            n_slopes     <- nrow(slopes_df)
            sign_flips   <- length(unique(sign(slopes_df$slope_estimate[is.finite(slopes_df$slope_estimate) &
                                                                         slopes_df$slope_estimate != 0]))) > 1
          } else {
            slope_min <- NA_real_; slope_max <- NA_real_; slope_range <- NA_real_
            n_slopes_sig <- 0L; n_slopes <- 0L; sign_flips <- FALSE
          }

          # Classification:
          #   - "no moderation"          : interaction not significant
          #   - "moderation (sign flip)" : interaction sig + slope changes sign across W
          #   - "moderation (magnitude)" : interaction sig, slope same sign but size differs
          moderation_type <- if (!interaction_significant) {
            "no moderation"
          } else if (sign_flips) {
            "moderation (sign flip)"
          } else {
            "moderation (magnitude change)"
          }

          # One-line interpretation
          format_p <- function(p) {
            if (!is.finite(p)) return("p = NA")
            if (p < 0.001)     return("p < .001")
            sprintf("p = %.3f", p)
          }
          unit_phrase <- if (is_glm) "log-odds of Y" else "Y"
          summary_interp <- if (!interaction_significant) {
            if (is.finite(interaction_min_p)) {
              sprintf("No significant moderation: %s's effect on %s does not depend on %s (interaction %s). The slopes you see across W levels are essentially the same effect, just evaluated at different points.",
                      predictor_var, outcome_var, moderator_var, format_p(interaction_min_p))
            } else {
              sprintf("No interaction term available to test moderation of %s on %s by %s.",
                      predictor_var, outcome_var, moderator_var)
            }
          } else {
            sprintf("%s: %s's effect on %s depends on %s (interaction %s). Slope of %s on %s ranges from %.3f to %.3f across the levels of %s; %d of %d simple slopes are individually significant.",
                    tools::toTitleCase(moderation_type),
                    predictor_var, outcome_var, moderator_var,
                    format_p(interaction_min_p),
                    predictor_var, unit_phrase,
                    slope_min, slope_max, moderator_var,
                    n_slopes_sig, n_slopes)
          }

          summary_rows[[key_base]] <- data.frame(
            outcome_variable        = outcome_var,
            predictor_variable      = predictor_var,
            moderator_variable      = moderator_var,
            family                  = fam,
            interaction_term        = interaction_term,
            interaction_estimate    = interaction_estimate,
            interaction_se          = interaction_se,
            interaction_min_p_value = interaction_min_p,
            interaction_significant = interaction_significant,
            n_interaction_terms     = n_interaction_terms,
            n_interaction_sig       = n_interaction_sig,
            slope_min               = slope_min,
            slope_max               = slope_max,
            slope_range             = slope_range,
            n_simple_slopes         = n_slopes,
            n_simple_slopes_sig     = n_slopes_sig,
            slope_sign_flips        = sign_flips,
            moderation_type         = moderation_type,
            interpretation          = summary_interp,
            formula                 = formula_str,
            stringsAsFactors        = FALSE
          )

          current_iteration <- current_iteration + 1
          setTxtProgressBar(pb, current_iteration)
        }, error = function(e) {
          error_msg <- sprintf("ERROR: Failed moderation Y='%s' X='%s' W='%s'\n  Error: %s",
                               outcome_var, predictor_var, moderator_var, e$message)
          message(error_msg)
        })
      }
    }
  }

  close(pb)
  cat("\n")

  final_coefs   <- do.call(rbind, coef_rows);    rownames(final_coefs)   <- NULL
  final_slopes  <- do.call(rbind, slope_rows);   rownames(final_slopes)  <- NULL
  final_fit     <- do.call(rbind, fit_rows);     rownames(final_fit)     <- NULL
  final_summary <- do.call(rbind, summary_rows); rownames(final_summary) <- NULL

  legend_slopes <- data.frame(
    column = c(
      "outcome_variable", "predictor_variable", "moderator_variable",
      "family", "moderator_level", "moderator_value",
      "slope_estimate", "slope_se", "slope_statistic", "slope_p_value",
      "odds_ratio", "significant", "direction", "interpretation"
    ),
    description = c(
      "Y -- the outcome variable.",
      "X -- the predictor whose slope on Y we are inspecting.",
      "W -- the moderator variable that may change X's effect.",
      "Model family used. gaussian = OLS, binomial = logistic.",
      "Label for the W value the slope is evaluated at: 'mean_minus_1sd' / 'mean' / 'mean_plus_1sd' for continuous W, factor level for categorical W, '0' / '1' for binary W.",
      "Numeric value of W for that level (NA for non-numeric levels).",
      "Slope of X on Y at this level of W. For logistic models this is on the log-odds scale.",
      "Standard error of the simple slope.",
      "Test statistic for the slope (t for OLS, z for logistic).",
      "p-value for the slope. p < 0.05 -> X significantly predicts Y at this level of W.",
      "exp(slope_estimate) for logistic models. Multiplicative effect on the odds of Y per unit of X. NA for OLS.",
      "TRUE if slope_p_value < 0.05.",
      "Sign of the slope (positive / negative / n/a).",
      "One-line plain-English summary of the slope at this level of W."
    ),
    stringsAsFactors = FALSE
  )

  legend_summary <- data.frame(
    column = c(
      "outcome_variable", "predictor_variable", "moderator_variable", "family",
      "interaction_term", "interaction_estimate", "interaction_se",
      "interaction_min_p_value", "interaction_significant",
      "n_interaction_terms", "n_interaction_sig",
      "slope_min", "slope_max", "slope_range",
      "n_simple_slopes", "n_simple_slopes_sig", "slope_sign_flips",
      "moderation_type", "interpretation", "formula"
    ),
    description = c(
      "Y -- the outcome variable.",
      "X -- the predictor whose slope on Y is being moderated.",
      "W -- the moderator. The X:W interaction is the moderation test.",
      "Model family used. gaussian = OLS, binomial = logistic.",
      "Name of the interaction term in the model (e.g., 'X:W'). For factor W with k levels there are k-1 such terms; the smallest-p term is reported here.",
      "Coefficient on the interaction term. For logistic, on log-odds scale.",
      "Standard error of the interaction coefficient.",
      "Smallest interaction p-value across all X:W terms. The headline test for moderation -- if this is < 0.05, moderation is present.",
      "TRUE if interaction_min_p_value < 0.05. The thing to read first.",
      "How many X:W interaction terms exist in the model (>1 only for factor W with >2 levels).",
      "How many of those interaction terms are individually significant.",
      "Smallest simple slope of X across the levels of W.",
      "Largest simple slope of X across the levels of W.",
      "slope_max minus slope_min. How much the X effect changes across W.",
      "Number of simple slopes evaluated (3 for continuous W, k for factor W with k levels, 2 for binary W).",
      "How many simple slopes have p < 0.05.",
      "TRUE if the slope of X changes sign across the levels of W (e.g., positive at low W and negative at high W).",
      "Classification: 'no moderation', 'moderation (magnitude change)', or 'moderation (sign flip)'.",
      "One-line plain-English summary of moderation for this Y / X / W combination.",
      "Model formula used."
    ),
    stringsAsFactors = FALSE
  )

  return(list(
    coefficients       = janitor::clean_names(final_coefs),
    simple_slopes      = janitor::clean_names(final_slopes),
    moderation_summary = janitor::clean_names(final_summary),
    model_fit          = janitor::clean_names(final_fit),
    legend             = list(simple_slopes = legend_slopes,
                              moderation_summary = legend_summary)
  ))
}
