#' A Function to Run Lasso or Ridge Regression with Missing Value Handling using tidymodels
#'
#' @param data The dataset as a dataframe.
#' @param outcome_vars A character vector specifying the names of the outcome variables.
#' @param control_vars An optional character vector specifying control variables in the model.
#' @param interest_vars A character vector specifying the variables of interest.
#' @param alpha A numeric value specifying the elastic net mixing parameter. 1 for Lasso, 0 for Ridge. Default is 1.
#' @return A dataframe summarizing the regression analysis for each variable of interest and each outcome variable.
#' @export
run_regularized_regression_tidymodels <- function(data, outcome_vars, control_vars = NULL, interest_vars, alpha = 1) {
  library(tidymodels)
  library(glmnet)
  
  if (!alpha %in% c(0, 1)) {
    stop("Alpha must be either 0 (Ridge) or 1 (Lasso)")
  }
  
  regression_type <- if(alpha == 1) "Lasso" else "Ridge"
  
  final_summary <- data.frame()
  
  for (outcome_var in outcome_vars) {
    # Prepare the predictor matrix
    if (!is.null(control_vars) && length(control_vars) > 0) {
      base_predictors <- c(control_vars, interest_vars)
    } else {
      base_predictors <- interest_vars
    }
    
    # Create the recipe
    recipe_obj <- recipe(formula = as.formula(paste(outcome_var, "~", paste(base_predictors, collapse = "+"))), data = data) %>%
      step_impute_mode(all_nominal_predictors()) %>%
      step_impute_knn(all_numeric_predictors()) %>%
      step_dummy(all_nominal_predictors()) %>%
      step_zv(all_predictors()) %>%
      step_normalize(all_numeric_predictors(), na_rm = TRUE) %>%
      step_naomit(all_predictors(), outcome_var)
    
    # Prepare the data
    prepped_data <- prep(recipe_obj) %>% juice()
    
    # Check if we have enough data left
    if (nrow(prepped_data) < 2) {
      warning(paste("Skipping", outcome_var, "due to insufficient data after preprocessing"))
      next
    }
    
    # Specify the model
    model_spec <- linear_reg(penalty = tune(), mixture = alpha) %>%
      set_engine("glmnet")
    
    # Create the workflow
    workflow_obj <- workflow() %>%
      add_model(model_spec)
    
    # Set up the grid for lambda
    lambda_grid <- grid_regular(penalty(), levels = 100)
    
    # Fit the model
    set.seed(123)  # for reproducibility
    model_fit <- workflow_obj %>%
      fit_resamples(
        resamples = vfold_cv(prepped_data, v = 5),
        grid = lambda_grid,
        metrics = metric_set(rmse),
        control = control_resamples(save_pred = TRUE)
      )
    
    # Get the best model
    best_model <- model_fit %>% select_best(metric = "rmse")
    
    # Finalize the workflow and fit
    final_workflow <- workflow_obj %>%
      finalize_workflow(best_model)
    
    final_fit <- final_workflow %>%
      fit(data = prepped_data)
    
    # Extract coefficients
    coef_tidy <- tidy(final_fit) %>%
      filter(estimate != 0)
    
    # Add outcome variable and regression type
    coef_tidy <- coef_tidy %>%
      mutate(outcome_variable = outcome_var,
             regression_type = regression_type,
             lambda = best_model$penalty)
    
    final_summary <- bind_rows(final_summary, coef_tidy)
  }
  
  return(final_summary)
}

