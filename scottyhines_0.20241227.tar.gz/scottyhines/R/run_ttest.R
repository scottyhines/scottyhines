#' Run t-Tests for Multiple Outcome Variables
#'
#' This function performs t-tests for multiple outcome variables, allowing both paired and unpaired tests.
#'
#' @param data A dataframe containing the data.
#' @param outcome_vars A vector of strings representing the outcome variables to test.
#' @param group_var A string representing the grouping variable.
#' @param paired A logical indicating whether to perform a paired t-test. Default is FALSE.
#'
#' @return A dataframe summarizing the t-test results for each outcome variable.
#' @importFrom broom tidy
#' @importFrom stats t.test
#' @export
run_ttest <- function(data, outcome_vars, group_var, paired = FALSE) {
  t_test_summaries <- list()

  for (outcome_var in outcome_vars) {
    if (paired) {
      # For paired t-test, use a vectorized approach
      group_levels <- unique(data[[group_var]])
      if (length(group_levels) != 2) {
        stop("Paired t-test requires exactly two levels in the group variable.")
      }

      # Split the data into two groups based on the grouping variable
      group1 <- data[data[[group_var]] == group_levels[1], outcome_var, drop = TRUE]
      group2 <- data[data[[group_var]] == group_levels[2], outcome_var, drop = TRUE]

      # Perform paired t-test
      mod <- t.test(group1, group2, paired = TRUE)
    } else {
      # For unpaired t-test, use the formula interface
      formula <- as.formula(paste(outcome_var, "~", group_var))
      mod <- t.test(formula, data = data)
    }

    # Summarize the t-test result
    tidy_model <- broom::tidy(mod)
    tidy_model$outcome_variable <- outcome_var
    tidy_model$group_variable <- group_var
    t_test_summaries[[outcome_var]] <- tidy_model
  }

  # Combine all t-test results into a single dataframe
  final_t_test_summary <- do.call(rbind, t_test_summaries)
  return(final_t_test_summary)
}
