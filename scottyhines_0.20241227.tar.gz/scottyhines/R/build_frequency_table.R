#' Build a frequency table for nominal/character variables within each group.
#'
#' @param df A data frame containing the data to summarize.
#' @param group_var The name of the variable to group by (as a string).
#' @param vars A vector of nominal/character variable names to calculate the frequencies for.
#' @param include_percentage A boolean indicating whether to include percentages in the format "% (N = frequency)".
#'
#' @return A wide-format data frame where each group's frequency counts for each variable category is a separate column.
#' @export
build_frequency_table <- function(df, group_var, vars, include_percentage = TRUE) {
  # Convert group_var to symbol and ensure vars is treated correctly
  group_var_sym <- rlang::ensym(group_var)

  # Initialize an empty list to store frequency tables
  freq_tables <- list()

  # Loop through each variable and calculate frequencies
  for (var in vars) {
    freq_table <- df %>%
      dplyr::group_by(!!group_var_sym, !!rlang::sym(var)) %>%
      dplyr::summarise(Frequency = n(), .groups = 'drop') %>%
      tidyr::pivot_wider(names_from = !!group_var_sym, values_from = Frequency, values_fill = list(Frequency = 0))

    # Rename the columns to match the desired format
    freq_table <- freq_table %>%
      dplyr::rename(sub_category = !!rlang::sym(var))

    if (include_percentage) {
      # Calculate total frequencies per group
      total_counts <- colSums(freq_table[ , -1], na.rm = TRUE)

      # Calculate percentages and format them
      percentage_table <- freq_table %>%
        dplyr::mutate(across(-sub_category, ~ paste0(round(. / total_counts[match(cur_column(), names(total_counts))] * 100, 2), "% (N = ", ., ")")))

      # Replace the frequency table with the formatted percentage table
      freq_table <- percentage_table
    }

    # Store the frequency table with the variable name as the list element name
    freq_tables[[var]] <- freq_table
  }

  # Combine all frequency tables into a single data frame
  final_df <- dplyr::bind_rows(freq_tables, .id = "var_of_interest")

  # Create the "variable" column
  final_df <- final_df %>%
    dplyr::mutate(variable = paste0(var_of_interest, "_", sub_category))

  return(final_df)
}
