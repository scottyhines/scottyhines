#' Perform XGBoost Classification with Holdout Sample
#'
#' This function performs XGBoost classification on a given dataset,
#' creating a model using the training data, making predictions on a holdout set, 
#' and producing visualizations.
#'
#' @param df A data frame containing the variables for analysis.
#' @param predictor_vars A character vector of predictor variable names.
#' @param metric A string specifying the name of the outcome variable.
#'
#' @return A list containing:
#'   \item{fit}{The fitted XGBoost model}
#'   \item{train_data}{The training data with predictions}
#'   \item{test_data}{The test data with predictions}
#'   \item{train_accuracy}{Accuracy metrics on the training data}
#'   \item{test_accuracy}{Accuracy metrics on the test data}
#'   \item{prediction_plot}{A ggplot object showing predicted vs actual classes for test data}
#'   \item{accuracy_plot}{A ggplot object comparing accuracy for training and test data}
#'   \item{feature_importance}{A data frame of feature importance}
#'
#' @import ggplot2
#' @importFrom stats as.formula
#' @importFrom rlang sym !!
#'
#' @export
xgboost_analysis_with_holdout <- function(df, predictor_vars, metric) {
  # Ensure metric is a factor
  df[[metric]] <- as.factor(df[[metric]])
  
  # Split the data into training (75%) and test (25%) sets
  set.seed(42)  # for reproducibility
  split <- rsample::initial_split(df, prop = 0.75, strata = metric)
  train_data <- rsample::training(split)
  test_data <- rsample::testing(split)
  
  # 1. Define the recipe
  formula_str <- paste(metric, "~", paste(predictor_vars, collapse = " + "))
  formula <- stats::as.formula(formula_str)
  xgb_recipe <- recipes::recipe(formula, data = train_data) %>%
    recipes::step_dummy(recipes::all_nominal(), -recipes::all_outcomes()) %>%
    recipes::step_normalize(recipes::all_numeric(), -recipes::all_outcomes()) %>%
    recipes::step_zv(recipes::all_predictors()) %>% # Remove zero-variance predictors
    recipes::step_corr(recipes::all_predictors(), threshold = 0.9) # Remove highly correlated predictors
  
  # 2. Define XGBoost model specification
  xgb_spec <- parsnip::boost_tree() %>%
    parsnip::set_engine("xgboost") %>%
    parsnip::set_mode("classification")
  
  # 3. Combine the recipe and model into a workflow
  xgb_workflow <- workflows::workflow() %>%
    workflows::add_recipe(xgb_recipe) %>%
    workflows::add_model(xgb_spec)
  
  # 4. Fit the workflow to the training data
  xgb_fit <- tryCatch({
    generics::fit(xgb_workflow, data = train_data)
  }, error = function(e) {
    message("Error in fitting the model: ", e$message)
    return(NULL)
  })
  
  if (is.null(xgb_fit)) {
    return(list(error = "Model fitting failed"))
  }
  
  # 5. Make predictions on training and test data
  train_augmented <- broom::augment(xgb_fit, new_data = train_data)
  test_augmented <- broom::augment(xgb_fit, new_data = test_data)
  
  # Calculate accuracy and other classification metrics for training and test data
  metric_set <- yardstick::metric_set(yardstick::accuracy, yardstick::kap, yardstick::mcc)
  
  train_accuracy <- metric_set(
    train_augmented,
    truth = !!rlang::sym(metric),
    estimate = .pred_class
  )
  
  test_accuracy <- metric_set(
    test_augmented,
    truth = !!rlang::sym(metric),
    estimate = .pred_class
  )
  
  # Create the prediction plot for test data
  prediction_plot <- ggplot2::ggplot(test_augmented, ggplot2::aes(x = !!rlang::sym(metric), y = .pred_class, color = !!rlang::sym(metric))) +
    ggplot2::geom_jitter(width = 0.2, height = 0.2, alpha = 0.5) +
    ggplot2::theme_minimal() +
    ggplot2::labs(title = "Predicted vs. Actual Classes (Test Data)", x = "Actual Class", y = "Predicted Class")
  
  # Create accuracy comparison plot
  accuracy_data <- rbind(
    cbind(train_accuracy, dataset = "Training"),
    cbind(test_accuracy, dataset = "Test")
  )
  
  accuracy_plot <- ggplot2::ggplot(accuracy_data, ggplot2::aes(x = .metric, y = .estimate, fill = dataset)) +
    ggplot2::geom_bar(stat = "identity", position = "dodge") +
    ggplot2::theme_minimal() +
    ggplot2::labs(title = "Model Performance Comparison",
                  x = "Metric", y = "Score", fill = "Dataset") +
    ggplot2::scale_y_continuous(limits = c(0, 1)) +
    ggplot2::coord_flip()
  
  # 6. Extract feature importance
  feature_importance <- tryCatch({
    xgb_model <- workflows::extract_fit_engine(xgb_fit)
    xgboost::xgb.importance(model = xgb_model)
  }, error = function(e) {
    message("Error in extracting feature importance: ", e$message)
    return(NULL)
  })
  
  # Return results as a list
  return(list(
    fit = xgb_fit,
    train_data = train_augmented,
    test_data = test_augmented,
    train_accuracy = train_accuracy,
    test_accuracy = test_accuracy,
    prediction_plot = prediction_plot,
    accuracy_plot = accuracy_plot,
    feature_importance = feature_importance
  ))
}
