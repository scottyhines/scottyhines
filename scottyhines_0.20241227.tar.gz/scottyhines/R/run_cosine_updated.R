#' Calculate Cosine Similarity and Node Dissimilarity
#'
#' This function calculates cosine similarity between text documents and computes
#' node dissimilarity scores. It creates two network graphs based on the similarity scores,
#' one with stop words and one without.
#'
#' @param df A data frame containing the text data and node IDs.
#' @param text_col The name of the column in df that contains the text data.
#' @param node_id_col The name of the column in df that contains the node IDs.
#' @param node_attrs Optional vector of column names in df to include as node attributes.
#' @param use_ngrams Logical, whether to use n-grams in text processing. Default is TRUE.
#' @param ngram_range A vector of two integers specifying the n-gram range. Default is c(1, 2).
#' @param min_term_freq Minimum frequency for a term to be included. Default is 1.
#' @param max_term_freq Maximum frequency for a term to be included. Default is Inf.
#'
#' @return A list containing:
#'   \item{edge_list_original}{A data frame of edges with their weights (with stop words)}
#'   \item{edge_list_improved}{A data frame of edges with their weights (without stop words)}
#'   \item{node_file}{A data frame of nodes with their attributes}
#'   \item{dissimilarity_ranking}{A data frame of nodes with their dissimilarity scores}
#'
#' @import text2vec
#' @import tm
#' @import igraph
#' @import dplyr
#' @import SnowballC
#'
#' @examples
#' \dontrun{
#' df <- data.frame(
#'   id = 1:3,
#'   text = c("This is document 1", "This is document 2", "This is document 3")
#' )
#' result <- run_cosine_similarity_with_attrs(df, "text", "id")
#' }
#'
#' @export
run_cosine_similarity_with_attrs <- function(df, text_col, node_id_col, node_attrs = NULL, 
                                             use_ngrams = TRUE, ngram_range = c(1, 2), 
                                             min_term_freq = 1, max_term_freq = Inf) { 
  library(text2vec) 
  library(tm) 
  library(igraph) 
  library(dplyr) 
  library(SnowballC)  # For stemming 
  
  # Error checking 
  if (!all(c(text_col, node_id_col) %in% colnames(df))) { 
    stop("Specified text_col or node_id_col not found in the dataframe") 
  } 
  
  # Extract texts and node IDs from the dataframe 
  texts <- df[[text_col]] 
  node_ids <- df[[node_id_col]] 
  
  cat("Number of rows in input dataframe:", nrow(df), "\n") 
  cat("Number of unique node IDs:", length(unique(node_ids)), "\n") 
  
  # Get stop words 
  stop_words <- tm::stopwords("en") 
  
  # Original method (with stop words) 
  # Create a token iterator 
  tokens_original <- text2vec::space_tokenizer(texts) 
  
  # Create vocabulary 
  it_original <- text2vec::itoken(tokens_original, progressbar = FALSE) 
  vocab_original <- text2vec::create_vocabulary(it_original) 
  
  # Create a term-co-occurrence matrix 
  vectorizer_original <- text2vec::vocab_vectorizer(vocab_original) 
  dtm_original <- text2vec::create_dtm(it_original, vectorizer_original) 
  
  # Apply TF-IDF transformation 
  tfidf_original <- text2vec::TfIdf$new() 
  dtm_tfidf_original <- text2vec::fit_transform(dtm_original, tfidf_original) 
  
  # Calculate cosine similarity 
  cosine_sim_original <- text2vec::sim2(dtm_tfidf_original, method = "cosine") 
  
  # Improved method (without stop words) 
  # Preprocess texts 
  preprocess_text <- function(x) { 
    x <- tolower(x) 
    x <- gsub("[[:punct:]]", " ", x) 
    x <- gsub("[[:digit:]]", " ", x) 
    x <- gsub("\\s+", " ", x) 
    x <- trimws(x) 
    tokens <- unlist(strsplit(x, "\\s+")) 
    tokens <- tokens[!tokens %in% stop_words] 
    tokens <- sapply(tokens, SnowballC::wordStem)  # Stemming 
    paste(tokens, collapse = " ") 
  } 
  
  processed_texts <- sapply(texts, preprocess_text) 
  
  # Create document-term matrix 
  it <- itoken(processed_texts, ids = node_ids, progressbar = FALSE) 
  
  if (use_ngrams) { 
    vocab <- create_vocabulary(it, ngram = ngram_range) 
  } else { 
    vocab <- create_vocabulary(it) 
  } 
  
  vocab <- prune_vocabulary(vocab, term_count_min = min_term_freq, 
                            term_count_max = max_term_freq) 
  
  vectorizer <- vocab_vectorizer(vocab) 
  dtm <- create_dtm(it, vectorizer) 
  
  cat("DTM dimensions:", dim(dtm), "\n") 
  
  # Apply TF-IDF transformation 
  tfidf <- TfIdf$new() 
  dtm_tfidf <- fit_transform(dtm, tfidf) 
  
  # Calculate cosine similarity 
  cosine_sim <- sim2(dtm_tfidf, dtm_tfidf, method = "cosine", norm = "l2") 
  
  cat("Cosine similarity matrix dimensions:", dim(cosine_sim), "\n") 
  
  # Convert cosine similarity matrices to dataframes 
  cosine_sim_df_original <- as.data.frame(as.matrix(cosine_sim_original)) 
  cosine_sim_df <- as.data.frame(as.matrix(cosine_sim)) 
  colnames(cosine_sim_df_original) <- node_ids 
  rownames(cosine_sim_df_original) <- node_ids 
  colnames(cosine_sim_df) <- node_ids 
  rownames(cosine_sim_df) <- node_ids 
  
  # Calculate average dissimilarity for each node 
  avg_dissimilarity_original <- rowMeans(1 - cosine_sim_df_original) 
  avg_dissimilarity <- rowMeans(1 - cosine_sim_df) 
  
  # Normalize dissimilarity scores for the improved method 
  norm_dissimilarity <- (avg_dissimilarity - min(avg_dissimilarity)) / 
    (max(avg_dissimilarity) - min(avg_dissimilarity)) 
  
  # Create a dataframe with node IDs and their dissimilarity scores 
  dissimilarity_df <- data.frame( 
    node_id = node_ids, 
    dissimilarity_with_stop_words = avg_dissimilarity_original, 
    dissimilarity_without_stop_words = avg_dissimilarity, 
    normalized = norm_dissimilarity 
  ) 
  
  # Sort the dataframe by dissimilarity with stop words in descending order 
  dissimilarity_df <- dissimilarity_df[order(-dissimilarity_df$dissimilarity_with_stop_words), ] 
  
  # Convert cosine similarity matrices to edge lists
  edge_list_original <- data.frame(
    from = rep(node_ids, each = length(node_ids)),
    to = rep(node_ids, times = length(node_ids)),
    weight = as.vector(as.matrix(cosine_sim_original))
  )
  
  edge_list_improved <- data.frame(
    from = rep(node_ids, each = length(node_ids)),
    to = rep(node_ids, times = length(node_ids)),
    weight = as.vector(as.matrix(cosine_sim))
  )
  
  # Remove self-loops and duplicate edges for both edge lists
  edge_list_original <- edge_list_original[edge_list_original$from != edge_list_original$to, ]
  edge_list_original <- edge_list_original[!duplicated(t(apply(edge_list_original, 1, sort))), ]
  
  edge_list_improved <- edge_list_improved[edge_list_improved$from != edge_list_improved$to, ]
  edge_list_improved <- edge_list_improved[!duplicated(t(apply(edge_list_improved, 1, sort))), ]
  
  # Sort edge lists by weight in descending order
  edge_list_original <- edge_list_original[order(-edge_list_original$weight), ]
  edge_list_improved <- edge_list_improved[order(-edge_list_improved$weight), ]
  
  # Keep only the top 50% of edges for both edge lists
  num_edges_to_keep_original <- ceiling(nrow(edge_list_original) * 0.5)
  num_edges_to_keep_improved <- ceiling(nrow(edge_list_improved) * 0.5)
  edge_list_original <- edge_list_original[1:num_edges_to_keep_original, ]
  edge_list_improved <- edge_list_improved[1:num_edges_to_keep_improved, ]
  
  # Get node file 
  node_file <- df %>% 
    dplyr::select(all_of(c(node_id_col, node_attrs))) 
  
  # Create igraph objects for both methods
  g_original <- graph_from_data_frame(edge_list_original, vertices = node_file, directed = FALSE)
  g_improved <- graph_from_data_frame(edge_list_improved, vertices = node_file, directed = FALSE)
  
  # Calculate layouts (separately for each graph)
  lay_original <- layout_nicely(g_original)
  lay_improved <- layout_nicely(g_improved)
  
  # Identify the three most dissimilar and similar nodes for both methods
  most_dissimilar_original <- head(dissimilarity_df$node_id[order(-dissimilarity_df$dissimilarity_with_stop_words)], 3)
  most_similar_original <- tail(dissimilarity_df$node_id[order(-dissimilarity_df$dissimilarity_with_stop_words)], 3)
  
  most_dissimilar_improved <- head(dissimilarity_df$node_id[order(-dissimilarity_df$dissimilarity_without_stop_words)], 3)
  most_similar_improved <- tail(dissimilarity_df$node_id[order(-dissimilarity_df$dissimilarity_without_stop_words)], 3)
  
  # Assign colors to nodes for both methods
  V(g_original)$color <- ifelse(V(g_original)$name %in% most_dissimilar_original, "#1cd788",
                                ifelse(V(g_original)$name %in% most_similar_original, "#d23a3c", "#d8e5e7"))
  
  V(g_improved)$color <- ifelse(V(g_improved)$name %in% most_dissimilar_improved, "#1cd788",
                                ifelse(V(g_improved)$name %in% most_similar_improved, "#d23a3c", "#d8e5e7"))
  
  # Set up the plotting area for two plots side by side
  par(mfrow = c(1, 2), mar = c(2, 2, 2, 2))  # Adjust margins to make room for legend
  
  # Plot the graph with colors (original method)
  plot(g_original, layout = lay_original, vertex.color = V(g_original)$color, main = "With Stop Words")
  
  # Add legend for original method
  legend("bottomright", 
         legend = c("Most Dissimilar", "Most Similar"), 
         col = c("#1cd788", "#d23a3c"), 
         pch = 19, 
         pt.cex = 1.5, 
         cex = 0.8, 
         bty = "n")
  
  # Plot the graph with colors (improved method)
  plot(g_improved, layout = lay_improved, vertex.color = V(g_improved)$color, main = "Without Stop Words")
  
  # Add legend for improved method
  legend("bottomright", 
         legend = c("Most Dissimilar", "Most Similar"), 
         col = c("#1cd788", "#d23a3c"), 
         pch = 19, 
         pt.cex = 1.5, 
         cex = 0.8, 
         bty = "n")
  
  # Reset the plotting area
  par(mfrow = c(1, 1))
  
  # Return the results 
  return(list( 
    edge_list_original = edge_list_original,
    edge_list_improved = edge_list_improved,
    node_file = node_file, 
    dissimilarity_ranking = dissimilarity_df 
  )) 
} 