#' Run Psychometrics Analysis
#'
#' This function performs psychometrics analysis on a specified set of items in a data frame,
#' including descriptive statistics, reliability analysis (Cronbach's alpha), item analysis,
#' Principal Component Analysis (PCA), and Exploratory Factor Analysis (EFA).
#'
#' @param df A data frame containing the data to be analyzed.
#' @param items A character vector of column names in the data frame representing the items to be analyzed.
#' @param factors The number of factors for PCA and EFA. Default is 1.
#' @param rotation The rotation method for PCA and EFA. Default is "varimax".
#'
#' @return A list containing the following components:
#'   \item{describe}{Descriptive statistics from psych::describe}
#'   \item{alpha}{Cronbach's alpha from psych::alpha}
#'   \item{item_analysis}{Item analysis from psychometric::item.exam}
#'   \item{kmo}{Kaiser-Meyer-Olkin Measure of Sampling Adequacy}
#'   \item{pca}{Principal Component Analysis results}
#'   \item{efa}{Exploratory Factor Analysis results}
#'   \item{scree_plot}{A ggplot2 object representing the scree plot}
#'
#' @import psych
#' @import psychometric
#' @import ggplot2
#' @importFrom stats factanal na.omit
#' @importFrom dplyr select all_of
#'
#' @examples
#' \dontrun{
#' data(mtcars)
#' items <- c("mpg", "cyl", "disp", "hp")
#' result <- run_psychometrics(mtcars, items, factors = 2)
#' print(result$alpha)
#' print(result$scree_plot)
#' }
#'
#' @export
run_psychometrics <- function(df, items, factors = 1, rotation = "varimax") {
  # Input validation
  if (!is.data.frame(df)) stop("df must be a data frame")
  if (!all(items %in% names(df))) stop("Not all items are present in the data frame")

  wd <- df %>% dplyr::select(all_of(items))

  out_psych_describe <- psych::describe(wd)

  psych_alpha <- psych::alpha(wd, check.keys = TRUE)
  out_psych_alpha <- psych_alpha$total

  out_psych_item_analysis <- psychometric::item.exam(wd, y = NULL, discrim = TRUE)

  out_kmo <- psych::KMO(wd)

  # Scree Plot
  pca_result <- psych::principal(wd, nfactors = ncol(wd), rotate = "none")
  eigenvalues <- pca_result$values
  plot_data <- data.frame(
    Component = 1:length(eigenvalues),
    Eigenvalue = eigenvalues
  )
  scree_plot <- ggplot2::ggplot(plot_data, ggplot2::aes(x = Component, y = Eigenvalue)) +
    ggplot2::geom_line() +
    ggplot2::geom_point() +
    ggplot2::geom_text(ggplot2::aes(label = round(Eigenvalue, 2)), vjust = -0.5) +
    ggplot2::scale_x_continuous(breaks = 1:length(eigenvalues)) +
    ggplot2::ylim(0, max(eigenvalues) + 1) +
    ggplot2::labs(title = "Scree Plot", x = "Component Number", y = "Eigenvalue") +
    ggplot2::theme_minimal()

  # PCA
  out_psych_pca <- psych::principal(wd, nfactors = factors, rotate = rotation)

  # EFA
  wd_no_na <- stats::na.omit(wd) # remove missing data from the model
  out_psych_EFA <- stats::factanal(wd_no_na, factors = factors, rotation = rotation)

  return(list(
    describe = out_psych_describe,
    alpha = out_psych_alpha,
    item_analysis = out_psych_item_analysis,
    kmo = out_kmo,
    pca = out_psych_pca,
    efa = out_psych_EFA,
    scree_plot = scree_plot
  ))
}

