#' A Function to Create a Correlation Table
#'
#' This function creates a correlation table for the specified outcome and interest variables in a given dataset.
#'
#' @param data The dataset as a dataframe.
#' @param outcome_vars A character vector specifying the names of the outcome variables.
#' @param interest_vars A character vector specifying the variables of interest.
#' @return A correlation table showing the correlation coefficients between the outcome variables and the interest variables.
#' @export
build_correlation_table <- function(data, outcome_vars, interest_vars) {
  # Select the relevant columns from the dataset
  relevant_columns <- data[, c(outcome_vars, interest_vars)]

  # Calculate the correlation matrix
  correlation_matrix <- cor(relevant_columns, use = "pairwise.complete.obs")

  # Subset the matrix to show correlations between outcome and interest variables
  correlation_table <- as.data.frame(correlation_matrix[outcome_vars, interest_vars, drop = FALSE])


  return(correlation_table)
}

