#' Basis Points Calculator
#'
#' A flexible function to convert basis points (bps) to percentages, calculate the basis points
#' difference between two raw means, and apply basis points to a monetary value.
#' Designed for inclusion in the `scottyhines` package.
#'
#' @param start Numeric. The starting value (e.g., basis points or raw mean).
#' @param end Numeric. The ending value, used to calculate basis points difference. Default is NULL.
#' @param value Numeric. A monetary value to apply basis points to. Default is NULL.
#' @param direction Character. The operation to perform:
#'   - "convert": Converts basis points to percentages. Uses `start` as input.
#'   - "difference": Calculates the basis points difference between `start` and `end`.
#'   - "apply": Applies the basis points (in `start`) to a monetary `value`.
#'
#' @return A character string describing the result of the calculation.
#' @export
calculate_basis_points <- function(start, end = NULL, value = NULL, direction = "difference") {
  # Convert basis points to percentage
  if (direction == "convert") {
    percentage <- start / 10000  # 1 basis point = 0.01%
    return(paste0(start, " bps is equivalent to ", percentage * 100, "%"))
  }

  # Calculate basis points difference between two values
  if (!is.null(end) & direction == "difference") {
    bps_difference <- (start - end) / start * 10000
    return(paste0("The difference from ", start, " to ", end,
                  " is ", round(abs(bps_difference), 2), " basis points"))
  }

  # Apply basis points to a monetary value
  if (!is.null(value) & direction == "apply") {
    percentage_change <- start / 10000
    adjusted_value <- value * (1 + percentage_change)
    return(paste0("Applying ", start, " bps to ", value,
                  " results in an adjusted value of ", round(adjusted_value, 2)))
  }

  # Error handling
  stop("Invalid input. Use 'convert', 'difference', or 'apply' as the direction.")
}
