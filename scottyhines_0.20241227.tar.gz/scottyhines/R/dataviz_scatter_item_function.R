#' Overall Scatter Item Function
#'
#' This function creates a scatter plot of item scores grouped by a specified variable.
#' Default texts are provided for the plot title, subtitle, x-axis label, and y-axis label.
#'
#' @param df A data frame containing the data.
#' @param grouping_var A string specifying the grouping variable.
#' @param item_score_var A string specifying the item score variable.
#' @param title_text A string specifying the title of the plot. Default is "Scatter Plot".
#' @param sub_text A string specifying the subtitle of the plot. Default is "Grouped by specified variable".
#' @param x_text A string specifying the x-axis label. Default is "Item Score".
#' @param y_text A string specifying the y-axis label. Default is "Group".
#'
#' @return A ggplot object.
#' @export
dataviz_scatter_item_function <- function(df,
                                          grouping_var,
                                          item_score_var,
                                          title_text = "Scatter Plot",
                                          sub_text = "Grouped by specified variable",
                                          x_text = "Item Score",
                                          y_text = "Group") {

  item_sum_stats <- df %>%
    dplyr::group_by(!!rlang::sym(grouping_var)) %>%
    dplyr::summarise(
      light_std = sd(!!rlang::sym(item_score_var), na.rm = TRUE),
      light_var = var(!!rlang::sym(item_score_var), na.rm = TRUE),
      light_min = min(!!rlang::sym(item_score_var), na.rm = TRUE),
      light_max = max(!!rlang::sym(item_score_var), na.rm = TRUE),
      light_mean = mean(!!rlang::sym(item_score_var), na.rm = TRUE)
    )

  plot2 <- df %>%
    ggplot2::ggplot(aes(x = .data[[item_score_var]], y = reorder(.data[[grouping_var]], desc(.data[[grouping_var]])))) +
    ggplot2::geom_jitter(aes(col = .data[[item_score_var]]), width = 0.5, size = 1) +
    ggplot2::geom_point(data = item_sum_stats, aes(x = light_mean, y = !!rlang::sym(grouping_var)), col = 'black', size = 5) +
    ggplot2::geom_vline(xintercept = mean(df[[item_score_var]], na.rm = TRUE), linetype = 'solid', size = 1.5) +
    ggplot2::labs(title = title_text, subtitle = sub_text, caption = "") +
    ggplot2::xlab(x_text) +
    ggplot2::ylab(y_text) +
    viridis::scale_color_viridis(option = 'magma') +
    ggplot2::theme_linedraw() +  # Use the linedraw theme
    ggplot2::theme(
      legend.position = 'none',   # Remove legend
      aspect.ratio = .5          # Adjust aspect ratio
    )

  return(plot2)
}
