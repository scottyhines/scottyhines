#' Run ANOVA and Group Contrasts
#'
#' This function performs ANOVA analyses on a set of outcome variables, optionally including control variables in the model, calculates contrasts for the group-level variable, and computes the group means for each outcome variable.
#'
#' @name run_anova_with_contrasts
#' @param data A dataframe containing the dataset.
#' @param outcome_vars A vector of names for the outcome variables.
#' @param control_vars An optional vector of names for control variables in the model. If not provided, the model will only include the group-level variable.
#' @param group_var The name of the group-level variable.
#' @return A list with three elements: `anova_summary`, a dataframe summarizing the ANOVA results for each outcome variable; `contrast_summary`, a dataframe summarizing the contrasts analysis; and `group_means_summary`, a dataframe containing the group means for each outcome variable.
#' @export
library(dplyr)
library(broom)
library(modelbased)
library(tidyr)

run_anova_with_contrasts <- function(data, outcome_vars, control_vars = NULL, group_var) {
  anova_summaries <- list()
  contrast_summaries <- list()
  group_means_list <- list()

  # Loop over the outcome variables
  for (outcome_var in outcome_vars) {
    # Check if control_vars is provided and is not empty
    if (!is.null(control_vars) && length(control_vars) > 0) {
      # Correctly build the formula with the control variables
      formula <- as.formula(paste(outcome_var, "~", paste(control_vars, collapse = " + "), "+", group_var))
    } else {
      # Build the formula without control variables
      formula <- as.formula(paste(outcome_var, "~", group_var))
    }

    # Fit the ANOVA model
    mod <- aov(formula, data = data)

    # Get a tidy summary of the model
    tidy_model <- broom::tidy(mod)
    tidy_model$outcome_variable <- outcome_var # Add the outcome variable name for clarity
    tidy_model$group_variable <- group_var # Add the group variable name for clarity

    # Calculate group means
    means <- data %>%
      dplyr::group_by(!!sym(group_var)) %>%
      dplyr::summarize(mean = mean(!!sym(outcome_var), na.rm = TRUE)) %>%
      tidyr::pivot_wider(names_from = !!sym(group_var), values_from = mean, names_prefix = "mean_") %>%
      dplyr::mutate(outcome_variable = outcome_var, group_variable = group_var)

    # Store the means
    group_means_list[[outcome_var]] <- means

    # Calculate contrasts for the group variable
    contrasts <- modelbased::estimate_contrasts(mod, contrast = group_var)
    contrasts_df <- as.data.frame(contrasts)
    contrasts_df$outcome_variable <- outcome_var # Ensure this column is present for consistency
    contrasts_df$group_variable <- group_var # Ensure this column is present for consistency

    # Store the tidy_model and contrasts_df in their respective lists
    anova_summaries[[outcome_var]] <- tidy_model
    contrast_summaries[[outcome_var]] <- contrasts_df
  }

  # Combine all ANOVA summaries into a single dataframe
  final_anova_summary <- do.call(rbind, anova_summaries)

  # Combine all contrast summaries into a single dataframe
  final_contrast_summary <- do.call(rbind, contrast_summaries)

  # Combine all group means into a single dataframe
  final_group_means <- do.call(bind_rows, group_means_list)

  # Combine final_anova_summary with the group means
  final_anova_summary <- final_anova_summary %>%
    left_join(final_group_means, by = c("outcome_variable", "group_variable"))

  # Combine final_contrast_summary with the group means
  final_contrast_summary <- final_contrast_summary %>%
    left_join(final_group_means, by = c("outcome_variable", "group_variable"))

  # Return all three dataframes
  return(list(anova_summary = final_anova_summary, contrast_summary = final_contrast_summary, group_means_summary = final_group_means))
}
