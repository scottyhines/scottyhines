#' Normalize and Categorize Heartbeat Data
#'
#' This function takes a dataframe and a list of column names that represent
#' heartbeat data. It normalizes these heartbeat data columns by calculating
#' the z-score, categorizes them into -1, 0, or 1 based on their z-score, and
#' renames them by prefixing 'heartbeat_'.
#'
#' @param data_frame A dataframe containing the data to process.
#' @param heartbeat_list A character vector specifying the column names
#'   in `data_frame` that contain heartbeat data. These columns are normalized
#'   and categorized.
#'
#' @return A dataframe with the heartbeat data columns normalized, categorized,
#'   and renamed. Original heartbeat data columns are replaced with the new
#'   columns, which have names prefixed with 'heartbeat_'.
#' @export
run_heartbeat <- function(data_frame, heartbeat_list) {
  df_heartbeat <- data_frame %>%
    dplyr::select(all_of(heartbeat_list)) %>%
    dplyr::rowwise() %>%
    dplyr::mutate(mean = mean(c_across(everything())),
                  sd = sd(c_across(everything()))) %>%
    dplyr::mutate(across(all_of(heartbeat_list), ~ round((. - mean) / sd))) %>%
    dplyr::select(-mean, -sd) %>%
    replace(., is.na(.), 0) %>%
    dplyr::mutate(across(all_of(heartbeat_list), ~ ifelse(. >= 1, 1, .))) %>%
    dplyr::mutate(across(all_of(heartbeat_list), ~ ifelse(. <= -1, -1, .))) %>%
    dplyr::rename_with(~ paste0('heartbeat_', .), all_of(heartbeat_list))

  return(df_heartbeat)
}
