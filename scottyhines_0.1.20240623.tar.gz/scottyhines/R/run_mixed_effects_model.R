#' A Function to Run Mixed-Effects Model Analysis
#'
#' This function performs mixed-effects model analysis on a given dataset. It allows for the specification of multiple outcome variables, control variables (if any), and variables of interest. The function returns a dataframe summarizing the analysis for each variable of interest, including estimates, standard errors, t-values, p-values, and means at each time point.
#'
#' @param data The dataset as a dataframe.
#' @param outcome_vars A character vector specifying the names of the outcome variables.
#' @param control_vars An optional character vector specifying control variables in the model. If provided, these variables are included in the model as additional fixed effects.
#' @param interest_vars A character vector specifying the variables of interest that will be individually added to the base model for analysis.
#' @param random_effects A string specifying the random effects structure (e.g., "(1 | subject)").
#' Notes on random effects structure:
#'  - Different Grouping Levels: If your data includes repeated measures for subjects, you might use (1 | subject).
#'  - Clusters or Groups: If your data is clustered (e.g., students within classrooms, patients within hospitals), you might use (1 | cluster) or (1 | group).
#'  - Nested Designs: If your grouping factors are nested (e.g., students within classrooms within schools), you might use (1 | school/classroom/subject).
#'  - Crossed Designs: If your factors are crossed (e.g., subjects rated by multiple raters), you might use (1 | subject) + (1 | rater).
#'  - Random Slopes: If you suspect that the effect of a predictor varies across levels of the grouping factor, you might include random slopes. For example, (1 + predictor | subject) allows the effect of predictor to vary by subject.
#'  - Complex Random Effects Structures: For both random intercepts and slopes, you might use (1 + predictor | subject). If you believe there is a correlation between random intercepts and slopes, you might use (1 + predictor || subject) to fit an uncorrelated model.
#'  - Model Fit and Comparison: Use AIC/BIC or likelihood ratio tests to compare models with different random effects structures.
#'  - Convergence Issues: Complex random effects structures may lead to convergence problems, requiring simpler models or alternative fitting algorithms.
#' @param interaction_var A character string specifying the interaction variable.
#' @param include_interaction A boolean indicating whether to include the interaction term in the model (default is TRUE).
#' @return A list containing two dataframes:
#'   - model_summary: A dataframe summarizing the mixed-effects model analysis for each variable of interest, including regression coefficients, standard errors, t-statistics, and p-values.
#'   - means_summary: A dataframe summarizing the mean values of the outcome variable at each level of the interaction variable.
#' @export
run_mixed_effects_model <- function(data, outcome_vars, control_vars = NULL, interest_vars, random_effects, interaction_var, include_interaction = TRUE) {
  library(lme4)
  library(lmerTest)
  library(broom.mixed)
  library(dplyr)
  library(tidyr)
  options(warn = -1)

  # Remove cases without the interaction variable
  data <- data %>% filter(!is.na(!!sym(interaction_var)))

  final_summary <- list()
  means_summary <- list()

  for (outcome_var in outcome_vars) {
    for (variable in interest_vars) {
      if (include_interaction) {
        base_formula <- paste(outcome_var, "~", variable, "*", interaction_var)
      } else {
        base_formula <- paste(outcome_var, "~", variable, "+", interaction_var)
      }
      if (!is.null(control_vars) && length(control_vars) > 0) {
        base_formula <- paste(base_formula, "+", paste(control_vars, collapse = " + "))
      }
      complete_formula_str <- paste(base_formula, "+", random_effects)
      formula <- as.formula(complete_formula_str)

      # Print the formula to check it
      print(paste("Running model with formula:", formula))

      model <- lmer(formula, data = data)
      tidy_model <- tidy(model, effects = "fixed")
      tidy_model$variable_of_interest <- variable
      tidy_model$outcome_variable <- outcome_var

      means <- data %>%
        group_by(!!sym(interaction_var)) %>%
        summarize(mean = mean(!!sym(outcome_var), na.rm = TRUE)) %>%
        pivot_wider(names_from = !!sym(interaction_var), values_from = mean, names_prefix = "mean_") %>%
        mutate(outcome_variable = outcome_var, variable_of_interest = variable, interaction_variable = interaction_var)

      final_summary[[paste(outcome_var, variable, sep = "_")]] <- tidy_model
      means_summary[[paste(outcome_var, variable, sep = "_")]] <- means
    }
  }

  final_combined_summary <- do.call(rbind, final_summary)
  final_means_summary <- do.call(rbind, means_summary)

  options(warn = 0)
  return(list(model_summary = final_combined_summary, means_summary = final_means_summary))
}
