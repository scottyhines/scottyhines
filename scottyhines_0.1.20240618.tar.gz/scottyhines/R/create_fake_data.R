#' Create Fake Data for Analysis
#'
#' This function generates a synthetic dataset with demographic information,
#' attitude measures, and network centrality metrics for a specified number of
#' observations. The dataset includes a mixture of factor, numeric, and character
#' variables, simulating a realistic scenario for testing data analysis pipelines,
#' including regression models and network analysis. Attitude measures are generated
#' as integer values on a scale from 1 to 5, suitable for representing Likert scale responses.
#'
#' @param n The number of observations to generate in the dataset. Defaults to 2000.
#' @return A dataframe with the following columns:
#' \describe{
#'   \item{id}{An integer vector, representing the row number.}
#'   \item{demo_job_level}{A factor variable with levels 1 to 5 representing job levels.}
#'   \item{demo_tenure}{A numeric vector with values ranging from 1 to 100 representing tenure.}
#'   \item{demo_region_code}{A character vector with values "north", "south", "east", and "west" representing geographic regions.}
#'   \item{demo_performance}{A numeric vector with values from 1 to 5 representing performance levels.}
#'   \item{demo_attrition}{A factor vector with levels 0 (no attrition) and 1 (attrition), where attrition cases occur in approximately 20% of the observations.}
#'   \item{attitude_*}{Several integer vectors on a scale from 1 to 5 representing different attitude measures, such as work ethic, adaptability, etc.}
#'   \item{network_*}{Numeric vectors representing network centrality measures such as degree (as integers), betweenness, closeness, and eigenvector centrality.}
#' }
#' @examples
#' # Generate a default dataset
#' fake_data <- create_fake_data()
#'
#' # Generate a smaller dataset with 500 observations
#' fake_data_500 <- create_fake_data(n = 500)
#'
#' @export
create_fake_data <- function(n = 2000) {
  # Generating demographic variables
  demo_job_level <- factor(sample(1:5, n, replace = TRUE))
  demo_tenure <- runif(n, min = 1, max = 100)
  demo_region_code <- sample(c("north", "south", "east", "west"), n, replace = TRUE)
  demo_performance <- sample(1:5, n, replace = TRUE)
  id <- 1:n

  # Adjusting attrition rate and converting to factor
  demo_attrition <- factor(sample(c(1, 0), n, replace = TRUE, prob = c(0.2, 0.8)),
                           levels = c(0, 1), labels = c("No Attrition", "Attrition"))

  # Generating integer attitude measures on a scale from 1 to 5
  attitude_work_ethic <- sample(1:5, n, replace = TRUE)
  attitude_adaptability <- sample(1:5, n, replace = TRUE)
  attitude_creativity <- sample(1:5, n, replace = TRUE)
  attitude_persistence <- sample(1:5, n, replace = TRUE)
  attitude_teamwork <- sample(1:5, n, replace = TRUE)
  attitude_communication <- sample(1:5, n, replace = TRUE)
  attitude_leadership <- sample(1:5, n, replace = TRUE)
  attitude_innovation <- sample(1:5, n, replace = TRUE)

  # Simulating network centrality measures
  network_degree <- round(rlnorm(n, meanlog = log(10), sdlog = 0.5))
  network_betweenness <- abs(rnorm(n, mean = 0.0005, sd = 0.0005))
  network_closeness <- runif(n, min = 0.0001, max = 0.001)
  network_eigenvector <- rbeta(n, shape1 = 2, shape2 = 5)

  # Compiling variables into a dataframe
  df <- data.frame(id, demo_job_level, demo_tenure, demo_region_code, demo_performance, demo_attrition,
                   attitude_work_ethic, attitude_adaptability, attitude_creativity,
                   attitude_persistence, attitude_teamwork, attitude_communication,
                   attitude_leadership, attitude_innovation,
                   network_degree, network_betweenness, network_closeness, network_eigenvector)

  return(df)
}
