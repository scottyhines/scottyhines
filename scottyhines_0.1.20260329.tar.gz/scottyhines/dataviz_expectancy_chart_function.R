#' Expectancy Chart (Side-by-Side Bar Chart)
#'
#' Creates a side-by-side (dodged) bar chart showing the mean of a numeric variable
#' across an x-axis variable, grouped by a categorical variable. Bars display
#' formatted labels (percentage or numeric). Useful for comparing rates or means
#' across cohorts and groups.
#'
#' @param df A data frame containing the data.
#' @param x_var A string specifying the x-axis variable (e.g., year, cohort).
#' @param y_var A string specifying the numeric variable to summarize (mean).
#' @param group_var A string specifying the grouping variable for dodged bars.
#' @param is_percentage Logical. If TRUE, formats y-axis and labels as percentages. Default is TRUE.
#' @param title_text A string specifying the title. Default is "Expectancy Chart".
#' @param sub_text A string specifying the subtitle. Default is "".
#' @param x_text A string specifying the x-axis label. Default is NULL (uses x_var).
#' @param y_text A string specifying the y-axis label. Default is NULL (uses y_var).
#' @param caption_text A string specifying the caption. Default is "".
#' @param show_labels Logical. Show value labels on bars. Default is TRUE.
#' @param label_size Numeric. Size of the value labels. Default is 4.
#' @param y_limit Optional numeric. Upper limit for y-axis. Default is NULL (auto).
#'
#' @return A ggplot object.
#' @export
dataviz_expectancy_chart_function <- function(df,
                                              x_var,
                                              y_var,
                                              group_var,
                                              is_percentage = TRUE,
                                              title_text = "Expectancy Chart",
                                              sub_text = "",
                                              x_text = NULL,
                                              y_text = NULL,
                                              caption_text = "",
                                              show_labels = TRUE,
                                              label_size = 4,
                                              y_limit = NULL) {

  if (is.null(x_text)) x_text <- x_var
  if (is.null(y_text)) y_text <- y_var

  # Summarize: mean of y_var by x_var and group_var
  plot_df <- df %>%
    dplyr::group_by(!!rlang::sym(x_var), !!rlang::sym(group_var)) %>%
    dplyr::summarise(value = mean(!!rlang::sym(y_var), na.rm = TRUE), .groups = "drop")

  # Ensure x_var is treated as factor for discrete axis
  plot_df[[x_var]] <- as.factor(plot_df[[x_var]])
  plot_df[[group_var]] <- as.factor(plot_df[[group_var]])

  # Format labels
  if (is_percentage) {
    plot_df$label <- scales::percent(plot_df$value, accuracy = 0.1)
  } else {
    plot_df$label <- round(plot_df$value, 2)
  }

  # Build the plot
  plot <- ggplot2::ggplot(plot_df, ggplot2::aes(
    x = .data[[x_var]], y = value, fill = .data[[group_var]]
  )) +
    ggplot2::geom_col(position = ggplot2::position_dodge(width = 0.9),
                      colour = "black", width = 0.8) +
    viridis::scale_fill_viridis(discrete = TRUE, option = "viridis")

  # Value labels on bars
  if (show_labels) {
    plot <- plot +
      ggplot2::geom_text(
        ggplot2::aes(label = label),
        position = ggplot2::position_dodge(width = 0.9),
        vjust = -0.5, size = label_size
      )
  }

  # Y-axis formatting
  if (is_percentage) {
    plot <- plot +
      ggplot2::scale_y_continuous(labels = scales::percent)
  }

  # Y limit
  if (!is.null(y_limit)) {
    plot <- plot + ggplot2::expand_limits(y = y_limit)
  } else if (is_percentage) {
    plot <- plot + ggplot2::expand_limits(y = max(plot_df$value) * 1.15)
  }

  # Labels and theme
  plot <- plot +
    ggplot2::labs(
      title = title_text, subtitle = sub_text,
      caption = caption_text, x = x_text, y = y_text
    ) +
    ggplot2::theme_linedraw() +
    ggplot2::theme(
      axis.text.x = ggplot2::element_text(face = "bold", color = "black", size = 10),
      axis.text.y = ggplot2::element_text(face = "bold", color = "black", size = 10),
      aspect.ratio = 0.5
    )

  return(plot)
}
