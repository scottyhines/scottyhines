# Test script for create_dummy_variables function
# Run this after compiling the package

library(scottyhines)
library(dplyr)

# Create test data
df <- data.frame(
  id = 1:10,
  gender = c("M", "F", "M", "F", "M", "F", "M", "F", "M", "F"),
  status = c("Active", "Inactive", "Active", "Active", "Inactive", 
             "Active", "Inactive", "Active", "Inactive", "Active"),
  score = rnorm(10, 50, 10)
)

print("Original data:")
print(df)

# Test 1: Basic dummy coding for specific variables
print("\n=== Test 1: Basic dummy coding ===")
df_test1 <- scottyhines::create_dummy_variables(df, vars = c("gender", "status"))
print(df_test1)

# Test 2: Remove first dummy (for regression)
print("\n=== Test 2: Remove first dummy ===")
df_test2 <- scottyhines::create_dummy_variables(df, vars = c("gender", "status"), remove_first = TRUE)
print(df_test2)

# Test 3: Remove original variables
print("\n=== Test 3: Remove original variables ===")
df_test3 <- scottyhines::create_dummy_variables(df, vars = c("gender", "status"), remove_original = TRUE)
print(df_test3)

# Test 4: Auto-detect all categorical variables
print("\n=== Test 4: Auto-detect categorical variables ===")
df_test4 <- scottyhines::create_dummy_variables(df)
print(df_test4)

# Test 5: Use with dplyr pipeline
print("\n=== Test 5: Use in dplyr pipeline ===")
df_test5 <- df %>%
  scottyhines::create_dummy_variables(vars = "gender") %>%
  dplyr::mutate(score_squared = score^2)
print(df_test5)
