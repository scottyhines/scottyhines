#' Run Chi-Square Tests of Independence
#'
#' This function performs chi-square tests of independence for multiple combinations of categorical variables.
#' It tests whether two categorical variables are independent or associated, and provides effect sizes,
#' expected frequencies, and residuals.
#'
#' @param data A dataframe containing the variables.
#' @param row_vars A character vector of variable names to use as row variables in contingency tables.
#' @param col_vars A character vector of variable names to use as column variables in contingency tables.
#' @param correct A logical indicating whether to apply Yates' continuity correction for 2x2 tables. Default is TRUE.
#' @param simulate_p A logical indicating whether to compute p-values by Monte Carlo simulation. Default is FALSE.
#' @param B An integer specifying the number of replicates for Monte Carlo simulation. Default is 2000.
#'
#' @return A list containing:
#' \describe{
#'   \item{test_results}{A dataframe with chi-square test statistics, p-values, degrees of freedom, and effect sizes.}
#'   \item{contingency_tables}{A list of observed frequency tables for each variable pair.}
#'   \item{expected_frequencies}{A list of expected frequency tables for each variable pair.}
#'   \item{residuals}{A list of standardized residuals for each variable pair.}
#' }
#'
#' @export
run_chi_square_test <- function(data, row_vars, col_vars, correct = TRUE, simulate_p = FALSE, B = 2000) {
  
  # Initialize storage lists
  test_results_list <- list()
  contingency_tables_list <- list()
  expected_freq_list <- list()
  residuals_list <- list()
  
  # Calculate total iterations for progress bar
  total_iterations <- length(row_vars) * length(col_vars)
  pb <- txtProgressBar(min = 0, max = total_iterations, style = 3)
  current_iteration <- 0
  
  # Loop through all combinations of row and column variables
  for (row_var in row_vars) {
    for (col_var in col_vars) {
      
      tryCatch({
        # Create contingency table
        contingency_table <- table(data[[row_var]], data[[col_var]])
        
        # Perform chi-square test
        if (simulate_p) {
          chi_test <- chisq.test(contingency_table, correct = correct, simulate.p.value = TRUE, B = B)
        } else {
          chi_test <- chisq.test(contingency_table, correct = correct)
        }
        
        # Calculate effect sizes
        n <- sum(contingency_table)
        chi_squared <- chi_test$statistic
        df <- chi_test$parameter
        
        # Cramér's V (effect size for chi-square)
        min_dim <- min(nrow(contingency_table) - 1, ncol(contingency_table) - 1)
        cramers_v <- sqrt(chi_squared / (n * min_dim))
        
        # Phi coefficient (for 2x2 tables)
        phi <- if (nrow(contingency_table) == 2 && ncol(contingency_table) == 2) {
          sqrt(chi_squared / n)
        } else {
          NA
        }
        
        # Contingency coefficient
        contingency_coef <- sqrt(chi_squared / (chi_squared + n))
        
        # Store test results
        test_result <- data.frame(
          row_variable = row_var,
          col_variable = col_var,
          chi_squared = as.numeric(chi_squared),
          df = as.numeric(df),
          p_value = chi_test$p.value,
          cramers_v = as.numeric(cramers_v),
          phi = as.numeric(phi),
          contingency_coefficient = as.numeric(contingency_coef),
          n_obs = n,
          n_cells = length(contingency_table),
          min_expected_freq = min(chi_test$expected),
          simulation_used = simulate_p
        )
        
        key <- paste(row_var, col_var, sep = "_x_")
        test_results_list[[key]] <- test_result
        
        # Store contingency table
        contingency_tables_list[[key]] <- as.data.frame.matrix(contingency_table)
        
        # Store expected frequencies
        expected_freq_list[[key]] <- as.data.frame.matrix(chi_test$expected)
        
        # Calculate and store standardized residuals
        residuals <- (contingency_table - chi_test$expected) / sqrt(chi_test$expected)
        residuals_list[[key]] <- as.data.frame.matrix(residuals)
        
      }, error = function(e) {
        warning(sprintf("Failed to compute chi-square test for %s x %s: %s", 
                       row_var, col_var, e$message))
      })
      
      # Update progress bar
      current_iteration <- current_iteration + 1
      setTxtProgressBar(pb, current_iteration)
    }
  }
  
  close(pb)
  cat("\n")
  
  # Combine all test results
  final_test_results <- do.call(rbind, test_results_list)
  rownames(final_test_results) <- NULL
  
  return(list(
    test_results = final_test_results,
    contingency_tables = contingency_tables_list,
    expected_frequencies = expected_freq_list,
    residuals = residuals_list
  ))
}
