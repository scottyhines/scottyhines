#' A Function to Run Lasso or Ridge Regression with Missing Value Handling
#'
#' This function performs either Lasso or Ridge regression analysis on a given dataset.
#' It handles missing values, allows for the specification of outcome variables,
#' control variables (if any), and variables of interest.
#'
#' @param data The dataset as a dataframe.
#' @param outcome_vars A character vector specifying the names of the outcome variables.
#' @param control_vars An optional character vector specifying control variables in the model.
#' @param interest_vars A character vector specifying the variables of interest.
#' @param alpha A numeric value specifying the elastic net mixing parameter. 1 for Lasso, 0 for Ridge. Default is 1.
#' @param impute_method Method for imputing missing values. Either "mean" or "median". Default is "mean".
#' @return A dataframe summarizing the regression analysis for each variable of interest and each outcome variable.
#' @import glmnet
#' @export
run_regularized_regression <- function(data, outcome_vars, control_vars = NULL, interest_vars, alpha = 1, impute_method = "mean") {
  options(warn = -1)
  #library(glmnet)

  if (!alpha %in% c(0, 1)) {
    stop("Alpha must be either 0 (Ridge) or 1 (Lasso)")
  }

  if (!impute_method %in% c("mean", "median")) {
    stop("Impute method must be either 'mean' or 'median'")
  }

  regression_type <- if(alpha == 1) "Lasso" else "Ridge"

  # Function to impute missing values
  impute_missing <- function(x) {
    if (is.numeric(x)) {
      if (impute_method == "mean") {
        x[is.na(x)] <- mean(x, na.rm = TRUE)
      } else {
        x[is.na(x)] <- median(x, na.rm = TRUE)
      }
    } else if (is.factor(x) || is.character(x)) {
      mode_val <- names(sort(table(x), decreasing = TRUE))[1]
      x[is.na(x)] <- mode_val
    }
    return(x)
  }

  final_summary <- data.frame()
  fit_stats_list <- list()
  
  # Initialize progress bar
  pb <- txtProgressBar(min = 0, max = length(outcome_vars), style = 3)

  for (i in seq_along(outcome_vars)) {
    outcome_var <- outcome_vars[i]
    # Prepare the predictor matrix
    if (!is.null(control_vars) && length(control_vars) > 0) {
      base_predictors <- c(control_vars, interest_vars)
    } else {
      base_predictors <- interest_vars
    }

    # Subset the data and impute missing values
    model_data <- data[, c(outcome_var, base_predictors)]
    model_data <- as.data.frame(lapply(model_data, impute_missing))

    X <- as.matrix(model_data[, base_predictors])
    y <- as.matrix(model_data[, outcome_var])

    # Fit the model
    model <- cv.glmnet(X, y, alpha = alpha, standardize = TRUE)

    # Extract coefficients at the optimal lambda
    coef_matrix <- as.matrix(coef(model, s = "lambda.min"))

    # Create a tidy dataframe of results
    tidy_model <- data.frame(
      term = rownames(coef_matrix),
      estimate = coef_matrix[,1],
      lambda = model$lambda.min,
      outcome_variable = outcome_var,
      regression_type = regression_type
    )

    tidy_model <- tidy_model[tidy_model$estimate != 0, ]  # Remove zero coefficients

    final_summary <- rbind(final_summary, tidy_model)
    
    # Extract model fit statistics
    # Predict using optimal lambda
    predictions <- predict(model, newx = X, s = "lambda.min")
    
    # Calculate R² and other metrics
    ss_total <- sum((y - mean(y))^2)
    ss_residual <- sum((y - predictions)^2)
    r_squared <- 1 - (ss_residual / ss_total)
    
    # Get cross-validation error
    cv_error_min <- model$cvm[model$lambda == model$lambda.min]
    cv_error_1se <- model$cvm[model$lambda == model$lambda.1se]
    
    fit_stats <- data.frame(
      outcome_variable = outcome_var,
      regression_type = regression_type,
      lambda_min = model$lambda.min,
      lambda_1se = model$lambda.1se,
      cv_error_min = cv_error_min,
      cv_error_1se = cv_error_1se,
      r_squared = r_squared,
      n_nonzero_coefs = sum(coef_matrix != 0) - 1,  # Exclude intercept
      n_obs = nrow(X),
      n_predictors = ncol(X)
    )
    
    fit_stats_list[[outcome_var]] <- fit_stats
    
    # Update progress bar
    setTxtProgressBar(pb, i)
  }

  close(pb)
  cat("\n")
  
  final_fit_stats <- do.call(rbind, fit_stats_list)

  options(warn = 0)
  return(list(
    coefficients = janitor::clean_names(final_summary),
    model_fit = janitor::clean_names(final_fit_stats)
  ))
}
