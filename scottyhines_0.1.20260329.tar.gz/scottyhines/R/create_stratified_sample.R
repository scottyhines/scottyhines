#' Create Stratified Sample
#'
#' This function performs stratified random sampling on a given dataframe based on specified variables, sample size, and tolerance level.
#'
#' @param data A dataframe containing the population data.
#' @param stratify_vars A character vector specifying the names of the variables to stratify on.
#' @param total_sample_size An integer specifying the total number of samples to pull.
#' @param tolerance A numeric value specifying the allowed deviation from the sample proportion (in percentage points).
#'
#' @return A list containing the stratified random sample, a summary of proportions in the population and sample, and suggestions for the next pull.
#' Returns NULL if an error occurs with a message to try a different sample size.
#' @export
create_stratified_sample <- function(data, stratify_vars, total_sample_size, tolerance = 3) {
  tryCatch({
    # Create strata
    data <- data %>%
      dplyr::mutate(strata = interaction(!!!dplyr::syms(stratify_vars), sep = "_"))
    
    # Calculate initial sample sizes
    proportions <- data %>%
      dplyr::group_by(strata) %>%
      dplyr::summarise(count = dplyr::n(), .groups = 'drop') %>%
      dplyr::mutate(proportion = count / sum(count),
                    sample_size = round(proportion * total_sample_size)) %>%
      dplyr::ungroup()
    
    # Adjust sample sizes to ensure they sum up to total_sample_size
    # Distribute rounding errors across strata instead of concentrating on one
    difference <- total_sample_size - sum(proportions$sample_size)
    if (difference != 0) {
      proportions <- proportions %>%
        dplyr::arrange(dplyr::desc(proportion)) %>%
        dplyr::mutate(
          adjustment = dplyr::case_when(
            difference > 0 & dplyr::row_number() <= abs(difference) ~ 1,
            difference < 0 & dplyr::row_number() <= abs(difference) ~ -1,
            TRUE ~ 0
          ),
          sample_size = sample_size + adjustment
        ) %>%
        dplyr::select(-adjustment)
    }
    
    resample <- TRUE
    max_attempts <- 10
    attempts <- 0
    n_strata <- nrow(proportions)
    
    # Initialize progress bar
    pb <- txtProgressBar(min = 0, max = max_attempts, style = 3)
    
    while (resample && attempts < max_attempts) {
      attempts <- attempts + 1
      iteration_start <- Sys.time()
      setTxtProgressBar(pb, attempts)
      
      # Perform stratified sampling more efficiently
      sampled_data <- lapply(seq_len(nrow(proportions)), function(i) {
        strata_val <- proportions$strata[i]
        n_sample <- proportions$sample_size[i]
        data %>%
          dplyr::filter(strata == strata_val) %>%
          dplyr::slice_sample(n = n_sample) %>%
          dplyr::select(-strata)
      }) %>%
        dplyr::bind_rows()
      
      iteration_time <- as.numeric(difftime(Sys.time(), iteration_start, units = "secs"))
      cat(sprintf(" [Iteration %d: %.2f sec]", attempts, iteration_time))
      
      # Check proportionality for combined strata
      population_proportions <- data %>%
        dplyr::group_by(strata) %>%
        dplyr::summarise(count = dplyr::n(), .groups = 'drop') %>%
        dplyr::mutate(proportion = count / sum(count)) %>%
        dplyr::select(strata, population_count = count, population_proportion = proportion)
      
      sample_proportions <- sampled_data %>%
        dplyr::mutate(strata = interaction(!!!dplyr::syms(stratify_vars), sep = "_")) %>%
        dplyr::group_by(strata) %>%
        dplyr::summarise(count = dplyr::n(), .groups = 'drop') %>%
        dplyr::mutate(proportion = count / sum(count)) %>%
        dplyr::select(strata, sample_count = count, sample_proportion = proportion)
      
      proportionality_check <- dplyr::left_join(population_proportions, sample_proportions, by = "strata") %>%
        dplyr::mutate(difference = sample_proportion - population_proportion,
                      suggestion = dplyr::case_when(
                        difference > tolerance / 100 ~ "Pull fewer",
                        difference < -tolerance / 100 ~ "Pull more",
                        TRUE ~ "Proportionate"
                      ))
      
      # Adjust sample sizes based on the suggestions with proportional adjustments
      proportions <- proportions %>%
        dplyr::left_join(proportionality_check %>% dplyr::select(strata, suggestion, difference), by = "strata") %>%
        dplyr::mutate(
          # Calculate proportional adjustment based on actual difference
          adjustment = dplyr::case_when(
            suggestion == "Pull fewer" ~ pmax(round(abs(difference) * total_sample_size), 1),
            suggestion == "Pull more" ~ pmax(round(abs(difference) * total_sample_size), 1),
            TRUE ~ 0
          ),
          sample_size = dplyr::case_when(
            suggestion == "Pull fewer" ~ pmax(sample_size - adjustment, 1),
            suggestion == "Pull more" ~ sample_size + adjustment,
            TRUE ~ sample_size
          )
        ) %>%
        dplyr::select(-suggestion, -difference, -adjustment)
      
      # Re-normalize to ensure total_sample_size is maintained
      size_diff <- total_sample_size - sum(proportions$sample_size)
      if (size_diff != 0) {
        proportions <- proportions %>%
          dplyr::arrange(dplyr::desc(proportion)) %>%
          dplyr::mutate(
            adjustment = dplyr::case_when(
              size_diff > 0 & dplyr::row_number() <= abs(size_diff) ~ 1,
              size_diff < 0 & dplyr::row_number() <= abs(size_diff) ~ -1,
              TRUE ~ 0
            ),
            sample_size = sample_size + adjustment
          ) %>%
          dplyr::select(-adjustment)
      }
      
      if (all(proportionality_check$suggestion == "Proportionate")) {
        resample <- FALSE
        cat("\n")
      }
    }
    
    close(pb)
    
    # Warn if tolerance was not achieved
    if (resample) {
      warning("Proportionality tolerance not achieved after ", max_attempts, " attempts. Returning best available sample.")
    }
    
    # Check proportionality for individual stratifying variables
    individual_checks <- lapply(stratify_vars, function(var) {
      population_individual <- data %>%
        dplyr::group_by(!!dplyr::sym(var)) %>%
        dplyr::summarise(count = dplyr::n(), .groups = 'drop') %>%
        dplyr::mutate(proportion = count / sum(count)) %>%
        dplyr::select(!!dplyr::sym(var), population_count = count, population_proportion = proportion)
      
      sample_individual <- sampled_data %>%
        dplyr::group_by(!!dplyr::sym(var)) %>%
        dplyr::summarise(count = dplyr::n(), .groups = 'drop') %>%
        dplyr::mutate(proportion = count / sum(count)) %>%
        dplyr::select(!!dplyr::sym(var), sample_count = count, sample_proportion = proportion)
      
      dplyr::left_join(population_individual, sample_individual, by = var) %>%
        dplyr::mutate(variable = var, .before = 1)
    })
    
    return(list(sample = sampled_data, proportionality_check = proportionality_check, individual_checks = individual_checks))
  }, error = function(e) {
    message("Error: ", e$message)
    message("Try a different sample size or check your data.")
    return(NULL)
  })
}
