#' Run Hierarchical Regression
#'
#' This function performs hierarchical (mixed-effects) regression analysis on a given dataset. It allows for the specification of an outcome variable, control variables (if any), variables of interest, and a grouping variable for random effects. The function returns a dataframe summarizing the regression analysis for each variable of interest.
#'
#' @param data A dataframe containing the dataset.
#' @param outcome_vars A string specifying the name of the outcome variable.
#' @param control_vars An optional character vector specifying control variables in the model. If provided, these variables are included in the regression model as additional predictors alongside the variables of interest.
#' @param interest_vars A character vector specifying the variables of interest that will be individually added to the base model for analysis.
#' @param group_var A string specifying the name of the hierarchical group level variable to be used for random effects.
#' @return A dataframe summarizing the linear regression analysis for each variable of interest. This summary includes regression coefficients, standard errors, t-statistics, p-values, and for random effects, the group variance component.
#' @export
run_hierarchical_regression <- function(data, outcome_vars, control_vars = NULL, interest_vars, group_var) {
  model_summaries <- list()
  model_fit_stats <- list()
  
  # Calculate total iterations for progress bar
  total_iterations <- length(outcome_vars) * length(interest_vars)
  pb <- txtProgressBar(min = 0, max = total_iterations, style = 3)
  current_iteration <- 0

  # Loop over the outcome variables
  for (outcome_var in outcome_vars) {
    # Base formula setup
    base_formula <- paste0(outcome_var, " ~ ")

    if (!is.null(control_vars) && length(control_vars) > 0) {
      # Include control variables in the formula
      base_formula <- paste0(base_formula, paste(control_vars, collapse = " + "), " + ")
    }

    base_formula <- paste0(base_formula, "(1|", group_var, ")")

    # Loop over interest variables to fit models
    for (variable in interest_vars) {
      # Complete formula with current variable of interest
      formula <- as.formula(paste(base_formula, "+", variable))

      # Fit the hierarchical regression model
      model <- lme4::lmer(formula, data = data)

      # Summarize the model with broom.mixed
      tidy_model <- broom.mixed::tidy(model)

      # Add the variable name to the summary for clarity
      tidy_model$variable_of_interest <- variable
      tidy_model$outcome_variable <- outcome_var # Add the outcome variable name for clarity

      # Store the summary in the list
      model_summaries[[paste(outcome_var, variable, sep = "_")]] <- tidy_model
      
      # Extract model fit statistics
      var_fixed <- var(as.vector(lme4::fixef(model) %*% t(model.matrix(model))))
      var_random <- sum(as.numeric(lme4::VarCorr(model)))
      var_residual <- attr(lme4::VarCorr(model), "sc")^2
      
      # Calculate ICC (intraclass correlation)
      icc <- var_random / (var_random + var_residual)
      
      fit_stats <- data.frame(
        variable_of_interest = variable,
        outcome_variable = outcome_var,
        formula = deparse(formula),
        marginal_r2 = var_fixed / (var_fixed + var_random + var_residual),
        conditional_r2 = (var_fixed + var_random) / (var_fixed + var_random + var_residual),
        icc = icc,
        aic = AIC(model),
        bic = BIC(model),
        loglik = as.numeric(logLik(model)),
        n_obs = nobs(model),
        n_groups = length(unique(data[[group_var]]))
      )
      
      model_fit_stats[[paste(outcome_var, variable, sep = "_")]] <- fit_stats
      
      # Update progress bar
      current_iteration <- current_iteration + 1
      setTxtProgressBar(pb, current_iteration)
    }
  }

  close(pb)
  cat("\n")

  # Combine all summaries into a single dataframe
  final_summary <- do.call(rbind, model_summaries)
  final_fit_stats <- do.call(rbind, model_fit_stats)

  return(list(
    coefficients = final_summary,
    model_fit = final_fit_stats
  ))
}
