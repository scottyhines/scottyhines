#' Density Ridge Plot Function (Pure ggplot2)
#'
#' Creates a ridgeline-style density plot showing the distribution of a numeric
#' variable across levels of a categorical variable. Optionally shades each
#' ridge by the group mean. No extra packages beyond ggplot2 and viridis.
#'
#' @param df A data frame containing the data.
#' @param x_var A string specifying the numeric variable for the x-axis (distribution).
#' @param group_var A string specifying the categorical variable for the y-axis (ridges).
#' @param fill_by_mean Logical. If TRUE, fills ridges by the group mean of x_var. Default is TRUE.
#' @param title_text A string specifying the title. Default is "Distribution of Values".
#' @param sub_text A string specifying the subtitle. Default is "".
#' @param x_text A string specifying the x-axis label. Default is NULL (uses x_var).
#' @param y_text A string specifying the y-axis label. Default is "".
#' @param caption_text A string specifying the caption. Default is "".
#' @param alpha Numeric. Fill transparency. Default is 0.8.
#' @param scale_height Numeric. Controls how much ridges overlap. Higher = more overlap. Default is 1.5.
#'
#' @return A ggplot object.
#' @export
dataviz_density_ridge_function <- function(df,
                                           x_var,
                                           group_var,
                                           fill_by_mean = TRUE,
                                           title_text = "Distribution of Values",
                                           sub_text = "",
                                           x_text = NULL,
                                           y_text = "",
                                           caption_text = "",
                                           alpha = 0.8,
                                           scale_height = 1.5) {

  if (is.null(x_text)) x_text <- x_var

  # Calculate group means for fill and ordering
  group_means <- df %>%
    dplyr::group_by(!!rlang::sym(group_var)) %>%
    dplyr::summarise(.group_mean = mean(!!rlang::sym(x_var), na.rm = TRUE), .groups = "drop")

  plot_df <- df %>%
    dplyr::left_join(group_means, by = group_var)

  # Get ordered group levels (alphabetical descending to match ridgeline convention)
  group_levels <- sort(unique(plot_df[[group_var]]), decreasing = FALSE)
  plot_df[[group_var]] <- factor(plot_df[[group_var]], levels = group_levels)

  # Compute densities manually per group so we can control overlap and fill by mean
  dens_list <- list()
  for (lvl in group_levels) {
    sub <- plot_df[plot_df[[group_var]] == lvl, ]
    if (nrow(sub) < 2) next
    d <- stats::density(sub[[x_var]], na.rm = TRUE)
    grp_mean <- unique(sub$.group_mean)
    grp_idx <- which(group_levels == lvl)
    # Scale density and offset by group index for ridgeline effect
    dens_list[[lvl]] <- data.frame(
      x = d$x,
      density = d$y / max(d$y) * scale_height + grp_idx,
      baseline = grp_idx,
      group_label = lvl,
      group_mean = grp_mean,
      stringsAsFactors = FALSE
    )
  }
  dens_df <- dplyr::bind_rows(dens_list)

  # Build the plot
  if (fill_by_mean) {
    plot <- ggplot2::ggplot(dens_df) +
      ggplot2::geom_ribbon(
        ggplot2::aes(x = x, ymin = baseline, ymax = density, group = group_label, fill = group_mean),
        alpha = alpha, color = "black", linewidth = 0.3
      ) +
      viridis::scale_fill_viridis(name = paste0("Mean ", x_var), option = "viridis")
  } else {
    plot <- ggplot2::ggplot(dens_df) +
      ggplot2::geom_ribbon(
        ggplot2::aes(x = x, ymin = baseline, ymax = density, group = group_label, fill = group_label),
        alpha = alpha, color = "black", linewidth = 0.3
      ) +
      viridis::scale_fill_viridis(discrete = TRUE, name = group_var, option = "viridis")
  }

  # Y-axis labels at group positions
  plot <- plot +
    ggplot2::scale_y_continuous(
      breaks = seq_along(group_levels),
      labels = group_levels,
      expand = c(0.01, 0)
    ) +
    ggplot2::labs(
      title = title_text, subtitle = sub_text,
      caption = caption_text, x = x_text, y = y_text
    ) +
    ggplot2::theme_linedraw() +
    ggplot2::theme(
      panel.grid.major.y = ggplot2::element_blank(),
      panel.grid.minor.y = ggplot2::element_blank(),
      plot.caption = ggplot2::element_text(hjust = 0)
    )

  return(plot)
}
