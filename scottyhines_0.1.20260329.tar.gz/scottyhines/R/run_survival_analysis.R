#' Run Survival Analysis
#'
#' This function performs survival analysis using Cox proportional hazards models and Kaplan-Meier estimation.
#' It supports multiple outcome variables (time-to-event), control variables, and variables of interest.
#'
#' @param data A dataframe containing the survival data.
#' @param time_vars A character vector of time-to-event variable names.
#' @param event_vars A character vector of event indicator variable names (0 = censored, 1 = event occurred).
#'   Must be the same length as time_vars and in corresponding order.
#' @param control_vars An optional character vector of control variables to include in Cox models.
#' @param interest_vars A character vector of predictor variables of interest.
#' @param strata_var An optional character string specifying a stratification variable for Kaplan-Meier curves.
#'
#' @return A list containing:
#' \describe{
#'   \item{cox_results}{A dataframe with Cox model coefficients, hazard ratios, and confidence intervals.}
#'   \item{cox_model_fit}{A dataframe with model fit statistics (concordance, AIC, BIC, log-likelihood).}
#'   \item{km_results}{A dataframe with Kaplan-Meier survival estimates (if strata_var provided).}
#'   \item{km_summary}{A dataframe summarizing median survival times by strata (if strata_var provided).}
#' }
#'
#' @export
run_survival_analysis <- function(data, time_vars, event_vars, control_vars = NULL, 
                                  interest_vars, strata_var = NULL) {
  
  if (!requireNamespace("survival", quietly = TRUE)) {
    stop("Package 'survival' is required but not installed.")
  }
  
  if (length(time_vars) != length(event_vars)) {
    stop("time_vars and event_vars must have the same length and be in corresponding order.")
  }
  
  # Initialize storage lists
  cox_results_list <- list()
  cox_fit_list <- list()
  km_results_list <- list()
  km_summary_list <- list()
  
  # Calculate total iterations for progress bar
  total_iterations <- length(time_vars) * length(interest_vars)
  pb <- txtProgressBar(min = 0, max = total_iterations, style = 3)
  current_iteration <- 0
  
  cat("Running survival analysis...\n")
  
  # Loop through each time-event pair
  for (i in seq_along(time_vars)) {
    time_var <- time_vars[i]
    event_var <- event_vars[i]
    
    # Build base formula
    base_formula <- "survival::Surv(time_var, event_var) ~"
    
    if (!is.null(control_vars) && length(control_vars) > 0) {
      base_formula <- paste(base_formula, paste(control_vars, collapse = " + "), "+")
    }
    
    # Loop through variables of interest
    for (variable in interest_vars) {
      
      tryCatch({
        # Build complete formula
        formula_str <- paste(base_formula, variable)
        
        # Replace placeholder with actual variable names
        formula_str <- gsub("time_var", time_var, formula_str)
        formula_str <- gsub("event_var", event_var, formula_str)
        
        formula <- as.formula(formula_str)
        
        # Fit Cox proportional hazards model
        cox_model <- survival::coxph(formula, data = data)
        
        # Extract coefficients and hazard ratios
        cox_summary <- summary(cox_model)
        tidy_cox <- broom::tidy(cox_model, exponentiate = FALSE, conf.int = TRUE)
        
        # Add hazard ratios
        tidy_cox$hazard_ratio <- exp(tidy_cox$estimate)
        tidy_cox$hr_conf_low <- exp(tidy_cox$conf.low)
        tidy_cox$hr_conf_high <- exp(tidy_cox$conf.high)
        
        # Add metadata
        tidy_cox$time_variable <- time_var
        tidy_cox$event_variable <- event_var
        tidy_cox$variable_of_interest <- variable
        
        key <- paste(time_var, event_var, variable, sep = "_")
        cox_results_list[[key]] <- tidy_cox
        
        # Extract model fit statistics
        concordance <- cox_summary$concordance
        
        fit_stats <- data.frame(
          time_variable = time_var,
          event_variable = event_var,
          variable_of_interest = variable,
          formula = formula_str,
          concordance = concordance[1],
          concordance_se = concordance[2],
          aic = AIC(cox_model),
          bic = BIC(cox_model),
          loglik = cox_model$loglik[2],
          n_obs = cox_model$n,
          n_events = cox_model$nevent,
          rsquare = cox_summary$rsq["rsq"],
          max_rsquare = cox_summary$rsq["maxrsq"]
        )
        
        cox_fit_list[[key]] <- fit_stats
        
      }, error = function(e) {
        warning(sprintf("Failed Cox model for %s ~ %s: %s", time_var, variable, e$message))
      })
      
      # Update progress bar
      current_iteration <- current_iteration + 1
      setTxtProgressBar(pb, current_iteration)
    }
    
    # Kaplan-Meier estimation (if strata variable provided)
    if (!is.null(strata_var)) {
      tryCatch({
        # Create survival object
        surv_formula <- as.formula(paste0("survival::Surv(", time_var, ", ", event_var, ") ~ ", strata_var))
        km_fit <- survival::survfit(surv_formula, data = data)
        
        # Extract survival estimates
        km_summary_df <- summary(km_fit)
        
        km_results <- data.frame(
          time_variable = time_var,
          event_variable = event_var,
          strata = km_summary_df$strata,
          time = km_summary_df$time,
          n_risk = km_summary_df$n.risk,
          n_event = km_summary_df$n.event,
          n_censor = km_summary_df$n.censor,
          survival = km_summary_df$surv,
          std_err = km_summary_df$std.err,
          lower_ci = km_summary_df$lower,
          upper_ci = km_summary_df$upper
        )
        
        km_results_list[[paste(time_var, event_var, sep = "_")]] <- km_results
        
        # Extract median survival times
        median_surv <- summary(km_fit)$table
        
        km_summary <- data.frame(
          time_variable = time_var,
          event_variable = event_var,
          strata = rownames(median_surv),
          n_obs = median_surv[, "records"],
          n_events = median_surv[, "events"],
          median_survival = median_surv[, "median"],
          lower_ci = median_surv[, "0.95LCL"],
          upper_ci = median_surv[, "0.95UCL"]
        )
        
        km_summary_list[[paste(time_var, event_var, sep = "_")]] <- km_summary
        
      }, error = function(e) {
        warning(sprintf("Failed Kaplan-Meier for %s: %s", time_var, e$message))
      })
    }
  }
  
  close(pb)
  cat("\nSurvival analysis complete!\n\n")
  
  # Combine results
  final_cox_results <- if (length(cox_results_list) > 0) {
    do.call(rbind, cox_results_list)
  } else {
    data.frame()
  }
  
  final_cox_fit <- if (length(cox_fit_list) > 0) {
    do.call(rbind, cox_fit_list)
  } else {
    data.frame()
  }
  
  final_km_results <- if (length(km_results_list) > 0) {
    do.call(rbind, km_results_list)
  } else {
    NULL
  }
  
  final_km_summary <- if (length(km_summary_list) > 0) {
    do.call(rbind, km_summary_list)
  } else {
    NULL
  }
  
  rownames(final_cox_results) <- NULL
  rownames(final_cox_fit) <- NULL
  if (!is.null(final_km_results)) rownames(final_km_results) <- NULL
  if (!is.null(final_km_summary)) rownames(final_km_summary) <- NULL
  
  return(list(
    cox_results = final_cox_results,
    cox_model_fit = final_cox_fit,
    km_results = final_km_results,
    km_summary = final_km_summary
  ))
}
