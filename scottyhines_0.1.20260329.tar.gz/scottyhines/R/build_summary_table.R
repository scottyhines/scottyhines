#' Build a Combined Summary Table (Means + Frequencies)
#'
#' Automatically detects whether each variable is numeric or categorical,
#' calls the appropriate function, and combines into a single table.
#' Variables are returned in the order provided, with N as the first row.
#'
#' @param df A data frame containing the data.
#' @param group_var The name of the grouping variable (as a string).
#' @param vars A character vector of variable names to summarize.
#' @param include_sd Logical. Include standard deviations for numeric variables. Default is TRUE.
#' @param include_percentage Logical. Include percentages for categorical variables. Default is TRUE.
#' @param include_overall Logical. If TRUE, adds an "overall" column. Default is TRUE.
#'
#' @return A wide-format data frame.
#' @export
build_summary_table <- function(df,
                                group_var,
                                vars,
                                include_sd = TRUE,
                                include_percentage = TRUE,
                                include_overall = TRUE) {

  grouped_parts <- list()
  overall_parts <- list()

  for (v in vars) {
    if (is.numeric(df[[v]])) {
      g <- scottyhines::build_means_table(
        df, group_var = group_var, vars = v, include_sd = include_sd
      )
      g <- g %>% dplyr::mutate(var_of_interest = v, sub_category = NA_character_)
      grouped_parts[[v]] <- g %>% dplyr::filter(variable != "N")

      if (include_overall) {
        df_ov <- df %>% dplyr::mutate(.overall_group = "Overall")
        o <- scottyhines::build_means_table(
          df_ov, group_var = ".overall_group", vars = v, include_sd = include_sd
        )
        if ("Overall" %in% names(o)) names(o)[names(o) == "Overall"] <- "overall"
        o <- o %>% dplyr::mutate(var_of_interest = v, sub_category = NA_character_)
        overall_parts[[v]] <- o %>% dplyr::filter(variable != "N")
      }
    } else {
      g <- scottyhines::build_frequency_table(
        df, group_var = group_var, vars = v, include_percentage = include_percentage
      )
      g <- g %>% dplyr::mutate(var_of_interest = v)
      grouped_parts[[v]] <- g

      if (include_overall) {
        df_ov <- df %>% dplyr::mutate(.overall_group = "Overall")
        o <- scottyhines::build_frequency_table(
          df_ov, group_var = ".overall_group", vars = v, include_percentage = include_percentage
        )
        if ("Overall" %in% names(o)) names(o)[names(o) == "Overall"] <- "overall"
        o <- o %>% dplyr::mutate(var_of_interest = v)
        overall_parts[[v]] <- o
      }
    }
  }

  # Build N row from first variable
  n_row <- scottyhines::build_means_table(
    df, group_var = group_var, vars = vars[1], include_sd = FALSE
  ) %>%
    dplyr::filter(variable == "N") %>%
    dplyr::mutate(var_of_interest = NA_character_, sub_category = NA_character_)

  if (include_overall) {
    df_ov <- df %>% dplyr::mutate(.overall_group = "Overall")
    n_ov <- scottyhines::build_means_table(
      df_ov, group_var = ".overall_group", vars = vars[1], include_sd = FALSE
    ) %>%
      dplyr::filter(variable == "N") %>%
      dplyr::mutate(var_of_interest = NA_character_, sub_category = NA_character_)
    if ("Overall" %in% names(n_ov)) names(n_ov)[names(n_ov) == "Overall"] <- "overall"
    n_row <- n_row %>%
      dplyr::left_join(
        n_ov %>% dplyr::select(variable, sub_category, var_of_interest, overall),
        by = c("variable", "sub_category", "var_of_interest")
      )
  }

  # Combine grouped parts
  grouped <- dplyr::bind_rows(grouped_parts)

  # Join overall column
  if (include_overall && length(overall_parts) > 0) {
    overall <- dplyr::bind_rows(overall_parts) %>%
      dplyr::select(variable, sub_category, var_of_interest, overall)
    join_cols <- intersect(
      c("variable", "sub_category", "var_of_interest"), names(grouped)
    )
    grouped <- grouped %>%
      dplyr::left_join(overall, by = join_cols)
  }

  # Prepend N row, order by input
  grouped <- dplyr::bind_rows(n_row, grouped) %>%
    dplyr::mutate(
      .input_order = dplyr::if_else(variable == "N", 0, match(var_of_interest, vars))
    ) %>%
    dplyr::arrange(.input_order) %>%
    dplyr::select(-.input_order)

  # Clean up
  grouped <- grouped %>%
    dplyr::select(variable, sub_category, dplyr::everything()) %>%
    dplyr::select(-dplyr::any_of("var_of_interest"))

  return(grouped)
}
