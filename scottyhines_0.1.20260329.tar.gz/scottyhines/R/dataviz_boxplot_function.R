#' Grouped Boxplot Function
#'
#' Creates a horizontal boxplot with jittered points and mean markers for one or
#' more numeric variables, optionally grouped by a categorical variable. Follows
#' the same style conventions as the other dataviz functions in this package.
#'
#' @param df A data frame containing the data.
#' @param vars A character vector of numeric variable names to plot. When multiple
#'   variables are provided they are pivoted long so each gets its own box.
#' @param group_var Optional string specifying a grouping variable for side-by-side
#'   (dodged) boxplots within each variable. Default is NULL.
#' @param title_text A string specifying the title. Default is "Boxplot".
#' @param sub_text A string specifying the subtitle. Default is "Distribution of Scores".
#' @param x_text A string specifying the x-axis label (appears on left after coord_flip). Default is "".
#' @param y_text A string specifying the y-axis label (appears on bottom after coord_flip). Default is "Value".
#' @param caption_text A string specifying the caption. Default is "".
#' @param show_jitter Logical. Show jittered data points. Default is TRUE.
#' @param jitter_alpha Numeric. Transparency of jittered points. Default is 0.25.
#' @param jitter_size Numeric. Size of jittered points. Default is 2.
#' @param show_mean Logical. Show mean as a point on each box. Default is TRUE.
#' @param mean_size Numeric. Size of the mean marker. Default is 3.
#'
#' @return A ggplot object.
#' @export
dataviz_boxplot_function <- function(df,
                                     vars,
                                     group_var = NULL,
                                     title_text = "Boxplot",
                                     sub_text = "Distribution of Scores",
                                     x_text = "",
                                     y_text = "Value",
                                     caption_text = "",
                                     show_jitter = TRUE,
                                     jitter_alpha = 0.25,
                                     jitter_size = 2,
                                     show_mean = TRUE,
                                     mean_size = 3) {

  # Pivot long if multiple vars
  if (!is.null(group_var)) {
    plot_df <- df %>%
      tidyr::pivot_longer(cols = dplyr::all_of(vars), names_to = "metric", values_to = "value") %>%
      dplyr::mutate(metric = factor(metric, levels = rev(vars)))
  } else {
    plot_df <- df %>%
      tidyr::pivot_longer(cols = dplyr::all_of(vars), names_to = "metric", values_to = "value") %>%
      dplyr::mutate(metric = factor(metric, levels = rev(vars)))
  }

  # Build the plot
  if (!is.null(group_var) && length(vars) == 1) {
    # Single variable + group: groups on the axis, one box per group
    plot <- ggplot2::ggplot(plot_df, ggplot2::aes(
      x = reorder(.data[[group_var]], dplyr::desc(.data[[group_var]])),
      y = value, fill = .data[[group_var]]
    )) +
      ggplot2::geom_boxplot(width = 0.6) +
      viridis::scale_fill_viridis(discrete = TRUE, option = "viridis")

    if (show_jitter) {
      plot <- plot +
        ggplot2::geom_jitter(size = jitter_size, alpha = jitter_alpha, width = 0.2)
    }
    if (show_mean) {
      plot <- plot +
        ggplot2::stat_summary(
          fun = mean, geom = "point", shape = 15, size = mean_size,
          colour = "mediumpurple4"
        )
    }
  } else if (!is.null(group_var) && length(vars) > 1) {
    # Multiple variables + group: metrics on axis, dodged by group
    plot <- ggplot2::ggplot(plot_df, ggplot2::aes(
      x = metric, y = value, fill = .data[[group_var]]
    )) +
      ggplot2::geom_boxplot(position = ggplot2::position_dodge(width = 0.8), width = 0.6) +
      viridis::scale_fill_viridis(discrete = TRUE, option = "viridis")

    if (show_jitter) {
      plot <- plot +
        ggplot2::geom_jitter(
          ggplot2::aes(group = .data[[group_var]]),
          position = ggplot2::position_jitterdodge(jitter.width = 0.2, dodge.width = 0.8),
          size = jitter_size, alpha = jitter_alpha
        )
    }
    if (show_mean) {
      plot <- plot +
        ggplot2::stat_summary(
          fun = mean, geom = "point", shape = 15, size = mean_size,
          colour = "mediumpurple4",
          position = ggplot2::position_dodge(width = 0.8)
        )
    }
  } else {
    plot <- ggplot2::ggplot(plot_df, ggplot2::aes(
      x = metric, y = value, fill = metric
    )) +
      ggplot2::geom_boxplot(width = 0.6) +
      viridis::scale_fill_viridis(discrete = TRUE, option = "viridis") +
      ggplot2::theme(legend.position = "none")

    if (show_jitter) {
      plot <- plot +
        ggplot2::geom_jitter(size = jitter_size, alpha = jitter_alpha, width = 0.2)
    }
    if (show_mean) {
      plot <- plot +
        ggplot2::stat_summary(
          fun = mean, geom = "point", shape = 15, size = mean_size,
          colour = "mediumpurple4"
        )
    }
  }

  # Flip and style
  plot <- plot +
    ggplot2::coord_flip() +
    ggplot2::labs(
      title = title_text, subtitle = sub_text,
      caption = caption_text, x = x_text, y = y_text
    ) +
    ggplot2::theme_linedraw() +
    ggplot2::theme(aspect.ratio = 0.5)

  return(plot)
}
