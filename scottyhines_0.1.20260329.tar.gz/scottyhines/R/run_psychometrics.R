#' Run Psychometrics Analysis
#'
#' This function performs psychometrics analysis on a specified set of items in a data frame,
#' including descriptive statistics, reliability analysis (Cronbach's alpha), item analysis,
#' Principal Component Analysis (PCA), and Exploratory Factor Analysis (EFA).
#'
#' @param df A data frame containing the data to be analyzed.
#' @param items A vector of column names in the data frame representing the items to be analyzed.
#' @param factors The number of factors for PCA and EFA. Default is 1.
#' @param rotation The rotation method for PCA and EFA. Default is "varimax".
#' @return A list containing the following components:
#' @export
run_psychometrics <- function(df, items, factors = 1, rotation = "varimax"){

  cat("Running psychometrics analysis...\n")
  
  wd <- dplyr::select(df, dplyr::all_of(items))
  
  # Step 1: Descriptive statistics
  cat("[1/6] Computing descriptive statistics...\n")
  out_psych_describe <- psych::describe(wd)

  # Step 2: Reliability analysis
  cat("[2/6] Computing reliability (Cronbach's alpha)...\n")
  psych_alpha <- psych::alpha(wd, check.keys=TRUE)
  out_psych_alpha <- psych_alpha$total
  
  # Step 3: Omega reliability (more robust than alpha)
  cat("[3/6] Computing omega reliability...\n")
  omega_result <- tryCatch({
    psych::omega(wd, nfactors = factors, plot = FALSE)
  }, error = function(e) {
    message("Omega calculation failed: ", e$message)
    NULL
  })

  # Step 4: Item analysis
  cat("[4/6] Running item analysis...\n")
  out_psych_item_analysis <- psychometric::item.exam(wd, y = NULL, discrim=TRUE)

  # Step 5: PCA
  cat("[5/6] Running Principal Component Analysis...\n")
  out_psych_pca <- psych::principal(wd, nfactors = factors, rotate = rotation)

  # Step 6: EFA
  cat("[6/6] Running Exploratory Factor Analysis...\n")
  temp <- stats::na.omit(wd) # remove missing data from the model
  out_psych_EFA <- stats::factanal(temp, factors = factors, rotation = rotation)
  
  # Extract fit indices for EFA
  efa_fit <- data.frame(
    n_factors = factors,
    chi_squared = out_psych_EFA$STATISTIC,
    df = out_psych_EFA$dof,
    p_value = out_psych_EFA$PVAL,
    n_obs = out_psych_EFA$n.obs
  )
  
  # Extract reliability metrics
  reliability_summary <- data.frame(
    cronbach_alpha = out_psych_alpha$raw_alpha,
    std_alpha = out_psych_alpha$std.alpha,
    omega_total = if (!is.null(omega_result)) omega_result$omega.tot else NA,
    omega_hierarchical = if (!is.null(omega_result)) omega_result$omega_h else NA,
    n_items = length(items),
    n_obs = nrow(wd)
  )
  
  cat("Analysis complete!\n\n")

  return(list(
    describe = out_psych_describe,
    alpha = out_psych_alpha,
    omega = omega_result,
    reliability_summary = reliability_summary,
    item_analysis = out_psych_item_analysis,
    pca = out_psych_pca,
    efa = out_psych_EFA,
    efa_fit = efa_fit
  ))
}
