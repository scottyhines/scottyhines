#' Run Logistic Regression
#'
#' Performs logistic regression analysis on a given dataset. This function allows for specifying one outcome variable,
#' optional control variables, and multiple variables of interest. It returns a summary dataframe that includes
#' odds ratios and confidence intervals for each variable of interest.
#'
#' @param data The dataset as a dataframe.
#' @param outcome_vars The name of the outcome variable as a string.
#' @param control_vars Optional character vector of control variables in the model.
#' @param interest_vars Character vector of variables of interest.
#' @param scale_numeric Logical. If TRUE, all numeric predictor and outcome columns are z-score scaled before fitting. Default is FALSE.
#' @return A dataframe summarizing the logistic regression analysis, including odds ratios and confidence intervals.
#' @export
run_logistic_regression <- function(data, outcome_vars, control_vars = NULL, interest_vars, scale_numeric = FALSE) {
  if (!requireNamespace("broom", quietly = TRUE)) stop("Package 'broom' is required but not installed.")
  
  # Scale numeric columns if requested
  if (scale_numeric) {
    all_vars <- unique(c(outcome_vars, interest_vars, control_vars))
    for (v in all_vars) {
      if (v %in% names(data) && is.numeric(data[[v]])) {
        data[[v]] <- as.numeric(scale(data[[v]]))
      }
    }
  }
  
  model_summaries <- list()
  model_fit_stats <- list()
  
  # Calculate total iterations for progress bar
  total_iterations <- length(outcome_vars) * length(interest_vars)
  pb <- txtProgressBar(min = 0, max = total_iterations, style = 3)
  current_iteration <- 0

  # Loop over the outcome variables
  for (outcome_var in outcome_vars) {
    base_formula <- paste(outcome_var, "~")

    if (!is.null(control_vars) && length(control_vars) > 0) {
      base_formula <- paste(base_formula, paste(control_vars, collapse = " + "), "+")
    }

    # Loop over interest variables to fit models
    for (variable in interest_vars) {
      tryCatch({
        formula <- as.formula(paste(base_formula, variable))
        model <- glm(formula, data = data, family = binomial(link = "logit"))
        tidy_model <- broom::tidy(model)
        odds_ratios <- exp(coef(model))
        conf_int <- exp(stats::confint(model))
        tidy_model$OR <- odds_ratios[names(odds_ratios) %in% tidy_model$term]
        tidy_model$CI_lower <- conf_int[rownames(conf_int), "2.5 %"]
        tidy_model$CI_upper <- conf_int[rownames(conf_int), "97.5 %"]
        tidy_model$variable_of_interest <- variable
        tidy_model$outcome_variable <- outcome_var
        model_summaries[[paste(outcome_var, variable, sep = "_")]] <- tidy_model
        
        # Extract model fit statistics
        null_model <- glm(as.formula(paste(outcome_var, "~ 1")), data = data, family = binomial(link = "logit"))
        mcfadden_r2 <- 1 - (logLik(model)[1] / logLik(null_model)[1])
        
        fit_stats <- data.frame(
          variable_of_interest = variable,
          outcome_variable = outcome_var,
          formula = paste(base_formula, variable),
          mcfadden_r2 = as.numeric(mcfadden_r2),
          aic = AIC(model),
          bic = BIC(model),
          null_deviance = model$null.deviance,
          residual_deviance = model$deviance,
          n_obs = nobs(model)
        )
        model_fit_stats[[paste(outcome_var, variable, sep = "_")]] <- fit_stats
        
        # Update progress bar
        current_iteration <- current_iteration + 1
        setTxtProgressBar(pb, current_iteration)
      }, error = function(e) {
        error_msg <- sprintf("ERROR: Failed processing variable '%s' with outcome '%s'\n  Formula: %s\n  Error: %s",
                             variable, outcome_var, paste(base_formula, variable), e$message)
        message(error_msg)
      })
    }
  }

  close(pb)
  cat("\n")

  final_summary <- do.call(rbind, model_summaries)
  final_fit_stats <- do.call(rbind, model_fit_stats)
  
  return(list(
    coefficients = janitor::clean_names(final_summary),
    model_fit = janitor::clean_names(final_fit_stats)
  ))
}

