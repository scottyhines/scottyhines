#' Grouped Line Chart Function
#'
#' This function creates a line chart showing the mean of a numeric variable
#' across a continuous or ordered x-axis variable, optionally grouped by a
#' categorical variable. Follows the same style conventions as the other
#' dataviz functions in this package.
#'
#' @param df A data frame containing the data.
#' @param x_var A string specifying the x-axis variable (e.g., time, tenure).
#' @param y_var A string specifying the numeric variable to summarize on the y-axis.
#' @param group_var Optional string specifying a grouping variable for multiple lines. Default is NULL.
#' @param title_text A string specifying the title of the plot. Default is "Line Chart".
#' @param sub_text A string specifying the subtitle. Default is "Mean over time".
#' @param x_text A string specifying the x-axis label. Default is NULL (uses x_var name).
#' @param y_text A string specifying the y-axis label. Default is NULL (uses y_var name).
#' @param caption_text A string specifying the caption. Default is "".
#' @param reference_line Optional numeric value to draw a horizontal reference line. Default is NULL.
#' @param show_points Logical. Show points on the line. Default is TRUE.
#' @param point_size Numeric. Size of the points. Default is 3.
#' @param line_size Numeric. Thickness of the lines. Default is 1.5.
#' @param show_overall_mean Logical. Show a horizontal line at the overall mean. Default is FALSE.
#'
#' @return A ggplot object.
#' @export
dataviz_line_chart_function <- function(df,
                                        x_var,
                                        y_var,
                                        group_var = NULL,
                                        title_text = "Line Chart",
                                        sub_text = "Mean over time",
                                        x_text = NULL,
                                        y_text = NULL,
                                        caption_text = "",
                                        reference_line = NULL,
                                        show_points = TRUE,
                                        point_size = 3,
                                        line_size = 1.5,
                                        show_overall_mean = FALSE) {

  # Default axis labels to variable names
  if (is.null(x_text)) x_text <- x_var
  if (is.null(y_text)) y_text <- y_var

  # Summarize data
  if (!is.null(group_var)) {
    plot_df <- df %>%
      dplyr::group_by(!!rlang::sym(x_var), !!rlang::sym(group_var)) %>%
      dplyr::summarise(y_mean = mean(!!rlang::sym(y_var), na.rm = TRUE), .groups = "drop") %>%
      na.omit()
  } else {
    plot_df <- df %>%
      dplyr::group_by(!!rlang::sym(x_var)) %>%
      dplyr::summarise(y_mean = mean(!!rlang::sym(y_var), na.rm = TRUE), .groups = "drop") %>%
      na.omit()
  }

  # Build the plot
  if (!is.null(group_var)) {
    plot <- ggplot2::ggplot(plot_df, ggplot2::aes(
      x = .data[[x_var]], y = y_mean,
      color = .data[[group_var]], group = .data[[group_var]]
    )) +
      ggplot2::geom_line(size = line_size) +
      viridis::scale_color_viridis(discrete = TRUE, option = "viridis")
  } else {
    plot <- ggplot2::ggplot(plot_df, ggplot2::aes(
      x = .data[[x_var]], y = y_mean, group = 1
    )) +
      ggplot2::geom_line(size = line_size, color = "black")
  }

  # Add points
  if (show_points) {
    if (!is.null(group_var)) {
      plot <- plot +
        ggplot2::geom_point(size = point_size, shape = 21, fill = "white", stroke = 2)
    } else {
      plot <- plot +
        ggplot2::geom_point(size = point_size, color = "black")
    }
  }

  # Reference line
  if (!is.null(reference_line)) {
    plot <- plot +
      ggplot2::geom_hline(yintercept = reference_line, linetype = "dashed", color = "red", size = 1)
  }

  # Overall mean line
  if (show_overall_mean) {
    overall_mean <- mean(df[[y_var]], na.rm = TRUE)
    plot <- plot +
      ggplot2::geom_hline(yintercept = overall_mean, linetype = "solid", size = 1.5)
  }

  # Labels and theme
  plot <- plot +
    ggplot2::labs(title = title_text, subtitle = sub_text, caption = caption_text) +
    ggplot2::xlab(x_text) +
    ggplot2::ylab(y_text) +
    ggplot2::theme_linedraw() +
    ggplot2::theme(aspect.ratio = 0.5)

  return(plot)
}
