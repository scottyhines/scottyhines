#' Run Linear Regression(s) With Optional Interaction Loop
#'
#' Fits linear models of the form:
#'   outcome ~ controls + (interest_var * interaction_with)
#' If `interaction_with` is NULL, it falls back to:
#'   outcome ~ controls + interest_var
#'
#' @param data A data.frame.
#' @param outcome_vars Character vector of outcome variable names.
#' @param control_vars Optional character vector of control variables always included.
#' @param interest_vars Character vector of predictors of interest to iterate over.
#' @param interaction_with Optional character vector of variables to interact with each interest var
#'   (e.g., "org_affiliation"). If provided, each model uses `interest_var * interaction_with`.
#' @param scale_numeric Logical. If TRUE, all numeric predictor and outcome columns are z-score scaled before fitting. Default is FALSE.
#' @return A data.frame (rows = model terms across all runs) with tidy coefficients and metadata.
#' @export
run_linear_regression <- function(data,
                                  outcome_vars,
                                  control_vars = NULL,
                                  interest_vars,
                                  interaction_with = NULL,
                                  scale_numeric = FALSE) {
  options(warn = -1)
  on.exit(options(warn = 0), add = TRUE)
  
  stopifnot(is.data.frame(data))
  stopifnot(is.character(outcome_vars), length(outcome_vars) >= 1)
  stopifnot(is.character(interest_vars), length(interest_vars) >= 1)
  if (!is.null(control_vars)) stopifnot(is.character(control_vars))
  if (!is.null(interaction_with)) stopifnot(is.character(interaction_with))
  
  # Scale numeric columns if requested
  if (scale_numeric) {
    all_vars <- unique(c(outcome_vars, interest_vars, control_vars, interaction_with))
    for (v in all_vars) {
      if (v %in% names(data) && is.numeric(data[[v]])) {
        data[[v]] <- as.numeric(scale(data[[v]]))
      }
    }
  }
  
  final_summary <- list()
  
  # Calculate total iterations for progress bar
  total_iterations <- length(outcome_vars) * length(interest_vars) * 
    ifelse(is.null(interaction_with), 1, length(interaction_with))
  pb <- txtProgressBar(min = 0, max = total_iterations, style = 3)
  current_iteration <- 0
  
  for (outcome_var in outcome_vars) {
    model_summaries <- list()
    model_fit_stats <- list()
    
    # Build the left side of the formula
    base_formula <- paste(outcome_var, "~")
    
    # Add controls if any
    if (!is.null(control_vars) && length(control_vars) > 0) {
      base_formula <- paste(base_formula, paste(control_vars, collapse = " + "), "+")
    }
    
    # Iterate over variables of interest
    for (variable in interest_vars) {
      
      # If interactions are requested, iterate across them; else just the variable
      partners <- if (is.null(interaction_with)) NA_character_ else interaction_with
      
      for (partner in partners) {
        tryCatch({
          if (is.na(partner)) {
            # No interaction: just add the interest variable
            rhs_term <- variable
            interacted_with_val <- NA_character_
          } else {
            # With interaction: use * to include main effects + interaction
            rhs_term <- paste(variable, partner, sep = " * ")
            interacted_with_val <- partner
          }
          
          # Full formula string
          complete_formula_str <- paste(base_formula, rhs_term, sep = " ")
          fm <- stats::as.formula(complete_formula_str)
          
          # Fit model
          fit <- stats::lm(fm, data = data)
          
          # Extract model fit statistics
          model_summary <- summary(fit)
          fit_stats <- data.frame(
            variable_of_interest = variable,
            interacted_with = interacted_with_val,
            outcome_variable = outcome_var,
            formula = complete_formula_str,
            r_squared = model_summary$r.squared,
            adj_r_squared = model_summary$adj.r.squared,
            f_statistic = model_summary$fstatistic[1],
            f_pvalue = pf(model_summary$fstatistic[1], 
                         model_summary$fstatistic[2], 
                         model_summary$fstatistic[3], 
                         lower.tail = FALSE),
            aic = AIC(fit),
            bic = BIC(fit),
            n_obs = nobs(fit),
            residual_se = model_summary$sigma
          )
          
          # Tidy summary
          tidy_model <- broom::tidy(fit)
          
          # Add metadata
          tidy_model$variable_of_interest <- variable
          tidy_model$interacted_with     <- interacted_with_val
          tidy_model$outcome_variable    <- outcome_var
          tidy_model$formula             <- complete_formula_str
          
          key <- if (is.na(interacted_with_val)) {
            paste(variable, outcome_var, sep = "__")
          } else {
            paste(variable, interacted_with_val, outcome_var, sep = "__")
          }
          model_summaries[[key]] <- tidy_model
          model_fit_stats[[key]] <- fit_stats
          
          # Update progress bar
          current_iteration <- current_iteration + 1
          setTxtProgressBar(pb, current_iteration)
        }, error = function(e) {
          error_msg <- if (is.na(partner)) {
            sprintf("ERROR: Failed processing variable '%s' with outcome '%s'\n  Formula: %s\n  Error: %s",
                    variable, outcome_var, complete_formula_str, e$message)
          } else {
            sprintf("ERROR: Failed processing variable '%s' interacted with '%s' for outcome '%s'\n  Formula: %s\n  Error: %s",
                    variable, partner, outcome_var, complete_formula_str, e$message)
          }
          message(error_msg)
        })
      }
    }
    
    final_summary[[outcome_var]] <- do.call(rbind, model_summaries)
    final_summary[[paste0(outcome_var, "_fit_stats")]] <- do.call(rbind, model_fit_stats)
  }
  
  close(pb)
  cat("\n")
  
  final_combined_summary <- do.call(rbind, final_summary[outcome_vars])
  rownames(final_combined_summary) <- NULL
  
  # Combine fit statistics
  fit_stat_keys <- paste0(outcome_vars, "_fit_stats")
  final_fit_stats <- do.call(rbind, final_summary[fit_stat_keys])
  rownames(final_fit_stats) <- NULL
  
  return(list(
    coefficients = janitor::clean_names(final_combined_summary),
    model_fit = janitor::clean_names(final_fit_stats)
  ))
}
