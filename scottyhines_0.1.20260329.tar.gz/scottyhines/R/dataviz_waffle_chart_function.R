#' Waffle Chart Function (Pure ggplot2)
#'
#' Creates a waffle chart showing the distribution of a categorical variable,
#' optionally faceted by a grouping variable. Each block represents a specified
#' number of observations. Built with geom_tile — no waffle package required.
#'
#' @param df A data frame containing the data.
#' @param fill_var A string specifying the categorical variable to fill by.
#' @param facet_var Optional string specifying a variable to facet by. Default is NULL.
#' @param block_size Numeric. Number of observations each block represents. Default is 1.
#' @param n_cols Numeric. Number of columns in the waffle grid. Default is 5.
#' @param title_text A string specifying the title. Default is "Waffle Chart".
#' @param sub_text A string specifying the subtitle. Default is NULL (auto-generates).
#' @param x_text A string specifying the x-axis label. Default is "".
#' @param y_text A string specifying the y-axis label. Default is "".
#' @param caption_text A string specifying the caption. Default is "".
#' @param facet_values Optional character vector to filter facet variable. Default is NULL.
#'
#' @return A ggplot object.
#' @export
dataviz_waffle_chart_function <- function(df,
                                          fill_var,
                                          facet_var = NULL,
                                          block_size = 1,
                                          n_cols = 5,
                                          title_text = "Waffle Chart",
                                          sub_text = NULL,
                                          x_text = "",
                                          y_text = "",
                                          caption_text = "",
                                          facet_values = NULL) {

  if (is.null(sub_text)) {
    sub_text <- paste0("Each block represents ", block_size, " observation(s)")
  }

  # Build grouped counts
  if (!is.null(facet_var)) {
    count_df <- df %>%
      dplyr::group_by(!!rlang::sym(facet_var), !!rlang::sym(fill_var)) %>%
      dplyr::summarise(n = dplyr::n(), .groups = "drop")
    if (!is.null(facet_values)) {
      count_df <- count_df %>%
        dplyr::filter(!!rlang::sym(facet_var) %in% facet_values)
    }
  } else {
    count_df <- df %>%
      dplyr::group_by(!!rlang::sym(fill_var)) %>%
      dplyr::summarise(n = dplyr::n(), .groups = "drop")
  }

  # Scale counts by block_size (round to nearest whole block)
  count_df <- count_df %>%
    dplyr::mutate(blocks = pmax(round(n / block_size), 0))

  # Expand into tile grid positions
  if (!is.null(facet_var)) {
    facet_levels <- unique(count_df[[facet_var]])
    tile_list <- list()
    for (fv in facet_levels) {
      sub <- count_df %>% dplyr::filter(!!rlang::sym(facet_var) == fv)
      tiles <- .build_waffle_tiles(sub, fill_var, n_cols)
      tiles[[facet_var]] <- fv
      tile_list[[fv]] <- tiles
    }
    tile_df <- dplyr::bind_rows(tile_list)
  } else {
    tile_df <- .build_waffle_tiles(count_df, fill_var, n_cols)
  }

  # Build the plot
  plot <- ggplot2::ggplot(tile_df, ggplot2::aes(x = col, y = row, fill = .data[[fill_var]])) +
    ggplot2::geom_tile(color = "white", linewidth = 0.5) +
    ggplot2::coord_equal() +
    viridis::scale_fill_viridis(discrete = TRUE, option = "viridis") +
    ggplot2::scale_y_continuous(expand = c(0, 0)) +
    ggplot2::scale_x_continuous(expand = c(0, 0))

  if (!is.null(facet_var)) {
    plot <- plot +
      ggplot2::facet_wrap(ggplot2::vars(.data[[facet_var]]), nrow = 1, strip.position = "bottom")
  }

  plot <- plot +
    ggplot2::labs(
      title = title_text, subtitle = sub_text,
      caption = caption_text, x = x_text, y = y_text
    ) +
    ggplot2::theme_linedraw() +
    ggplot2::theme(
      axis.text = ggplot2::element_blank(),
      axis.ticks = ggplot2::element_blank(),
      panel.grid = ggplot2::element_blank()
    )

  return(plot)
}

# Internal helper: expand counts into row/col tile positions
.build_waffle_tiles <- function(count_df, fill_var, n_cols) {
  tiles <- list()
  idx <- 1
  block_idx <- 0
  for (i in seq_len(nrow(count_df))) {
    nb <- count_df$blocks[i]
    if (nb > 0) {
      fill_val <- count_df[[fill_var]][i]
      for (b in seq_len(nb)) {
        block_idx <- block_idx + 1
        col <- ((block_idx - 1) %% n_cols) + 1
        row <- ((block_idx - 1) %/% n_cols) + 1
        tiles[[idx]] <- data.frame(
          col = col, row = row, fill_val = fill_val,
          stringsAsFactors = FALSE
        )
        idx <- idx + 1
      }
    }
  }
  result <- dplyr::bind_rows(tiles)
  if (nrow(result) > 0) {
    names(result)[names(result) == "fill_val"] <- fill_var
  }
  return(result)
}
