#' Grouped Bar Chart Function
#'
#' This function creates a bar chart showing means (with standard error bars) of a numeric
#' variable grouped by a specified categorical variable. Follows the same style conventions
#' as `dataviz_scatter_item_function`.
#'
#' @param df A data frame containing the data.
#' @param grouping_var A string specifying the grouping variable (categorical).
#' @param value_var A string specifying the numeric variable to summarize.
#' @param title_text A string specifying the title of the plot. Default is "Bar Chart".
#' @param sub_text A string specifying the subtitle of the plot. Default is "Mean by group".
#' @param x_text A string specifying the x-axis label. Default is "Group".
#' @param y_text A string specifying the y-axis label. Default is "Mean".
#' @param fill_var Optional string specifying a second grouping variable for dodged bars. Default is NULL.
#'
#' @return A ggplot object.
#' @export
dataviz_bar_chart_function <- function(df,
                                       grouping_var,
                                       value_var,
                                       title_text = "Bar Chart",
                                       sub_text = "Mean by group",
                                       x_text = "Group",
                                       y_text = "Mean",
                                       fill_var = NULL) {

  # Calculate summary statistics
  if (!is.null(fill_var)) {
    sum_stats <- df %>%
      dplyr::group_by(!!rlang::sym(grouping_var), !!rlang::sym(fill_var)) %>%
      dplyr::summarise(
        mean_val = mean(!!rlang::sym(value_var), na.rm = TRUE),
        se_val = sd(!!rlang::sym(value_var), na.rm = TRUE) / sqrt(dplyr::n()),
        .groups = "drop"
      )
  } else {
    sum_stats <- df %>%
      dplyr::group_by(!!rlang::sym(grouping_var)) %>%
      dplyr::summarise(
        mean_val = mean(!!rlang::sym(value_var), na.rm = TRUE),
        se_val = sd(!!rlang::sym(value_var), na.rm = TRUE) / sqrt(dplyr::n()),
        .groups = "drop"
      )
  }

  # Build the plot
  if (!is.null(fill_var)) {
    plot <- ggplot2::ggplot(sum_stats, ggplot2::aes(
      x = reorder(.data[[grouping_var]], mean_val),
      y = mean_val,
      fill = .data[[fill_var]]
    )) +
      ggplot2::geom_col(position = ggplot2::position_dodge(width = 0.8), width = 0.7) +
      ggplot2::geom_errorbar(ggplot2::aes(ymin = mean_val - se_val, ymax = mean_val + se_val),
                             position = ggplot2::position_dodge(width = 0.8), width = 0.2) +
      viridis::scale_fill_viridis(discrete = TRUE, option = "viridis")
  } else {
    plot <- ggplot2::ggplot(sum_stats, ggplot2::aes(
      x = reorder(.data[[grouping_var]], mean_val),
      y = mean_val,
      fill = mean_val
    )) +
      ggplot2::geom_col(width = 0.7) +
      ggplot2::geom_errorbar(ggplot2::aes(ymin = mean_val - se_val, ymax = mean_val + se_val), width = 0.2) +
      viridis::scale_fill_viridis(option = "viridis") +
      ggplot2::theme(legend.position = "none")
  }

  # Add overall mean reference line and styling
  overall_mean <- mean(df[[value_var]], na.rm = TRUE)

  plot <- plot +
    ggplot2::geom_hline(yintercept = overall_mean, linetype = "solid", size = 1.5) +
    ggplot2::labs(title = title_text, subtitle = sub_text, caption = "") +
    ggplot2::xlab(x_text) +
    ggplot2::ylab(y_text) +
    ggplot2::coord_flip() +
    ggplot2::theme_linedraw() +
    ggplot2::theme(aspect.ratio = 0.5)

  return(plot)
}
