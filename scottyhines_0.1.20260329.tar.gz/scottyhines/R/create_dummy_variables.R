#' Create Dummy Variables from Categorical Variables
#'
#' @description
#' Automatically creates dummy (binary indicator) variables from categorical variables.
#' Each level of the categorical variable becomes a new binary column.
#'
#' @param data A data frame or tibble
#' @param vars Character vector of variable names to dummy code. If NULL, all character and factor variables will be dummy coded.
#' @param remove_first Logical. If TRUE, removes the first dummy variable for each categorical variable (useful for regression to avoid multicollinearity). Default is FALSE.
#' @param remove_original Logical. If TRUE, removes the original categorical variables from the output. Default is FALSE.
#' @param prefix_sep Character string to separate the variable name from the level name in new column names. Default is "_".
#'
#' @return A data frame with dummy variables added
#'
#' @examples
#' \dontrun{
#' # Create dummy variables for specific columns
#' df_dummies <- create_dummy_variables(df, vars = c("gender", "status"))
#'
#' # Create dummy variables for all categorical variables
#' df_dummies <- create_dummy_variables(df)
#'
#' # Remove first dummy (for regression)
#' df_dummies <- create_dummy_variables(df, vars = "gender", remove_first = TRUE)
#'
#' # Remove original variables
#' df_dummies <- create_dummy_variables(df, vars = "status", remove_original = TRUE)
#' }
#'
#' @export
create_dummy_variables <- function(data, 
                                   vars = NULL, 
                                   remove_first = FALSE, 
                                   remove_original = FALSE,
                                   prefix_sep = "_") {
  
  # Check if data is provided
  if (missing(data) || is.null(data)) {
    stop("Please provide a data frame or tibble")
  }
  
  # Convert to data frame if tibble
  data <- as.data.frame(data)
  
  # If vars is NULL, identify all character and factor columns
  if (is.null(vars)) {
    vars <- names(data)[sapply(data, function(x) is.character(x) || is.factor(x))]
    
    if (length(vars) == 0) {
      message("No categorical variables found in the data")
      return(data)
    }
    
    message(paste0("Dummy coding variables: ", paste(vars, collapse = ", ")))
  }
  
  # Check if specified variables exist in data
  missing_vars <- setdiff(vars, names(data))
  if (length(missing_vars) > 0) {
    stop(paste0("Variables not found in data: ", paste(missing_vars, collapse = ", ")))
  }
  
  # Store original data
  result <- data
  
  # Loop through each variable to dummy code
  for (var in vars) {
    
    # Convert to factor if character
    if (is.character(data[[var]])) {
      data[[var]] <- as.factor(data[[var]])
    }
    
    # Get levels
    levels_var <- levels(data[[var]])
    
    # Determine which levels to create dummies for
    if (remove_first && length(levels_var) > 1) {
      levels_to_code <- levels_var[-1]
    } else {
      levels_to_code <- levels_var
    }
    
    # Create dummy variables
    for (level in levels_to_code) {
      # Create clean column name
      col_name <- paste0(var, prefix_sep, gsub("[^[:alnum:]_]", "_", level))
      
      # Create binary indicator
      result[[col_name]] <- as.integer(data[[var]] == level)
    }
  }
  
  # Remove original variables if requested
  if (remove_original) {
    result <- result[, !(names(result) %in% vars), drop = FALSE]
  }
  
  return(result)
}
