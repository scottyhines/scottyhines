#' A Function to Run Mixed-Effects Model Analysis
#'
#' This function performs mixed-effects model analysis on a given dataset. It allows for the specification of multiple outcome variables, control variables (if any), and variables of interest. The function returns a dataframe summarizing the analysis for each variable of interest, including estimates, standard errors, t-values, p-values, and means at each time point.
#'
#' @param data The dataset as a dataframe.
#' @param outcome_vars A character vector specifying the names of the outcome variables.
#' @param control_vars An optional character vector specifying control variables in the model. If provided, these variables are included in the model as additional fixed effects.
#' @param interest_vars A character vector specifying the variables of interest that will be individually added to the base model for analysis.
#' @param random_effects A string specifying the random effects structure (e.g., "(1 | subject)").
#' @param interaction_var A character string specifying the interaction variable.
#' @param include_interaction A boolean indicating whether to include the interaction term in the model (default is TRUE).
#' @param scale_numeric Logical. If TRUE, all numeric predictor and outcome columns are z-score scaled before fitting. Default is FALSE.
#' @return A list containing two dataframes:
#'   - model_summary: A dataframe summarizing the mixed-effects model analysis for each variable of interest, including regression coefficients, standard errors, t-statistics, and p-values.
#'   - means_summary: A dataframe summarizing the mean values of the outcome variable at each level of the interaction variable.
#' @export
run_mixed_effects_model <- function(data, outcome_vars, control_vars = NULL, interest_vars, random_effects, interaction_var, include_interaction = TRUE, scale_numeric = FALSE) {
  options(warn = -1)

  # Remove cases without the interaction variable
  data <- dplyr::filter(data, !is.na(.data[[interaction_var]]))
  
  # Scale numeric columns if requested
  if (scale_numeric) {
    all_vars <- unique(c(outcome_vars, interest_vars, control_vars, interaction_var))
    for (v in all_vars) {
      if (v %in% names(data) && is.numeric(data[[v]])) {
        data[[v]] <- as.numeric(scale(data[[v]]))
      }
    }
  }

  final_summary <- list()
  means_summary <- list()
  model_fit_stats <- list()
  
  # Calculate total iterations for progress bar
  total_iterations <- length(outcome_vars) * length(interest_vars)
  pb <- txtProgressBar(min = 0, max = total_iterations, style = 3)
  current_iteration <- 0

  for (outcome_var in outcome_vars) {
    for (variable in interest_vars) {
      tryCatch({
        if (include_interaction) {
          base_formula <- paste(outcome_var, "~", variable, "*", interaction_var)
        } else {
          base_formula <- paste(outcome_var, "~", variable, "+", interaction_var)
        }
        if (!is.null(control_vars) && length(control_vars) > 0) {
          base_formula <- paste(base_formula, "+", paste(control_vars, collapse = " + "))
        }
        complete_formula_str <- paste(base_formula, "+", random_effects)
        formula <- as.formula(complete_formula_str)

        # Print the formula to check it
        print(paste("Running model with formula:", formula))

        model <- lme4::lmer(formula, data = data)
        tidy_model <- broom.mixed::tidy(model, effects = "fixed")

        # Calculate p-values using t-distribution
        # Get degrees of freedom (approximation using Satterthwaite)
        df <- suppressMessages(lmerTest::lmer(formula, data = data))
        df_summary <- summary(df)

        # Add p-values to tidy_model
        tidy_model$p.value <- df_summary$coefficients[,"Pr(>|t|)"]

        tidy_model$variable_of_interest <- variable
        tidy_model$outcome_variable <- outcome_var

        means <- data %>%
          dplyr::group_by(.data[[interaction_var]]) %>%
          dplyr::summarize(mean = mean(.data[[outcome_var]], na.rm = TRUE)) %>%
          tidyr::pivot_wider(names_from = .data[[interaction_var]], values_from = mean, names_prefix = "mean_") %>%
          dplyr::mutate(outcome_variable = outcome_var, variable_of_interest = variable, interaction_variable = interaction_var)

        # Extract model fit statistics
        fit_stats <- data.frame(
          variable_of_interest = variable,
          outcome_variable = outcome_var,
          formula = complete_formula_str,
          aic = AIC(model),
          bic = BIC(model),
          loglik = as.numeric(logLik(model)),
          n_obs = nobs(model),
          n_groups = length(unique(data[[gsub(".*\\| (.*)\\)", "\\1", random_effects)]]))
        )
        
        # Calculate marginal and conditional R² (Nakagawa & Schielzeth method)
        var_fixed <- var(as.vector(lme4::fixef(model) %*% t(model.matrix(model))))
        var_random <- sum(as.numeric(lme4::VarCorr(model)))
        var_residual <- attr(lme4::VarCorr(model), "sc")^2
        
        fit_stats$marginal_r2 <- var_fixed / (var_fixed + var_random + var_residual)
        fit_stats$conditional_r2 <- (var_fixed + var_random) / (var_fixed + var_random + var_residual)

        final_summary[[paste(outcome_var, variable, sep = "_")]] <- tidy_model
        means_summary[[paste(outcome_var, variable, sep = "_")]] <- means
        model_fit_stats[[paste(outcome_var, variable, sep = "_")]] <- fit_stats
        
        # Update progress bar
        current_iteration <- current_iteration + 1
        setTxtProgressBar(pb, current_iteration)
      }, error = function(e) {
        error_msg <- sprintf("ERROR: Failed processing variable '%s' with outcome '%s' and interaction '%s'\n  Formula: %s\n  Error: %s",
                             variable, outcome_var, interaction_var, complete_formula_str, e$message)
        message(error_msg)
      })
    }
  }

  close(pb)
  cat("\n")

  final_combined_summary <- do.call(rbind, final_summary)
  final_means_summary <- do.call(rbind, means_summary)
  final_fit_stats <- do.call(rbind, model_fit_stats)

  options(warn = 0)
  return(list(
    model_summary = janitor::clean_names(final_combined_summary), 
    means_summary = janitor::clean_names(final_means_summary),
    model_fit = janitor::clean_names(final_fit_stats)
  ))
}
