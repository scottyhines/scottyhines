#' Build a summary table with means, counts, and optionally standard deviations for specified variables within each group.
#'
#' @param df A data frame containing the data to summarize.
#' @param group_var The name of the variable to group by (as a string).
#' @param vars A vector of variable names to calculate the summaries for.
#' @param include_sd A boolean indicating whether to include standard deviations in parentheses.
#'
#' @return A wide-format data frame where each group's mean, count, and optional standard deviation for each variable is a separate column.
#' @export
build_means_table <- function(df, group_var, vars, include_sd = FALSE) {
  # Convert group_var to symbol and ensure vars is treated correctly
  group_var_sym <- rlang::ensym(group_var)
  
  # Convert group_var to character to avoid joining issues
  df <- df %>%
    dplyr::mutate(!!group_var_sym := as.character(!!group_var_sym))
  
  # Calculate means for each variable within each group and round to 2 decimals
  means_df <- df %>%
    dplyr::group_by(!!group_var_sym) %>%
    dplyr::summarise(dplyr::across(all_of(vars), ~round(mean(.x, na.rm = TRUE), 2)), .groups = 'drop') %>%
    dplyr::mutate(across(all_of(vars), as.character)) # Ensure means are characters for consistency
  
  if (include_sd) {
    # Calculate standard deviations for each variable within each group and round to 2 decimals
    sds_df <- df %>%
      dplyr::group_by(!!group_var_sym) %>%
      dplyr::summarise(dplyr::across(all_of(vars), ~round(sd(.x, na.rm = TRUE), 2)), .groups = 'drop')
    
    # Rename columns to indicate they are standard deviations
    names(sds_df)[-1] <- paste0(names(sds_df)[-1], "_sd")
    
    # Merge means and standard deviations dataframes
    summary_df <- means_df %>%
      dplyr::left_join(sds_df, by = as.character(group_var_sym))
    
    # Format the means with SDs in parentheses
    summary_df <- summary_df %>%
      dplyr::mutate(across(all_of(vars), 
                           ~ paste0(.x, " (", get(paste0(cur_column(), "_sd")), ")"))) %>%
      dplyr::select(-ends_with("_sd"))
  } else {
    summary_df <- means_df
  }
  
  # Calculate the count of group
  counts_df <- df %>%
    dplyr::group_by(!!group_var_sym) %>%
    dplyr::summarise(N = n()) %>%
    dplyr::mutate(across(everything(), as.character)) # Ensure counts are characters
  
  # Merge the means and counts dataframes
  summary_df <- summary_df %>%
    dplyr::inner_join(counts_df, by = as.character(group_var_sym))
  
  # Pivot the data to a wide format with groups as column headers
  wide_df <- tidyr::pivot_longer(summary_df, cols = -!!group_var_sym, names_to = "variable", values_to = "value") %>%
    tidyr::pivot_wider(names_from = !!group_var_sym, values_from = value)
  
  # Ensure "N_n" is always the first row
  wide_df <- wide_df %>%
    dplyr::arrange(factor(variable, levels = c("N_n", setdiff(variable, "N_n"))))
  
  return(wide_df)
}
