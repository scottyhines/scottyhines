setwd("~/scottyhines")
library(roxygen2)
devtools::document()
devtools::check()

# usethis::use_test("square_number")
# usethis::use_test("run_t_test")
# usethis::use_test("run_hierarchical_regression")
# usethis::use_test("run_linear_regression")
# usethis::use_test("run_logistic_regression")
# usethis::use_test("run_network_analysis")
#usethis::use_test("create_fake_data")

devtools::build()

devtools::install("~/scottyhines")

install.packages("//Users/hinessco/scottyhines/scottyhines_0.20241203.tar.gz", repos = NULL, type = "source")

# test functions ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

library(scottyhines)
library(dplyr)

# create fake data ~~~~~~~~~~~~~~~~~~
df <- scottyhines::create_fake_data(5000) %>% dplyr::mutate(id = as.factor(id))
df %>% dplyr::mutate(quartile_group = scottyhines::quartile_categorize(demo_tenure)) %>%
  dplyr::mutate(quartile_group = as.factor(quartile_group)) %>% glimpse()

# set outcomes and predictors ~~~~~~~
outcomes <- c("attitude_work_ethic", "attitude_adaptability", "attitude_creativity")
vars_of_interest <- c("attitude_teamwork", "attitude_communication", "attitude_persistence")

# statifed sampling ~~~~~~~~~~~~~~~~~
out <- scottyhines::create_stratified_sample(df, c("demo_job_level", "demo_region_code", "demo_attrition"), 100)
out$sample
out$proportionality_check

# build tables ~~~~~~~~~~~~~~~~~~~~~~
scottyhines::build_means_table(df, group_var = "demo_region_code", vars = outcomes, include_sd = T)
scottyhines::build_frequency_table(df, group_var = "demo_performance", vars = "demo_region_code", include_percentage = T)
scottyhines::build_correlation_table(data = df, outcome_vars = outcomes, interest_vars = vars_of_interest)

# run statistical analyses ~~~~~~~~~~
# out_ttest <- scottyhines::run_t_test(df, outcome_vars = outcomes, group_var = "demo_attrition", paired = T)
# scottyhines::run_one_sample_ttest_with_overall_mean(df, item_col = outcomes, response_col = "demo_attrition")

out_anova <- scottyhines::run_anova_with_contrasts(df, group_var = "demo_region_code", outcome_vars = outcomes, control_variables = NULL)
out_anova$anova
out_anova$contrasts
out_anova$group_means
x <- scottyhines::run_linear_regression(df, outcome_var = outcomes, control_vars = "attitude_leadership", interest_vars = vars_of_interest)
x <- scottyhines::run_logistic_regression(df, outcome_var = "demo_attrition", control_vars = c("attitude_leadership", "attitude_innovation"), interest_vars = vars_of_interest)
x <- scottyhines::run_hierarchical_regression(df, outcome_var = outcomes, control_vars = c("demo_tenure", "demo_region_code"), interest_vars = vars_of_interest, group_var = "demo_job_level")
x <- scottyhines::run_regularized_regression(df, outcome_vars = outcomes, control_vars = NULL, interest_vars = vars_of_interest, alpha = 0)
scottyhines::run_network_analysis(df, outcome_var = "demo_performance", control_vars = "attitude_leadership", interest_vars = c("network_degree", "network_betweenness", "network_closeness", "network_eigenvector"), group_var = "demo_job_level", num_permutations = 500)
scottyhines::run_heartbeat(df, outcomes)
scottyhines::run_causal_attitude_network(df, gamma = .5, threshold = F)
x <- scottyhines::run_mixed_effects_model(df, outcome_vars = c("attitude_work_ethic", "attitude_adaptability"), control_vars = c("attitude_teamwork"), interest_vars = c("attitude_communication"), random_effects = "+ attitude_leadership * demo_job_level + (1 | demo_job_level)")
scottyhines::run_psychometrics(df, items = c(outcomes, vars_of_interest), factors = 2)

out <- scottyhines::lda_analysis(wd, predictor_vars = predictor_vars, metric = "quartile_group")
out$plot
out$accuracy
out$group_means


statements <- c(
  "In today's rapidly evolving business landscape, it is crucial to",
  "The implementation of cutting-edge technologies has revolutionized the way we",
  "Effective communication and collaboration are essential components for success in",
  "As organizations strive for innovation and growth, they must consider",
  "The integration of artificial intelligence and machine learning has significantly impacted",
  "optimize processes and streamline operations for maximum efficiency and productivity.",
  "adapt to changing market conditions and meet customer expectations effectively.",
  "foster a culture of continuous improvement and knowledge sharing across teams.",
  "the long-term implications of their strategic decisions on various stakeholders.",
  "various industries, from healthcare and finance to manufacturing and retail.",
  "The Quantum Computing Revolution is poised to transform cryptography and complex problem-solving in ways we can barely imagine today.",
  "Biometric authentication using DNA sequencing could become the next frontier in personal security and access control systems.",
  "Neuroplasticity-based learning algorithms may soon enable machines to adapt and learn like human brains, revolutionizing artificial intelligence.",
  "The integration of nanotechnology in medicine is opening up possibilities for targeted drug delivery and microscopic surgical procedures.",
  "Vertical farming coupled with AI-driven climate control could be the solution to sustainable urban food production in the future.",
  "The exploration of Mars continues to captivate scientists and the public alike, with new discoveries shaping our understanding of the Red Planet.",
  "Advancements in propulsion technology are bringing us closer to achieving interstellar travel and exploring distant star systems.",
  "The development of space-based solar power could revolutionize our approach to sustainable energy production on Earth.",
  "Asteroid mining has the potential to provide vast resources and reshape the global economy in unprecedented ways.",
  "The search for extraterrestrial intelligence (SETI) is entering a new era with more sophisticated detection methods and expanded search parameters.",
  "Space tourism is on the brink of becoming a reality, with private companies racing to offer commercial flights to low Earth orbit.",
  "The establishment of lunar bases could serve as a stepping stone for deep space exploration and resource utilization.",
  "Satellite constellations are transforming global communication networks and internet accessibility in remote areas of the world.",
  "The study of exoplanets is yielding new insights into the potential for life beyond our solar system.",
  "Space debris management is becoming increasingly crucial as we continue to launch more satellites and spacecraft into Earth's orbit.",
  "The rise of remote work has transformed traditional office dynamics and necessitated new approaches to team management and collaboration.",
  "Ergonomic office design is gaining importance as companies prioritize employee well-being and productivity in the workplace.",
  "Digital project management tools are streamlining workflows and enhancing team coordination in modern office environments.",
  "The concept of hot-desking is challenging traditional notions of personal workspace and promoting more flexible office arrangements.",
  "Workplace diversity and inclusion initiatives are becoming integral to corporate culture and talent acquisition strategies.",
  "The implementation of artificial intelligence in office automation is revolutionizing administrative tasks and data processing.",
  "Corporate sustainability practices are expanding beyond recycling to include energy-efficient technologies and green building design.",
  "The integration of virtual and augmented reality in office settings is opening new possibilities for training and collaborative work.",
  "Mindfulness and wellness programs are being incorporated into office cultures to combat stress and improve employee mental health.",
  "The evolution of office communication platforms is facilitating seamless interaction between in-office and remote team members.")

# Create the dataframe
df <- data.frame(
  id = 1:length(statements),
  text = statements,
  stringsAsFactors = FALSE
)
print(df)
# Print the dataframe
x <- scottyhines::run_cosine_similarity_with_attrs(df, text_col = "text", node_id_col = "id")
x$dissimilarity_ranking




