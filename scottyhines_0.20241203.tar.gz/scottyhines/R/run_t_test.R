#' Run T-Tests on Multiple Outcome Variables
#'
#' This function conducts t-tests on a set of outcome variables across two groups
#' within a dataset. It returns a dataframe summarizing the t-test analysis for
#' each outcome variable.
#'
#' @param data A dataframe containing the dataset.
#' @param outcome_vars A character vector specifying the names of the outcome variables.
#' @param group_var A character string specifying the name of the grouping variable.
#' @param paired A logical indicating whether to perform paired t-tests.
#' @return A dataframe summarizing the t-test results for each outcome variable, including
#'         t statistic, degrees of freedom, p-value, and the means of each group.
#' @export
run_t_test <- function(data, outcome_vars, group_var, paired = FALSE) {
  t_test_summaries <- list()

  # Loop over the outcome variables
  for (outcome_var in outcome_vars) {
    # Dynamically build the formula
    formula <- as.formula(paste(outcome_var, "~", group_var))

    # Fit the t-test model
    mod <- t.test(formula, data = data, paired = paired)

    # Get a tidy summary of the model
    tidy_model <- broom::tidy(mod)
    tidy_model$outcome_variable <- outcome_var # Add the outcome variable name for clarity
    tidy_model$group_variable <- group_var # Add the group variable name for clarity

    # Store the tidy_model in the list
    t_test_summaries[[outcome_var]] <- tidy_model
  }

  # Combine all t-test summaries into a single dataframe
  final_t_test_summary <- do.call(rbind, t_test_summaries)

  # Return the dataframe
  return(final_t_test_summary)
}
