#' Perform Linear Discriminant Analysis (LDA)
#'
#' This function performs Linear Discriminant Analysis on a given dataset,
#' creating a model, making predictions, and producing visualizations.
#'
#' @param df A data frame containing the variables for analysis.
#' @param predictor_vars A character vector of predictor variable names.
#' @param metric A string specifying the name of the outcome variable.
#'
#' @return A list containing:
#'   \item{fit}{The fitted LDA model}
#'   \item{augmented_data}{The original data augmented with predictions}
#'   \item{accuracy}{Accuracy metrics of the model}
#'   \item{plot}{A ggplot object showing predicted vs actual classes}
#'   \item{group_means}{A table of group means for each predictor}
#'
#' @import ggplot2
#' @importFrom stats as.formula
#' @importFrom rlang sym !!
#'
#' @export
lda_analysis <- function(df, predictor_vars, metric) {
  # Ensure metric is a factor
  df[[metric]] <- as.factor(df[[metric]])

  # 1. Define the recipe
  formula_str <- paste(metric, "~", paste(predictor_vars, collapse = " + "))
  formula <- stats::as.formula(formula_str)
  lda_recipe <- recipes::recipe(formula, data = df) %>%
    recipes::step_dummy(recipes::all_nominal(), -recipes::all_outcomes()) %>%
    recipes::step_normalize(recipes::all_numeric(), -recipes::all_outcomes()) %>%
    recipes::step_zv(recipes::all_predictors()) %>% # Remove zero-variance predictors
    recipes::step_corr(recipes::all_predictors(), threshold = 0.9) # Remove highly correlated predictors

  # 2. Define LDA model specification
  lda_spec <- discrim_linear() %>%
    parsnip::set_engine("MASS") %>%
    parsnip::set_mode("classification")

  # 3. Combine the recipe and model into a workflow
  lda_workflow <- workflows::workflow() %>%
    workflows::add_recipe(lda_recipe) %>%
    workflows::add_model(lda_spec)

  # 4. Fit the workflow to the data
  lda_fit <- tryCatch({
    generics::fit(lda_workflow, data = df)
  }, error = function(e) {
    message("Error in fitting the model: ", e$message)
    return(NULL)
  })

  if (is.null(lda_fit)) {
    return(list(error = "Model fitting failed"))
  }

  # 5. Make predictions and augment the data with prediction details
  df_augmented <- broom::augment(lda_fit, new_data = df) %>%
    dplyr::select(dplyr::all_of(predictor_vars), !!rlang::sym(metric), .pred_class)

  # Calculate accuracy and other classification metrics
  accuracy <- yardstick::metric_set(yardstick::accuracy, yardstick::kap, yardstick::mcc)(
    df_augmented,
    truth = !!rlang::sym(metric),
    estimate = .pred_class
  )

  # Create the plot
  plot <- ggplot2::ggplot(df_augmented, ggplot2::aes(x = !!rlang::sym(metric), y = .pred_class, color = !!rlang::sym(metric))) +
    ggplot2::geom_jitter(width = 0.2, height = 0.2, alpha = 0.5) +
    ggplot2::theme_minimal() +
    ggplot2::labs(title = "Predicted vs. Actual Classes", x = "Actual Class", y = "Predicted Class")

  # 6. Extract the fitted workflow
  prepped_recipe <- recipes::prep(lda_recipe, training = df)
  prepped_data <- recipes::juice(prepped_recipe)

  df_group <- dplyr::group_by(prepped_data, !!rlang::sym(metric)) %>%
    dplyr::summarise(across(everything(), mean, na.rm = TRUE)) %>%
    tidyr::pivot_longer(-!!rlang::sym(metric), names_to = "varaible", values_to = "value") %>%
    tidyr::pivot_wider(names_from = !!rlang::sym(metric), values_from = "value")

  # Return results as a list
  return(list(
    fit = lda_fit,
    augmented_data = df_augmented,
    accuracy = accuracy,
    plot = plot,
    group_means = df_group
  ))
}

