#' Categorize values into quartiles, handling NAs
#'
#' This function categorizes numeric values into quartiles and handles NA values
#' by first assigning them to a separate category (5), then converting back to NA.
#'
#' @param x A numeric vector to be categorized
#'
#' @return A vector of the same length as x, with values categorized as follows:
#'   - 1: values in the first quartile
#'   - 2: values in the second quartile
#'   - 3: values in the third quartile
#'   - 4: values in the fourth quartile
#'   - NA: originally NA values
#'
#' @examples
#' x <- c(1, 2, 3, 4, 5, NA, 7, 8, 9, 10)
#' quartile_categorize(x)
#'
#' @export
quartile_categorize <- function(x) {
  # Handle the case where all values are NA
  if(all(is.na(x))) {
    return(rep(NA_integer_, length(x)))
  }

  quartiles <- stats::quantile(x, probs = c(0.25, 0.5, 0.75), na.rm = TRUE)

  result <- dplyr::case_when(
    is.na(x) ~ 5L,
    x <= quartiles[1] ~ 1L,
    x <= quartiles[2] ~ 2L,
    x <= quartiles[3] ~ 3L,
    TRUE ~ 4L
  )

  # Convert 5 back to NA
  result[result == 5L] <- NA_integer_

  return(result)
}
