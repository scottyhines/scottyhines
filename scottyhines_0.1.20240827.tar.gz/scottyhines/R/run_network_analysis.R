#' Run Social Capital Network Analytic Regressions
#'
#' This function performs standard, permutaiton, and hierarchical (mixed-effects) regression analysis on a given dataset. It allows for the specification of an outcome variable, control variables (if any), variables of interest, and a grouping variable for random effects. The function returns a dataframe summarizing the regression analysis for each variable of interest.
#'
#' @param data A dataframe containing the dataset.
#' @param outcome_var A string specifying the name of the outcome variable.
#' @param control_vars An optional character vector specifying control variables in the model. If provided, these variables are included in the regression model as additional predictors alongside the variables of interest.
#' @param interest_vars A character vector specifying the variables of interest that will be individually added to the base model for analysis.
#' @param group_var A string specifying the name of the hierarchical group level variable to be used for random effects.
#' @param num_permutations A integer specifying the number of permutations to bootstrap over to account for lack of independence in social captial network analytic models.
#' @return A dataframe summarizing the linear regression analysis for each variable of interest. This summary includes regression coefficients, standard errors, t-statistics, p-values, and for random effects, the group variance component.
#' @export
run_network_analysis <- function(data, outcome_var, control_vars = NULL, interest_vars, group_var, num_permutations = 1000) {
  model_summaries <- list()
  # Check if control_vars is provided and non-empty
  control_vars_formula_part <- if (!is.null(control_vars) && length(control_vars) > 0) {
    paste(control_vars, collapse = " + ")
  } else {
    "1"
  }
  for (variable in interest_vars) {
    # Prepare the data
    var_names <- c(outcome_var, control_vars, variable, group_var)
    analysis_data <- data[complete.cases(data[var_names]), var_names]
    # Prepare the formula
    predictors <- c(variable, control_vars_formula_part)
    formula <- as.formula(paste(outcome_var, "~", paste(predictors, collapse = " + ")))
    # Observed model ~~~~~~~~~~~~~~~~
    mod_observed <- lm(formula, data = analysis_data)
    out_observed <- broom::tidy(mod_observed) %>%
      dplyr::mutate(variable_of_interest = variable) %>%
      dplyr::mutate(variable_of_interest = variable,
                    observed_estimate = estimate,
                    observed_std_error = std.error,
                    observed_statistic = statistic,
                    observed_p_value = format(p.value, digits = 10)) %>%
      dplyr::select(-estimate, -std.error, -statistic, -p.value)  # Removing original columns
    # Permutations ~~~~~~~~~~~~~~~~~~
    perm_fits <- replicate(num_permutations, {
      permuted_data <- analysis_data
      permuted_data[[outcome_var]] <- sample(analysis_data[[outcome_var]])
      mod_perm <- lm(formula, data = permuted_data)
      coef(mod_perm)
    }, simplify = FALSE)
    # Calculate means, CIs, and p-values for permutation results
    coef_names <- names(perm_fits[[1]])
    means <- sapply(coef_names, function(name) mean(sapply(perm_fits, function(fit) fit[name])))
    ci_list <- lapply(coef_names, function(name) {
      all_vals <- unlist(sapply(perm_fits, function(fit) fit[name]))
      quantile(all_vals, probs = c(0.025, 0.975))
    })
    ci_df <- do.call(rbind, ci_list)
    rownames(ci_df) <- coef_names
    ci_df <- as.data.frame(ci_df)
    names(ci_df) <- c("perm_lower", "perm_upper")
    means_df <- data.frame(term = names(means), perm_mean_value = means, row.names = NULL)
    perm_results <- cbind(means_df, ci_df)
    # pvalues ~~~~~~~~~~~~
    perm_p_values <- as.data.frame(perm_fits) %>%
      tibble::rownames_to_column("term") %>%
      dplyr::mutate(term = ifelse(term == "permuted", "net_stat", term)) %>%
      tidyr::pivot_longer(cols = 2:ncol(.), # what columns do we want to be long
                          names_to = "metric", # name of the metric
                          values_to = "estimate", # name of the value
                          values_drop_na = FALSE) %>% # drop nas?
      dplyr::left_join(out_observed) %>%
      dplyr::mutate(comparison = ifelse(estimate >= observed_estimate, 1, 0)) %>%
      dplyr::group_by(term) %>%
      dplyr::summarise(perm_p_value = mean(comparison)) %>%
      dplyr::ungroup()
    # Random effects model ~~~~~~~~~~~
    random_effect_formula <- paste0(outcome_var, "~", paste(predictors, collapse = " + "), "+ (1|", group_var, ")")
    mod_random <- lme4::lmer(as.formula(random_effect_formula), data = analysis_data)
    out_random_effects <- broom.mixed::tidy(mod_random) %>%
      janitor::clean_names() %>%
      dplyr::mutate(variable_of_interest = variable)
    random_model_pval <- broom.mixed::tidy(car::Anova(mod_random)) %>%
      janitor::clean_names() %>%
      dplyr::select(-statistic, -df) %>%
      dplyr::rename(random_effects_model_p_value = p_value)
    out_random_effects_final <- out_random_effects %>%
      dplyr::left_join(random_model_pval) %>%
      dplyr::rename_with(~paste("random_effects_model", ., sep = "_"), everything()) %>%
      dplyr::rename(term = random_effects_model_term,
                    variable_of_interest = random_effects_model_variable_of_interest)
    # Combine results ~~~~~~~~~~~~~~~~~~~~~
    out_fixed_effects <- out_observed %>%
      dplyr::select(term, starts_with("observed")) %>%
      dplyr::left_join(perm_results, by = "term") %>%
      dplyr::left_join(perm_p_values, by = "term") %>%
      dplyr::mutate(outcome = outcome_var)
    print(out_fixed_effects)
    final_model_summary <- dplyr::left_join(out_fixed_effects, out_random_effects_final)
    print("variavble ran")
    # Store in list
    model_summaries[[variable]] <- final_model_summary
  }
  # Bind all summaries together for final output
  final_summary <- dplyr::bind_rows(model_summaries, .id = "variable_of_interest") %>%
    dplyr::select(term, outcome, everything())
  return(final_summary)
}
