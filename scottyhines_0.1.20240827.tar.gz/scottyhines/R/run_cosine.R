#' Run Cosine Similarity and Extract Edge List and Node Attributes
#'
#' This function takes a dataframe containing text statements, calculates the cosine similarity matrix,
#' converts it to an edge list, and returns the edge list and node attributes.
#' It allows for the specification of text and node ID columns and adds node attributes.
#'
#' @param df A dataframe containing the text statements and node IDs.
#' @param text_col The name of the column containing the text statements (as a string).
#' @param node_id_col The name of the column containing the node IDs (as a string).
#' @param node_attrs A character vector of column names to be used as node attributes.
#' @return A list containing the edge list and node attributes.
#' @import text2vec
#' @import tm
#' @import igraph
#' @import dplyr
#' @export
run_cosine_similarity_with_attrs <- function(df, text_col, node_id_col, node_attrs = NULL) {
  # Extract texts and node IDs from the dataframe
  texts <- df[[text_col]]
  node_ids <- df[[node_id_col]]
  
  # Create a token iterator
  tokens <- text2vec::space_tokenizer(texts)
  
  # Create vocabulary
  it <- text2vec::itoken(tokens, progressbar = FALSE)
  vocab <- text2vec::create_vocabulary(it)
  
  # Create a term-co-occurrence matrix
  vectorizer <- text2vec::vocab_vectorizer(vocab)
  dtm <- text2vec::create_dtm(it, vectorizer)
  
  # Apply TF-IDF transformation
  tfidf <- text2vec::TfIdf$new()
  dtm_tfidf <- text2vec::fit_transform(dtm, tfidf)
  
  # Calculate cosine similarity
  cosine_sim <- text2vec::sim2(dtm_tfidf, method = "cosine")
  
  # Convert cosine similarity matrix to an edge list
  cosine_sim_matrix <- as.matrix(cosine_sim)
  
  edge_list <- data.frame(
    from = rep(node_ids, each = length(node_ids)),
    to = rep(node_ids, times = length(node_ids)),
    weight = as.vector(cosine_sim_matrix)
  )
  
  # Remove self-loops (where from == to)
  edge_list <- edge_list[edge_list$from != edge_list$to, ]
  
  # Remove duplicate edges
  edge_list <- edge_list[!duplicated(t(apply(edge_list, 1, sort))), ]
  
  # Get node file
  node_file <- df %>% dplyr::select(all_of(c(node_id_col, node_attrs)))
  
  # Create igraph object
  g <- igraph::graph_from_data_frame(edge_list, vertices = node_file, directed = FALSE)
  lay <- igraph::layout_nicely(g)
  # Plot the graph
  plot(g, layout = lay)
  
  # Return the edge list and node attributes
  return(list(
    edge_list = edge_list,
    node_file = node_file
  ))
}