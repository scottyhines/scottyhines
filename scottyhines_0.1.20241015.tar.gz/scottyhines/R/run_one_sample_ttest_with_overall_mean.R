#' Calculate One-Sample t-Test with Overall Mean
#'
#' This function performs a one-sample t-test for each unique item in a dataset, comparing the mean of a response variable
#' for each item to the overall mean of that response variable. The function returns a tidy dataframe with the t-test results,
#' including t-statistic, degrees of freedom, p-value, and confidence intervals.
#'
#' @param data A dataframe containing the dataset.
#' @param item_col A string specifying the column name of the items to group by for the t-test.
#' @param response_col A string specifying the column name of the response variable to be tested.
#' @param conf_level A numeric value specifying the confidence level for the confidence intervals. Default is 0.95.
#'
#' @return A dataframe with the following columns:
#' \item{item}{The unique items from the item column.}
#' \item{t_statistic}{The t-statistic from the t-test.}
#' \item{df}{The degrees of freedom associated with the t-test.}
#' \item{p_value}{The p-value associated with the t-test.}
#' \item{conf_low}{The lower bound of the confidence interval for the mean difference.}
#' \item{conf_high}{The upper bound of the confidence interval for the mean difference.}
#' \item{overall_mean}{The overall mean of the response variable across all items.}
#'
#' @importFrom dplyr group_by ungroup mutate rename
#' @importFrom broom tidy
#' @importFrom stats t.test
#' @export
run_one_sample_ttest_with_overall_mean <- function(data, item_col, response_col, conf_level = 0.95) {
  # Calculate the overall mean of the response column
  overall_mean <- mean(data[[response_col]], na.rm = TRUE)
  
  # Function to perform a one-sample t-test for a single item
  t_test_single_item <- function(df) {
    t_test_result <- stats::t.test(df[[response_col]], mu = overall_mean, conf.level = conf_level)
    tidy_result <- broom::tidy(t_test_result)
    return(tidy_result)
  }
  
  # Group by item and perform the t-test
  results <- data %>%
    dplyr::group_by(!!rlang::sym(item_col)) %>%
    dplyr::do(t_test_single_item(.)) %>%
    dplyr::ungroup()
  
  # Rename columns for clarity and add overall mean
  results <- results %>%
    dplyr::rename(
      item = !!rlang::sym(item_col),
      t_statistic = statistic,
      df = parameter,
      p_value = p.value,
      conf_low = conf.low,
      conf_high = conf.high
    ) %>%
    dplyr::mutate(overall_mean = overall_mean)
  
  return(results)
}