#' Run Psychometrics Analysis
#'
#' This function performs psychometrics analysis on a specified set of items in a data frame,
#' including descriptive statistics, reliability analysis (Cronbach's alpha), item analysis,
#' Principal Component Analysis (PCA), and Exploratory Factor Analysis (EFA).
#'
#' @param df A data frame containing the data to be analyzed.
#' @param items A vector of column names in the data frame representing the items to be analyzed.
#' @param factors The number of factors for PCA and EFA. Default is 1.
#' @param rotation The rotation method for PCA and EFA. Default is "varimax".
#' @return A list containing the following components:
#' @export
run_psychometrics <- function(df, items, factors = 1, rotation = "varimax"){

  wd <- dplyr::select(df, dplyr::all_of(items))
  out_psych_describe <- psych::describe(wd)

  psych_alpha <- psych::alpha(wd, check.keys=TRUE)
  out_psych_alpha <- psych_alpha$total

  out_psych_item_analysis <- psychometric::item.exam(wd, y = NULL, discrim=TRUE)

  # PCA
  out_psych_pca <- psych::principal(wd, nfactors = factors, rotate = rotation)

  # EFA
  temp <- stats::na.omit(wd) # remove missing data from the model
  out_psych_EFA <- stats::factanal(temp, factors = factors, rotation = rotation)

  return(list(
    describe = out_psych_describe,
    alpha = out_psych_alpha,
    item_analysis = out_psych_item_analysis,
    pca = out_psych_pca,
    efa = out_psych_EFA
  ))
}
